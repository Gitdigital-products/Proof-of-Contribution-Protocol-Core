"""
Math Equation Engine
====================

Provides symbolic math, equation parsing, numerical solvers,
and calculus operations. Built for scientific computing
and mathematical education.

Author: MiniMax Agent
Version: 1.0.0
"""

from math_engine.equations import *
from math_engine.solvers import *
from math_engine.calculus import *
from math_engine.differential_eq import *
from math_engine.optimization import *
from math_engine.expression_parser import *

__version__ = "1.0.0"
__author__ = "MiniMax Agent"

__all__ = [
    # Equations
    "Equation",
    "LinearEquation",
    "QuadraticEquation",
    "Polynomial",
    # Solvers
    "solve_linear",
    "solve_quadratic",
    "solve_polynomial",
    "solve_system",
    # Calculus
    "derivative",
    "integral",
    "gradient",
    "jacobian",
    "hessian",
    # Differential equations
    "solve_ode",
    "solve_pde",
    # Optimization
    "minimize",
    "maximize",
    "find_root",
    # Expression parser
    "parse_expression",
    "evaluate_expression",
]
