"""
Solvers Module
==============

Provides numerical solvers for equations, systems, and optimization.

Author: MiniMax Agent
"""

import numpy as np
from scipy import optimize, linalg
from typing import Union, List, Optional, Tuple, Dict, Any, Callable


def solve_linear(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    Solve linear system Ax = b.
    
    Args:
        a: Coefficient matrix (n, n)
        b: Right-hand side vector (n,)
        
    Returns:
        Solution vector x
    """
    return linalg.solve(a, b)


def solve_quadratic(a: float, b: float, c: float) -> Tuple[float, float]:
    """
    Solve quadratic equation ax² + bx + c = 0.
    
    Args:
        a: Coefficient of x²
        b: Coefficient of x
        c: Constant term
        
    Returns:
        Tuple of (x1, x2) solutions
    """
    discriminant = b**2 - 4*a*c
    
    if discriminant < 0:
        real_part = -b / (2*a)
        imag_part = np.sqrt(-discriminant) / (2*a)
        return (complex(real_part, imag_part), complex(real_part, -imag_part))
    
    sqrt_disc = np.sqrt(discriminant)
    x1 = (-b + sqrt_disc) / (2*a)
    x2 = (-b - sqrt_disc) / (2*a)
    
    return (x1, x2)


def solve_polynomial(coeffs: List[float], tol: float = 1e-12) -> np.ndarray:
    """
    Find roots of polynomial.
    
    Args:
        coeffs: Polynomial coefficients [a_n, ..., a_1, a_0]
        tol: Tolerance for root refinement
        
    Returns:
        Array of roots
    """
    if len(coeffs) == 1:
        return np.array([])
    
    roots = np.roots(coeffs)
    
    # Refine roots using Newton-Raphson
    def polynomial(x):
        return np.polyval(coeffs, x)
    
    refined_roots = []
    for root in roots:
        if np.isreal(root):
            root = root.real
            for _ in range(10):
                f = polynomial(root)
                if abs(f) < tol:
                    break
                df = np.polyval(np.polyder(coeffs), root)
                if abs(df) < tol:
                    break
                root = root - f / df
            refined_roots.append(root)
        else:
            refined_roots.append(root)
    
    return np.array(refined_roots)


def solve_system(
    funcs: List[Callable],
    x0: np.ndarray,
    method: str = 'hybr',
    max_iter: int = 1000,
    tol: float = 1e-8
) -> Tuple[np.ndarray, bool]:
    """
    Solve system of nonlinear equations.
    
    Args:
        funcs: List of functions f_i(x) = 0
        x0: Initial guess
        method: Solution method ('hybr', 'lm', 'broyden1')
        max_iter: Maximum iterations
        tol: Tolerance
        
    Returns:
        Tuple of (solution, success)
    """
    def combined_func(x):
        return np.array([f(x) for f in funcs])
    
    result = optimize.root(
        combined_func,
        x0,
        method=method,
        options={'maxiter': max_iter, 'tol': tol}
    )
    
    return result.x, result.success


def solve_ivp(
    fun: Callable,
    y0: np.ndarray,
    t_span: Tuple[float, float],
    t_eval: Optional[np.ndarray] = None,
    method: str = 'RK45'
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Solve initial value problem dy/dt = f(t, y).
    
    Args:
        fun: Function f(t, y)
        y0: Initial conditions
        t_span: Time span (t_start, t_end)
        t_eval: Time points to evaluate
        method: Integration method
        
    Returns:
        Tuple of (t_values, y_values)
    """
    from scipy.integrate import solve_ivp as scipy_solve_ivp
    
    solution = scipy_solve_ivp(
        fun,
        t_span,
        y0,
        t_eval=t_eval,
        method=method
    )
    
    return solution.t, solution.y


def newton_raphson(
    func: Callable,
    deriv: Callable,
    x0: float,
    max_iter: int = 100,
    tol: float = 1e-8
) -> Tuple[float, int, bool]:
    """
    Newton-Raphson method for finding roots.
    
    Args:
        func: Function f(x)
        deriv: Derivative f'(x)
        x0: Initial guess
        max_iter: Maximum iterations
        tol: Tolerance
        
    Returns:
        Tuple of (solution, iterations, converged)
    """
    x = x0
    
    for i in range(max_iter):
        f = func(x)
        df = deriv(x)
        
        if abs(df) < tol:
            break
        
        x_new = x - f / df
        
        if abs(x_new - x) < tol:
            return x_new, i + 1, True
        
        x = x_new
    
    return x, max_iter, False


def bisection(
    func: Callable,
    a: float,
    b: float,
    max_iter: int = 100,
    tol: float = 1e-8
) -> Tuple[float, int, bool]:
    """
    Bisection method for finding roots.
    
    Args:
        func: Function f(x)
        a: Left endpoint
        b: Right endpoint
        max_iter: Maximum iterations
        tol: Tolerance
        
    Returns:
        Tuple of (solution, iterations, converged)
    """
    fa = func(a)
    fb = func(b)
    
    if fa * fb > 0:
        raise ValueError("Function must have opposite signs at endpoints")
    
    for i in range(max_iter):
        c = (a + b) / 2
        fc = func(c)
        
        if abs(fc) < tol or (b - a) / 2 < tol:
            return c, i + 1, True
        
        if fa * fc < 0:
            b = c
            fb = fc
        else:
            a = c
            fa = fc
    
    return (a + b) / 2, max_iter, False


def secant_method(
    func: Callable,
    x0: float,
    x1: float,
    max_iter: int = 100,
    tol: float = 1e-8
) -> Tuple[float, int, bool]:
    """
    Secant method for finding roots.
    
    Args:
        func: Function f(x)
        x0: First initial guess
        x1: Second initial guess
        max_iter: Maximum iterations
        tol: Tolerance
        
    Returns:
        Tuple of (solution, iterations, converged)
    """
    x_prev = x0
    x_curr = x1
    
    for i in range(max_iter):
        f_prev = func(x_prev)
        f_curr = func(x_curr)
        
        if abs(f_curr - f_prev) < tol:
            break
        
        x_next = x_curr - f_curr * (x_curr - x_prev) / (f_curr - f_prev)
        
        if abs(x_next - x_curr) < tol:
            return x_next, i + 1, True
        
        x_prev = x_curr
        x_curr = x_next
    
    return x_curr, max_iter, False


def fixed_point_iteration(
    g: Callable,
    x0: float,
    max_iter: int = 100,
    tol: float = 1e-8
) -> Tuple[float, int, bool]:
    """
    Fixed point iteration for solving x = g(x).
    
    Args:
        g: Iteration function
        x0: Initial guess
        max_iter: Maximum iterations
        tol: Tolerance
        
    Returns:
        Tuple of (solution, iterations, converged)
    """
    x = x0
    
    for i in range(max_iter):
        x_new = g(x)
        
        if abs(x_new - x) < tol:
            return x_new, i + 1, True
        
        x = x_new
    
    return x, max_iter, False


def minimize_1d(
    func: Callable,
    a: float,
    b: float,
    method: str = 'golden'
) -> Tuple[float, float, int]:
    """
    Minimize 1D function in interval.
    
    Args:
        func: Function to minimize
        a: Left endpoint
        b: Right endpoint
        method: Method ('golden', 'bounded')
        
    Returns:
        Tuple of (minimum_x, minimum_f, iterations)
    """
    result = optimize.minimize_scalar(
        func,
        bounds=(a, b),
        method=method
    )
    
    return result.x, result.fun, result.nfev


def minimize_nd(
    func: Callable,
    x0: np.ndarray,
    method: str = 'BFGS',
    bounds: Optional[List[Tuple[float, float]]] = None,
    constraints: Optional[Dict] = None,
    options: Optional[Dict] = None
) -> Tuple[np.ndarray, float, Dict]:
    """
    Minimize n-dimensional function.
    
    Args:
        func: Objective function
        x0: Initial guess
        method: Optimization method
        bounds: Variable bounds
        constraints: Optimization constraints
        options: Additional options
        
    Returns:
        Tuple of (minimum_x, minimum_f, info)
    """
    result = optimize.minimize(
        func,
        x0,
        method=method,
        bounds=bounds,
        constraints=constraints,
        options=options
    )
    
    return result.x, result.fun, {
        'success': result.success,
        'nit': result.nit,
        'nfev': result.nfev
    }


def find_root_broyden(
    func: Callable,
    x0: np.ndarray,
    max_iter: int = 100,
    tol: float = 1e-8
) -> Tuple[np.ndarray, bool]:
    """
    Broyden's method for systems of equations.
    
    Args:
        func: System of equations f(x) = 0
        x0: Initial guess
        max_iter: Maximum iterations
        tol: Tolerance
        
    Returns:
        Tuple of (solution, converged)
    """
    result = optimize.root(
        func,
        x0,
        method='broyden1',
        options={'maxiter': max_iter, 'tol': tol}
    )
    
    return result.x, result.success
