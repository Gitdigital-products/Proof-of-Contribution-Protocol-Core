"""
Calculus Module
===============

Provides derivatives, integrals, gradients, Jacobians, and Hessians
for mathematical operations.

Author: MiniMax Agent
"""

import numpy as np
from typing import Callable, List, Tuple, Union, Optional
from scipy import optimize


def derivative(
    func: Callable,
    x: float,
    method: str = 'central',
    tol: float = 1e-8
) -> float:
    """
    Compute numerical derivative.
    
    Args:
        func: Function to differentiate
        x: Point at which to evaluate
        method: 'forward', 'backward', or 'central'
        tol: Step size
        
    Returns:
        Derivative value
    """
    if method == 'forward':
        return (func(x + tol) - func(x)) / tol
    elif method == 'backward':
        return (func(x) - func(x - tol)) / tol
    else:  # central
        return (func(x + tol) - func(x - tol)) / (2 * tol)


def partial_derivative(
    func: Callable,
    x: np.ndarray,
    var_idx: int,
    tol: float = 1e-8
) -> float:
    """
    Compute partial derivative with respect to variable.
    
    Args:
        func: Multivariate function
        x: Point at which to evaluate
        var_idx: Index of variable to differentiate
        tol: Step size
        
    Returns:
        Partial derivative value
    """
    x_plus = x.copy()
    x_minus = x.copy()
    
    x_plus[var_idx] += tol
    x_minus[var_idx] -= tol
    
    return (func(x_plus) - func(x_minus)) / (2 * tol)


def gradient(
    func: Callable,
    x: np.ndarray,
    tol: float = 1e-8
) -> np.ndarray:
    """
    Compute gradient vector.
    
    Args:
        func: Multivariate function
        x: Point at which to evaluate
        tol: Step size
        
    Returns:
        Gradient vector
    """
    grad = np.zeros(len(x))
    
    for i in range(len(x)):
        grad[i] = partial_derivative(func, x, i, tol)
    
    return grad


def jacobian(
    funcs: List[Callable],
    x: np.ndarray,
    tol: float = 1e-8
) -> np.ndarray:
    """
    Compute Jacobian matrix of system of functions.
    
    Args:
        funcs: List of functions
        x: Point at which to evaluate
        tol: Step size
        
    Returns:
        Jacobian matrix (len(funcs), len(x))
    """
    jac = np.zeros((len(funcs), len(x)))
    
    for i, f in enumerate(funcs):
        for j in range(len(x)):
            jac[i, j] = partial_derivative(f, x, j, tol)
    
    return jac


def hessian(
    func: Callable,
    x: np.ndarray,
    tol: float = 1e-8
) -> np.ndarray:
    """
    Compute Hessian matrix of second derivatives.
    
    Args:
        func: Twice-differentiable function
        x: Point at which to evaluate
        tol: Step size
        
    Returns:
        Hessian matrix
    """
    n = len(x)
    hess = np.zeros((n, n))
    
    # Second partial derivatives
    for i in range(n):
        for j in range(i, n):
            # f_xx
            if i == j:
                x_plus = x.copy()
                x_minus = x.copy()
                x_plus[i] += tol
                x_minus[i] -= tol
                hess[i, i] = (func(x_plus) - 2*func(x) + func(x_minus)) / (tol**2)
            else:
                # f_xy
                x_pp = x.copy()
                x_pm = x.copy()
                x_mp = x.copy()
                x_mm = x.copy()
                
                x_pp[i] += tol
                x_pp[j] += tol
                x_pm[i] += tol
                x_pm[j] -= tol
                x_mp[i] -= tol
                x_mp[j] += tol
                x_mm[i] -= tol
                x_mm[j] -= tol
                
                hess[i, j] = (func(x_pp) - func(x_pm) - func(x_mp) + func(x_mm)) / (4 * tol**2)
                hess[j, i] = hess[i, j]
    
    return hess


def integral(
    func: Callable,
    a: float,
    b: float,
    method: str = 'trapezoid',
    n: int = 1000
) -> float:
    """
    Compute definite integral numerically.
    
    Args:
        func: Function to integrate
        a: Lower bound
        b: Upper bound
        method: 'trapezoid', 'simpson', or 'romberg'
        n: Number of subintervals
        
    Returns:
        Integral value
    """
    if method == 'trapezoid':
        x = np.linspace(a, b, n + 1)
        y = np.array([func(xi) for xi in x])
        return np.trapz(y, x)
    
    elif method == 'simpson':
        if n % 2 == 1:
            n += 1
        x = np.linspace(a, b, n + 1)
        y = np.array([func(xi) for xi in x])
        return np.simps(y, x)
    
    elif method == 'romberg':
        return romberg_integration(func, a, b)
    
    else:
        raise ValueError(f"Unknown method: {method}")


def romberg_integration(
    func: Callable,
    a: float,
    b: float,
    max_iter: int = 10,
    tol: float = 1e-8
) -> float:
    """
    Romberg integration for high accuracy.
    
    Args:
        func: Function to integrate
        a: Lower bound
        b: Upper bound
        max_iter: Maximum iterations
        tol: Tolerance
        
    Returns:
        Integral value
    """
    R = np.zeros((max_iter, max_iter))
    
    # First column - trapezoidal rule with doubling intervals
    h = b - a
    R[0, 0] = h * (func(a) + func(b)) / 2
    
    for i in range(1, max_iter):
        h /= 2
        
        # Trapezoidal rule
        n_intervals = 2**i
        x = np.linspace(a, b, n_intervals + 1)
        y = np.array([func(xi) for xi in x])
        R[i, 0] = np.trapz(y, x)
        
        # Richardson extrapolation
        for j in range(1, i + 1):
            R[i, j] = R[i, j-1] + (R[i, j-1] - R[i-1, j-1]) / (4**j - 1)
        
        # Check convergence
        if i > 0 and abs(R[i, i] - R[i-1, i-1]) < tol:
            return R[i, i]
    
    return R[max_iter-1, max_iter-1]


def double_integral(
    func: Callable,
    x_range: Tuple[float, float],
    y_range: Tuple[float, float],
    n: int = 50
) -> float:
    """
    Compute double integral numerically.
    
    Args:
        func: Function of two variables
        x_range: (x_min, x_max)
        y_range: (y_min, y_max)
        n: Number of points per dimension
        
    Returns:
        Integral value
    """
    from scipy import integrate
    
    result, _ = integrate.dblquad(
        func,
        y_range[0], y_range[1],
        lambda x: x_range[0], lambda x: x_range[1]
    )
    
    return result


def triple_integral(
    func: Callable,
    x_range: Tuple[float, float],
    y_range: Tuple[float, float],
    z_range: Tuple[float, float]
) -> float:
    """
    Compute triple integral numerically.
    
    Args:
        func: Function of three variables
        x_range: (x_min, x_max)
        y_range: (y_min, y_max)
        z_range: (z_min, z_max)
        
    Returns:
        Integral value
    """
    from scipy import integrate
    
    result, _ = integrate.tplquad(
        func,
        z_range[0], z_range[1],
        lambda z: y_range[0], lambda z: y_range[1],
        lambda z, y: x_range[0], lambda z, y: x_range[1]
    )
    
    return result


def laplacian(
    func: Callable,
    x: np.ndarray,
    h: float = 1e-5
) -> float:
    """
    Compute Laplacian of function at point.
    
    Args:
        func: Function to compute Laplacian of
        x: Point (must be 3D for standard Laplacian)
        h: Step size
        
    Returns:
        Laplacian value
    """
    n = len(x)
    
    if n == 1:
        # 1D: d²f/dx²
        return (func(x + h) - 2*func(x) + func(x - h)) / h**2
    
    elif n == 2:
        # 2D: d²f/dx² + d²f/dy²
        x_plus = x.copy()
        x_minus = x.copy()
        x_plus[0] += h
        x_minus[0] -= h
        d2f_dx2 = (func(x_plus) - 2*func(x) + func(x_minus)) / h**2
        
        y_plus = x.copy()
        y_minus = x.copy()
        y_plus[1] += h
        y_minus[1] -= h
        d2f_dy2 = (func(y_plus) - 2*func(x) + func(y_minus)) / h**2
        
        return d2f_dx2 + d2f_dy2
    
    elif n == 3:
        # 3D Laplacian
        laplacian_sum = 0
        
        for i in range(3):
            x_plus = x.copy()
            x_minus = x.copy()
            x_plus[i] += h
            x_minus[i] -= h
            laplacian_sum += (func(x_plus) - 2*func(x) + func(x_minus)) / h**2
        
        return laplacian_sum
    
    else:
        raise ValueError("Laplacian supported for 1D, 2D, or 3D only")


def divergence(
    vector_field: Callable,
    x: np.ndarray,
    h: float = 1e-5
) -> float:
    """
    Compute divergence of vector field.
    
    Args:
        vector_field: Function returning vector [f1, f2, ..., fn]
        x: Point at which to compute divergence
        h: Step size
        
    Returns:
        Divergence value
    """
    n = len(x)
    div = 0
    
    for i in range(n):
        def partial_j(j):
            x_plus = x.copy()
            x_plus[j] += h
            x_minus = x.copy()
            x_minus[j] -= h
            vf_plus = vector_field(x_plus)
            vf_minus = vector_field(x_minus)
            return (vf_plus[i] - vf_minus[i]) / (2 * h)
        
        div += partial_j(i)
    
    return div


def curl_3d(
    vector_field: Callable,
    x: np.ndarray,
    h: float = 1e-5
) -> np.ndarray:
    """
    Compute curl of 3D vector field.
    
    Args:
        vector_field: Function returning [f1, f2, f3]
        x: Point at which to compute curl
        h: Step size
        
    Returns:
        Curl vector [curl_x, curl_y, curl_z]
    """
    def partial_derivative(f, i, j):
        """Partial derivative of f_i with respect to x_j."""
        x_plus = x.copy()
        x_minus = x.copy()
        x_plus[j] += h
        x_minus[j] -= h
        
        vf_plus = vector_field(x_plus)
        vf_minus = vector_field(x_minus)
        
        return (vf_plus[i] - vf_minus[i]) / (2 * h)
    
    # curl_x = df3/dy - df2/dz
    curl_x = partial_derivative(lambda v: vector_field(v)[2], 0, 1) - \
             partial_derivative(lambda v: vector_field(v)[1], 0, 2)
    
    # curl_y = df1/dz - df3/dx
    curl_y = partial_derivative(lambda v: vector_field(v)[0], 1, 2) - \
             partial_derivative(lambda v: vector_field(v)[2], 1, 0)
    
    # curl_z = df2/dx - df1/dy
    curl_z = partial_derivative(lambda v: vector_field(v)[1], 2, 0) - \
             partial_derivative(lambda v: vector_field(v)[0], 2, 1)
    
    return np.array([curl_x, curl_y, curl_z])
