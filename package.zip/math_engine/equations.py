"""
Equations Module
================

Provides equation classes for symbolic mathematics including
linear, quadratic, and polynomial equations.

Author: MiniMax Agent
"""

import numpy as np
from typing import Union, List, Optional, Tuple, Dict, Any
from dataclasses import dataclass
import operator


@dataclass
class Equation:
    """
    Base class for mathematical equations.
    
    Attributes:
        expression: String representation of equation
        variables: List of variable names
    """
    expression: str
    variables: List[str] = None
    
    def __post_init__(self):
        """Initialize equation."""
        if self.variables is None:
            # Extract variables from expression
            self.variables = sorted(set(c for c in self.expression if c.isalpha()))
    
    def evaluate(self, values: Dict[str, float]) -> float:
        """
        Evaluate equation with given variable values.
        
        Args:
            values: Dictionary mapping variable names to values
            
        Returns:
            Evaluated result
        """
        expr = self.expression
        for var, val in values.items():
            expr = expr.replace(var, str(val))
        return eval(expr)
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.expression})"


class LinearEquation(Equation):
    """
    Linear equation of the form ax + b = 0.
    
    Represents and solves linear equations with various methods.
    """
    
    def __init__(self, a: float, b: float, var: str = 'x'):
        """
        Initialize linear equation ax + b = 0.
        
        Args:
            a: Coefficient of variable
            b: Constant term
            var: Variable name
        """
        self.a = a
        self.b = b
        self.var = var
        super().__init__(f"{a}*{var} + {b}")
    
    def solve(self) -> float:
        """
        Solve linear equation.
        
        Returns:
            Solution for x
        """
        if self.a == 0:
            if self.b == 0:
                return float('inf')  # Infinite solutions
            else:
                raise ValueError("No solution: 0*x + b = 0 has no solution")
        
        return -self.b / self.a
    
    def get_slope(self) -> float:
        """Get slope (coefficient a)."""
        return self.a
    
    def get_intercept(self) -> float:
        """Get y-intercept (constant b)."""
        return self.b
    
    def evaluate(self, values: Dict[str, float]) -> float:
        """Evaluate at given x value."""
        x = values.get(self.var, 0)
        return self.a * x + self.b


class QuadraticEquation(Equation):
    """
    Quadratic equation of the form ax² + bx + c = 0.
    
    Supports solving via quadratic formula, factoring,
    and vertex calculations.
    """
    
    def __init__(self, a: float, b: float, c: float, var: str = 'x'):
        """
        Initialize quadratic equation ax² + bx + c = 0.
        
        Args:
            a: Coefficient of x²
            b: Coefficient of x
            c: Constant term
            var: Variable name
        """
        self.a = a
        self.b = b
        self.c = c
        self.var = var
        super().__init__(f"{a}*{var}**2 + {b}*{var} + {c}")
    
    def solve(self) -> Tuple[float, float]:
        """
        Solve quadratic equation using quadratic formula.
        
        Returns:
            Tuple of (x1, x2) solutions
        """
        discriminant = self.b**2 - 4*self.a*self.c
        
        if discriminant < 0:
            # Complex roots
            real_part = -self.b / (2*self.a)
            imag_part = np.sqrt(-discriminant) / (2*self.a)
            return (complex(real_part, imag_part), complex(real_part, -imag_part))
        
        sqrt_disc = np.sqrt(discriminant)
        x1 = (-self.b + sqrt_disc) / (2*self.a)
        x2 = (-self.b - sqrt_disc) / (2*self.a)
        
        return (x1, x2)
    
    def get_vertex(self) -> Tuple[float, float]:
        """
        Get vertex of parabola.
        
        Returns:
            Tuple of (x, y) coordinates
        """
        x_vertex = -self.b / (2*self.a)
        y_vertex = self.a * x_vertex**2 + self.b * x_vertex + self.c
        return (x_vertex, y_vertex)
    
    def get_discriminant(self) -> float:
        """Get discriminant value."""
        return self.b**2 - 4*self.a*self.c
    
    def get_axis_of_symmetry(self) -> float:
        """Get axis of symmetry line."""
        return -self.b / (2*self.a)


class Polynomial(Equation):
    """
    General polynomial equation.
    
    Supports polynomials of any degree with various
    operations and root-finding.
    """
    
    def __init__(self, coefficients: List[float], var: str = 'x'):
        """
        Initialize polynomial from coefficients.
        
        Args:
            coefficients: List of coefficients [a_n, ..., a_1, a_0]
                        for a_n*x^n + ... + a_1*x + a_0
            var: Variable name
        """
        self.coefficients = coefficients
        self.degree = len(coefficients) - 1
        self.var = var
        
        # Build expression string
        expr_parts = []
        for i, coef in enumerate(coefficients):
            power = len(coefficients) - 1 - i
            if coef == 0:
                continue
            
            if power == 0:
                term = f"{coef}"
            elif power == 1:
                term = f"{coef}*{var}"
            else:
                term = f"{coef}*{var}**{power}"
            
            expr_parts.append(term)
        
        expression = " + ".join(expr_parts) if expr_parts else "0"
        super().__init__(expression)
    
    def evaluate(self, values: Dict[str, float]) -> float:
        """Evaluate polynomial at given value."""
        x = values.get(self.var, 0)
        return np.polyval(self.coefficients, x)
    
    def derivative(self) -> 'Polynomial':
        """
        Compute derivative polynomial.
        
        Returns:
            New Polynomial representing derivative
        """
        if self.degree == 0:
            return Polynomial([0])
        
        deriv_coeffs = []
        for i, coef in enumerate(self.coefficients[:-1]):
            power = self.degree - i
            deriv_coeffs.append(coef * power)
        
        return Polynomial(deriv_coeffs)
    
    def integral(self, constant: float = 0) -> 'Polynomial':
        """
        Compute indefinite integral polynomial.
        
        Args:
            constant: Integration constant
            
        Returns:
            New Polynomial representing integral
        """
        int_coeffs = [constant]
        for i, coef in enumerate(self.coefficients):
            power = i + 1
            int_coeffs.append(coef / power)
        
        return Polynomial(int_coeffs)
    
    def find_roots(self) -> np.ndarray:
        """
        Find roots of polynomial numerically.
        
        Returns:
            Array of roots
        """
        if self.degree == 0:
            return np.array([])
        
        return np.roots(self.coefficients)
    
    def evaluate_horner(self, x: float) -> float:
        """
        Evaluate using Horner's method (more numerically stable).
        
        Args:
            x: Value to evaluate at
            
        Returns:
            Polynomial value
        """
        result = self.coefficients[0]
        for coef in self.coefficients[1:]:
            result = result * x + coef
        return result


def create_polynomial_from_roots(roots: np.ndarray) -> Polynomial:
    """
    Create polynomial from roots.
    
    Args:
        roots: Array of roots
        
    Returns:
        Polynomial with given roots
    """
    # (x - r1)(x - r2)... = expand
    coeffs = np.poly(roots)
    return Polynomial(coeffs.tolist())


def polynomial_gcd(p1: List[float], p2: List[float]) -> List[float]:
    """
    Compute GCD of two polynomials using Euclidean algorithm.
    
    Args:
        p1: First polynomial coefficients
        p2: Second polynomial coefficients
        
    Returns:
        GCD polynomial coefficients
    """
    from np.linalg import gcd
    
    while len(p2) > 1 or (len(p2) == 1 and p2[0] != 0):
        remainder = np.polynomial.polydiv(p1, p2)[1]
        p1, p2 = p2, remainder.tolist()
    
    return p1 if p1 else [0]
