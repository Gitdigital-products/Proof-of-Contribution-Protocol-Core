"""
Linear Algebra Module
=====================

Provides comprehensive linear algebra operations using NumPy and SciPy.
Includes matrix decompositions, solving systems, and advanced operations
with proper numerical stability considerations.

Author: MiniMax Agent
"""

import numpy as np
from scipy import linalg
from typing import Union, Tuple, Optional, List, Dict, Any
from numpy.typing import NDArray, MatrixLike


def solve_linear(
    a: MatrixLike,
    b: MatrixLike,
    method: str = 'auto',
    overwrite_a: bool = False,
    overwrite_b: bool = False
) -> NDArray:
    """
    Solve linear system Ax = b for x.
    
    Supports multiple solving methods with automatic selection based
    on matrix properties for optimal performance and stability.
    
    Args:
        a: Coefficient matrix (n, n)
        b: Right-hand side vector or matrix (n,) or (n, k)
        method: Solving method ('auto', 'lu', 'qr', 'cholesky', 'svd')
        overwrite_a: Allow overwriting a for memory efficiency
        overwrite_b: Allow overwriting b for memory efficiency
        
    Returns:
        Solution matrix x
        
    Raises:
        LinAlgError: If matrix is singular or nearly singular
    """
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    
    if method == 'auto':
        # Auto-select method based on matrix properties
        if a.shape[0] == a.shape[1]:
            # Check if symmetric positive definite
            if np.allclose(a, a.T, rtol=1e-5):
                try:
                    return linalg.solve(a, b, assume_a='pos', overwrite_a=overwrite_a, overwrite_b=overwrite_b)
                except linalg.LinAlgError:
                    pass
            # Try standard LU decomposition
            return linalg.solve(a, b, overwrite_a=overwrite_a, overwrite_b=overwrite_b)
        else:
            # Rectangular case - use least squares
            return linalg.lstsq(a, b)[0]
    
    elif method == 'lu':
        return linalg.solve(a, b, overwrite_a=overwrite_a, overwrite_b=overwrite_b)
    
    elif method == 'cholesky':
        return linalg.solve(a, b, assume_a='pos', overwrite_a=overwrite_a, overwrite_b=overwrite_b)
    
    elif method == 'qr':
        # QR decomposition for stability
        q, r = linalg.qr(a, mode='economic')
        return linalg.solve_triangular(r, q.T @ b)
    
    elif method == 'svd':
        # SVD for ill-conditioned matrices
        u, s, vt = linalg.svd(a, full_matrices=False)
        s_inv = np.where(s > 1e-10, 1/s, 0)
        return vt.T @ (s_inv[:, None] * (u.T @ b))
    
    else:
        raise ValueError(f"Unknown method: {method}")


def eigen_decomposition(
    a: MatrixLike,
    compute_vectors: bool = True,
    method: str = 'direct'
) -> Tuple[NDArray, Optional[NDArray]]:
    """
    Compute eigenvalues and optionally eigenvectors.
    
    Args:
        a: Square matrix (n, n)
        compute_vectors: Whether to compute eigenvectors
        method: Computation method ('direct', 'eigh', 'eigvals')
        
    Returns:
        Tuple of (eigenvalues, eigenvectors) if compute_vectors=True
    """
    a = np.asarray(a, dtype=np.float64)
    
    if not compute_vectors:
        if method == 'eigh' and np.allclose(a, a.T):
            return linalg.eigvalsh(a)
        return linalg.eigvals(a)
    
    if method == 'eigh' and np.allclose(a, a.T):
        eigenvalues, eigenvectors = linalg.eigh(a)
    else:
        eigenvalues, eigenvectors = linalg.eig(a)
    
    # Sort by eigenvalue magnitude
    idx = np.abs(eigenvalues).argsort()[::-1]
    eigenvalues = eigenvalues[idx]
    if compute_vectors:
        eigenvectors = eigenvectors[:, idx]
    
    return eigenvalues, eigenvectors


def svd_decomposition(
    a: MatrixLike,
    full_matrices: bool = False,
    compute_uv: bool = True
) -> Tuple[NDArray, NDArray, NDArray]:
    """
    Singular Value Decomposition (SVD).
    
    A = U @ S @ Vh where U and V are orthogonal, S is diagonal.
    
    Args:
        a: Input matrix (m, n)
        full_matrices: Whether to compute full U and V matrices
        compute_uv: Whether to compute U and V
        
    Returns:
        Tuple of (U, S, Vh) if compute_uv=True, else (S,)
    """
    a = np.asarray(a, dtype=np.float64)
    
    if compute_uv:
        U, S, Vh = linalg.svd(a, full_matrices=full_matrices)
        return U, S, Vh
    else:
        S = linalg.svd(a, compute_uv=False)
        return (S,)


def cholesky_decomposition(
    a: MatrixLike,
    lower: bool = False,
    overwrite: bool = False
) -> NDArray:
    """
    Cholesky decomposition for symmetric positive definite matrices.
    
    A = L @ L.T (lower=True) or A = U.T @ U (lower=False)
    
    Args:
        a: Symmetric positive definite matrix
        lower: Whether to return lower triangular factor
        overwrite: Allow in-place computation
        
    Returns:
        Triangular factor
    """
    a = np.asarray(a, dtype=np.float64)
    
    if not np.allclose(a, a.T):
        raise ValueError("Matrix must be symmetric for Cholesky decomposition")
    
    return linalg.cholesky(a, lower=lower, overwrite=overwrite)


def qr_decomposition(
    a: MatrixLike,
    mode: str = 'reduced',
    pivoting: bool = False
) -> Tuple[NDArray, NDArray, Optional[NDArray]]:
    """
    QR decomposition using Gram-Schmidt or Householder reflections.
    
    A = Q @ R where Q is orthogonal and R is upper triangular.
    
    Args:
        a: Input matrix (m, n)
        mode: 'reduced', 'full', 'r', 'economic'
        pivoting: Whether to use column pivoting
        
    Returns:
        Tuple of (Q, R, P) if pivoting=True, else (Q, R)
    """
    a = np.asarray(a, dtype=np.float64)
    
    if pivoting:
        Q, R, P = linalg.qr(a, mode='economic', pivoting=True)
        return Q, R, P
    else:
        Q, R = linalg.qr(a, mode=mode)
        return Q, R


def matrix_power(
    a: MatrixLike,
    p: float,
    compute_sqrt: bool = False
) -> NDArray:
    """
    Compute matrix power with optional matrix square root.
    
    For non-integer powers, uses eigendecomposition:
    A^p = V @ D^p @ V^(-1)
    
    Args:
        a: Square matrix
        p: Power exponent (can be fractional)
        compute_sqrt: If True and p=0.5, compute matrix square root
        
    Returns:
        Matrix raised to power p
    """
    a = np.asarray(a, dtype=np.float64)
    
    if compute_sqrt and p == 0.5:
        eigenvalues, eigenvectors = linalg.eigh(a)
        sqrt_eigenvalues = np.sqrt(np.maximum(eigenvalues, 0))
        return eigenvectors @ np.diag(sqrt_eigenvalues) @ eigenvectors.T
    
    eigenvalues, eigenvectors = linalg.eig(a)
    
    # Handle complex eigenvalues for real matrices
    if np.iscomplexobj(eigenvalues):
        # Real form using absolute values
        eigenvalues = np.abs(eigenvalues) ** p
    else:
        eigenvalues = np.power(eigenvalues, p)
    
    # Handle numerical issues with near-zero eigenvalues
    eigenvalues = np.where(np.abs(eigenvalues) < 1e-10, 1.0, eigenvalues)
    
    return eigenvectors @ np.diag(eigenvalues) @ linalg.inv(eigenvectors)


def matrix_exponential(
    a: MatrixLike,
    method: str = 'Pade'
) -> NDArray:
    """
    Compute matrix exponential exp(A).
    
    Uses Padé approximants or Taylor series for numerical stability.
    
    Args:
        a: Square matrix
        method: 'Pade' or 'Taylor'
        
    Returns:
        Matrix exponential
    """
    a = np.asarray(a, dtype=np.float64)
    return linalg.expm(a)


def matrix_logarithm(
    a: MatrixLike,
    method: str = 'Pade'
) -> NDArray:
    """
    Compute matrix logarithm log(A).
    
    Inverse operation of matrix exponential.
    
    Args:
        a: Square matrix with positive eigenvalues
        method: Computation method
        
    Returns:
        Matrix logarithm
    """
    a = np.asarray(a, dtype=np.float64)
    return linalg.logm(a)


def condition_number(
    a: MatrixLike,
    p: Optional[str] = None
) -> float:
    """
    Compute condition number of matrix.
    
    The condition number indicates numerical stability:
    - cond(A) = 1 for well-conditioned matrices
    - cond(A) >> 1 for ill-conditioned matrices
    
    Args:
        a: Input matrix
        p: Norm type ('2', 'fro', 'inf')
        
    Returns:
        Condition number
    """
    a = np.asarray(a, dtype=np.float64)
    return linalg.cond(a, p=p)


def matrix_norm(
    a: MatrixLike,
    ord: str = 'fro'
) -> float:
    """
    Compute matrix norm.
    
    Supported norms:
    - 'fro': Frobenius norm
    - 'nuc': Nuclear norm (sum of singular values)
    - 'inf': Infinity norm (max row sum)
    - '-inf': Min infinity norm (min row sum)
    - '1': One norm (max column sum)
    - '2': Spectral norm (max singular value)
    
    Args:
        a: Input matrix
        ord: Norm type
        
    Returns:
        Matrix norm value
    """
    a = np.asarray(a, dtype=np.float64)
    return linalg.norm(a, ord=ord)


def vector_norm(
    a: NDArray,
    ord: Optional[float] = None
) -> float:
    """
    Compute vector norm.
    
    Args:
        a: Input vector
        ord: Norm order (None=2-norm, 1=manhattan, 2=euclidean, inf=max)
        
    Returns:
        Vector norm value
    """
    a = np.asarray(a, dtype=np.float64)
    return linalg.norm(a, ord=ord)


def kronecker_product(
    a: MatrixLike,
    b: MatrixLike
) -> NDArray:
    """
    Compute Kronecker product of two matrices.
    
    Args:
        a: First matrix (m, n)
        b: Second matrix (p, q)
        
    Returns:
        Kronecker product (m*p, n*q)
    """
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    return np.kron(a, b)


def hadamard_product(
    a: MatrixLike,
    b: MatrixLike
) -> NDArray:
    """
    Element-wise (Hadamard) product of matrices.
    
    Args:
        a: First matrix
        b: Second matrix (must have same shape)
        
    Returns:
        Element-wise product
    """
    return np.multiply(a, b)


def trace(a: MatrixLike) -> float:
    """
    Compute matrix trace (sum of diagonal elements).
    
    Args:
        a: Input matrix
        
    Returns:
        Trace value
    """
    a = np.asarray(a, dtype=np.float64)
    return np.trace(a)


def determinant(a: MatrixLike) -> float:
    """
    Compute matrix determinant.
    
    Args:
        a: Square matrix
        
    Returns:
        Determinant value
    """
    a = np.asarray(a, dtype=np.float64)
    return linalg.det(a)


def rank(a: MatrixLike, tol: float = 1e-10) -> int:
    """
    Compute matrix rank.
    
    Args:
        a: Input matrix
        tol: Tolerance for singular values
        
    Returns:
        Matrix rank
    """
    a = np.asarray(a, dtype=np.float64)
    s = linalg.svd(a, compute_uv=False)
    return np.sum(s > tol)


def null_space(
    a: MatrixLike,
    tol: float = 1e-10
) -> NDArray:
    """
    Find null space of matrix (vectors that map to zero).
    
    Args:
        a: Input matrix
        tol: Tolerance for singular values
        
    Returns:
        Orthogonal basis for null space
    """
    a = np.asarray(a, dtype=np.float64)
    _, s, vh = linalg.svd(a)
    null_mask = s <= tol
    null_space_basis = vh[null_mask].T
    return null_space_basis


def orthogonal_complement(
    a: MatrixLike,
    tol: float = 1e-10
) -> NDArray:
    """
    Find orthogonal complement of matrix span.
    
    Args:
        a: Input matrix (m, n) with m <= n
        tol: Tolerance
        
    Returns:
        Basis for orthogonal complement
    """
    a = np.asarray(a, dtype=np.float64)
    _, _, Vh = linalg.svd(a)
    rank_a = rank(a, tol)
    return Vh[rank_a:].T


def solve Sylvester equation:
    """
    Solve Sylvester equation: AX + XB = C
    
    Args:
        a: Matrix A (n, n)
        b: Matrix B (m, m)
        c: Matrix C (n, m)
        
    Returns:
        Solution matrix X
    """
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    c = np.asarray(c, dtype=np.float64)
    
    # Vectorize: (I ⊗ A + B.T ⊗ I) vec(X) = vec(C)
    n, m = c.shape
    lhs = np.kron(np.eye(m), a) + np.kron(b.T, np.eye(n))
    rhs = c.flatten()
    
    x_flat = solve_linear(lhs, rhs)
    return x_flat.reshape(n, m)


def solve_lyapunov(
    a: MatrixLike,
    q: MatrixLike
) -> NDArray:
    """
    Solve Lyapunov equation: AX + XA.T = Q
    
    For stable system analysis and control theory.
    
    Args:
        a: System matrix (n, n)
        q: Right-hand side (n, n)
        
    Returns:
        Solution matrix X
    """
    a = np.asarray(a, dtype=np.float64)
    q = np.asarray(q, dtype=np.float64)
    
    return linalg.solve_continuous_lyapunov(a, q)
