"""
SciPy Operations Module
=======================

Provides wrappers and utilities for SciPy optimization, interpolation,
signal processing, and scientific computing. Built for production use
with comprehensive error handling and validation.

Author: MiniMax Agent
"""

import numpy as np
from scipy import optimize, signal, interpolate, integrate, stats
from scipy.special import expit, logit
from typing import Union, Tuple, List, Optional, Callable, Dict, Any
from numpy.typing import NDArray


def optimize(
    func: Callable[[NDArray], float],
    x0: NDArray,
    method: str = 'L-BFGS-B',
    bounds: Optional[List[Tuple[float, float]]] = None,
    constraints: Optional[Dict[str, Any]] = None,
    options: Optional[Dict[str, Any]] = None
) -> Tuple[NDArray, float, Dict[str, Any]]:
    """
    General-purpose optimization with multiple method support.
    
    Args:
        func: Objective function to minimize
        x0: Initial guess
        method: Optimization method ('L-BFGS-B', 'SLSQP', 'Nelder-Mead', etc.)
        bounds: Variable bounds as list of (min, max) tuples
        constraints: Dictionary of constraints for SLSQP
        options: Additional optimization options
        
    Returns:
        Tuple of (optimal_x, optimal_value, info_dict)
    """
    default_options = {
        'disp': False,
        'maxiter': 1000,
        'ftol': 1e-9
    }
    
    if options:
        default_options.update(options)
    
    if method == 'L-BFGS-B' and bounds is not None:
        result = optimize.minimize(
            func, x0, method=method,
            bounds=bounds,
            options=default_options
        )
    elif method == 'SLSQP' and constraints is not None:
        result = optimize.minimize(
            func, x0, method=method,
            constraints=constraints,
            bounds=bounds,
            options=default_options
        )
    else:
        result = optimize.minimize(
            func, x0, method=method,
            options=default_options
        )
    
    return result.x, result.fun, {
        'success': result.success,
        'message': result.message,
        'nit': result.nit,
        'nfev': result.nfev
    }


def gradient_descent(
    func: Callable[[NDArray], float],
    grad_func: Callable[[NDArray], NDArray],
    x0: NDArray,
    learning_rate: float = 0.01,
    max_iter: int = 1000,
    tolerance: float = 1e-6,
    momentum: float = 0.0
) -> Tuple[NDArray, float, List[float]]:
    """
    Gradient descent optimization with momentum support.
    
    Args:
        func: Objective function
        grad_func: Gradient function
        x0: Initial point
        learning_rate: Step size
        max_iter: Maximum iterations
        tolerance: Convergence tolerance
        momentum: Momentum coefficient
        
    Returns:
        Tuple of (optimal_x, optimal_value, loss_history)
    """
    x = x0.copy()
    velocity = np.zeros_like(x)
    loss_history = []
    
    for i in range(max_iter):
        grad = grad_func(x)
        loss = func(x)
        loss_history.append(loss)
        
        velocity = momentum * velocity - learning_rate * grad
        x_new = x + velocity
        
        if np.abs(func(x_new) - loss) < tolerance:
            break
        
        x = x_new
    
    return x, func(x), loss_history


def newton_method(
    func: Callable[[NDArray], float],
    grad_func: Callable[[NDArray], NDArray],
    hess_func: Callable[[NDArray], NDArray],
    x0: NDArray,
    max_iter: int = 100,
    tolerance: float = 1e-6
) -> Tuple[NDArray, float]:
    """
    Newton's method for optimization.
    
    Args:
        func: Objective function
        grad_func: Gradient function
        hess_func: Hessian function
        x0: Initial guess
        
    Returns:
        Tuple of (optimal_x, optimal_value)
    """
    x = x0.copy()
    
    for _ in range(max_iter):
        grad = grad_func(x)
        hess = hess_func(x)
        
        try:
            delta = np.linalg.solve(hess, grad)
        except np.linalg.LinAlgError:
            delta = np.linalg.lstsq(hess, grad, rcond=None)[0]
        
        x_new = x - delta
        
        if np.linalg.norm(delta) < tolerance:
            break
        
        x = x_new
    
    return x, func(x)


def interpolate_1d(
    x: NDArray,
    y: NDArray,
    x_new: NDArray,
    kind: str = 'cubic'
) -> NDArray:
    """
    1D interpolation with multiple method support.
    
    Args:
        x: Known x coordinates
        y: Known y values
        x_new: Points to interpolate
        kind: Interpolation method ('linear', 'cubic', 'quintic')
        
    Returns:
        Interpolated values
    """
    if len(x) != len(y):
        raise ValueError("x and y must have same length")
    
    f = interpolate.interp1d(x, y, kind=kind, fill_value='extrapolate')
    return f(x_new)


def interpolate_2d(
    points: Tuple[NDArray, NDArray],
    values: NDArray,
    points_new: Tuple[NDArray, NDArray],
    method: str = 'cubic'
) -> NDArray:
    """
    2D interpolation using scipy.interpolate.
    
    Args:
        points: Tuple of (x, y) coordinates
        values: Function values at grid points
        points_new: New (x, y) coordinates for interpolation
        method: Interpolation method
        
    Returns:
        Interpolated values
    """
    f = interpolate.interp2d(points[0], points[1], values, kind=method)
    return f(points_new[0], points_new[1])


def signal_process(
    data: NDArray,
    sampling_rate: float,
    lowcut: Optional[float] = None,
    highcut: Optional[float] = None,
    order: int = 5
) -> Tuple[NDArray, NDArray]:
    """
    Apply bandpass filter to signal.
    
    Args:
        data: Input signal
        sampling_rate: Sampling rate in Hz
        lowcut: Low frequency cutoff
        highcut: High frequency cutoff
        order: Filter order
        
    Returns:
        Tuple of (filtered_signal, filter_info)
    """
    nyquist = 0.5 * sampling_rate
    
    if lowcut is not None and highcut is not None:
        low = lowcut / nyquist
        high = highcut / nyquist
        b, a = signal.butter(order, [low, high], btype='band')
    elif lowcut is not None:
        low = lowcut / nyquist
        b, a = signal.butter(order, low, btype='high')
    elif highcut is not None:
        high = highcut / nyquist
        b, a = signal.butter(order, high, btype='low')
    else:
        return data, {}
    
    filtered = signal.filtfilt(b, a, data)
    
    return filtered, {'b': b, 'a': a, 'sampling_rate': sampling_rate}


def filter_signal(
    data: NDArray,
    b: NDArray,
    a: NDArray,
    zi: Optional[NDArray] = None
) -> Tuple[NDArray, NDArray]:
    """
    Apply IIR filter with optional initial conditions.
    
    Args:
        data: Input signal
        b: Numerator coefficients
        a: Denominator coefficients
        zi: Initial conditions
        
    Returns:
        Tuple of (filtered_signal, final_state)
    """
    if zi is not None:
        filtered, zf = signal.lfilter(b, a, data, zi=zi)
    else:
        filtered = signal.lfilter(b, a, data)
        zf = None
    
    return filtered, zf


def find_peaks(
    data: NDArray,
    height: Optional[float] = None,
    distance: int = 1,
    prominence: Optional[float] = None
) -> Tuple[NDArray, Dict[str, NDArray]]:
    """
    Find peaks in signal with various constraints.
    
    Args:
        data: Input signal
        height: Minimum height of peaks
        distance: Minimum distance between peaks
        prominence: Minimum prominence of peaks
        
    Returns:
        Tuple of (peak_indices, peak_properties)
    """
    properties = {}
    
    if height is not None:
        properties['height'] = height
    
    if prominence is not None:
        properties['prominence'] = prominence
    
    peaks, properties_out = signal.find_peaks(data, distance=distance, **properties)
    
    return peaks, properties_out


def welch_psd(
    data: NDArray,
    sampling_rate: float = 1.0,
    nperseg: Optional[int] = None
) -> Tuple[NDArray, NDArray]:
    """
    Compute power spectral density using Welch's method.
    
    Args:
        data: Input signal
        sampling_rate: Sampling rate
        nperseg: Length of each segment
        
    Returns:
        Tuple of (frequencies, psd)
    """
    frequencies, psd = signal.welch(data, fs=sampling_rate, nperseg=nperseg)
    return frequencies, psd


def convolve_signal(
    a: NDArray,
    v: NDArray,
    mode: str = 'full'
) -> NDArray:
    """
    Convolve two signals with mode support.
    
    Args:
        a: First signal
        v: Second signal (kernel)
        mode: Convolution mode ('full', 'valid', 'same')
        
    Returns:
        Convolved signal
    """
    return np.convolve(a, v, mode=mode)


def integrate_ode(
    deriv_func: Callable[[float, NDArray], NDArray],
    y0: NDArray,
    t_span: Tuple[float, float],
    t_eval: Optional[NDArray] = None,
    method: str = 'RK45'
) -> Tuple[NDArray, NDArray]:
    """
    Solve ordinary differential equation system.
    
    Args:
        deriv_func: Derivative function dy/dt
        y0: Initial conditions
        t_span: Time span (t_start, t_end)
        t_eval: Time points to evaluate
        method: Integration method
        
    Returns:
        Tuple of (t, y) solution arrays
    """
    solution = integrate.solve_ivp(
        deriv_func,
        t_span,
        y0,
        t_eval=t_eval,
        method=method
    )
    
    return solution.t, solution.y


def cumulative_trapezoid(
    y: NDArray,
    x: Optional[NDArray] = None,
    dx: float = 1.0
) -> NDArray:
    """
    Cumulative integration using trapezoidal rule.
    
    Args:
        y: Values to integrate
        x: x coordinates (if None, assumes uniform spacing)
        dx: Spacing between points
        
    Returns:
        Cumulative integral
    """
    return integrate.cumulative_trapezoid(y, x=x, dx=dx)


def gaussian_filter(
    data: NDArray,
    sigma: float,
    order: int = 0
) -> NDArray:
    """
    Apply Gaussian filter to data.
    
    Args:
        data: Input array
        sigma: Standard deviation for Gaussian kernel
        order: Order of Gaussian (0 for smoothing)
        
    Returns:
        Filtered data
    """
    return signal.gaussian_filter(data, sigma, order=order)


def savgol_filter(
    data: NDArray,
    window_length: int,
    polyorder: int,
    deriv: int = 0
) -> NDArray:
    """
    Savitzky-Golay filter for smoothing and differentiation.
    
    Args:
        data: Input signal
        window_length: Length of filter window (must be odd)
        polyorder: Order of polynomial
        deriv: Derivative order
        
    Returns:
        Filtered signal
    """
    if window_length % 2 == 0:
        raise ValueError("window_length must be odd")
    
    return signal.savgol_filter(data, window_length, polyorder, deriv=deriv)
