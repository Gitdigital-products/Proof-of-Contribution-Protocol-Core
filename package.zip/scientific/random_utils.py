"""
Random Utilities Module
======================

Provides comprehensive random number generation, seeding, and
reproducibility utilities. Built for scientific computing and
machine learning with proper state management.

Author: MiniMax Agent
"""

import numpy as np
import random
from typing import Optional, Tuple, Dict, Any, List, Union
from numpy.typing import NDArray


# ============================================================================
# Global RNG State
# ============================================================================

_global_rng = np.random.default_rng()


def get_rng() -> np.random.Generator:
    """
    Get the global random number generator.
    
    Returns:
        Global numpy random generator
    """
    return _global_rng


def set_rng(seed: Optional[int] = None) -> None:
    """
    Set the global random seed.
    
    Args:
        seed: Random seed (None for random seed)
    """
    global _global_rng
    if seed is None:
        seed = int.from_bytes(np.random.bytes(4), 'big')
    _global_rng = np.random.default_rng(seed)


def get_rng_state() -> Dict[str, Any]:
    """
    Get current RNG state for reproducibility.
    
    Returns:
        Dictionary containing RNG state
    """
    return {
        'random_state': _global_rng.bit_generator.state,
        'numpy_state': np.random.get_state(),
        'python_random_state': random.getstate()
    }


def set_rng_state(state: Dict[str, Any]) -> None:
    """
    Restore RNG state from saved state.
    
    Args:
        state: State dictionary from get_rng_state()
    """
    global _global_rng
    _global_rng.bit_generator.state = state['random_state']
    np.random.set_state(state['numpy_state'])
    random.setstate(state['python_random_state'])


# ============================================================================
# Seeding Utilities
# ============================================================================

def set_seed(
    seed: int,
    deterministic: bool = True,
    benchmark: bool = False
) -> Dict[str, Any]:
    """
    Set random seed for reproducibility across all libraries.
    
    This function seeds NumPy, Python random, and any backend
    libraries (PyTorch, TensorFlow) that might be available.
    
    Args:
        seed: Random seed
        deterministic: Whether to enforce deterministic algorithms
        benchmark: Whether to enable cuDNN benchmarking
        
    Returns:
        Dictionary with seeding information
    """
    info = {
        'seed': seed,
        'deterministic': deterministic,
        'benchmark': benchmark
    }
    
    # Seed NumPy
    np.random.seed(seed)
    global _global_rng
    _global_rng = np.random.default_rng(seed)
    
    # Seed Python random
    random.seed(seed)
    
    # Seed Python's built-in random module
    random.seed(seed)
    
    # Try to seed PyTorch if available
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)
        
        if deterministic:
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = benchmark
            torch.use_deterministic_algorithms(deterministic)
        
        info['pytorch_seeded'] = True
    except ImportError:
        info['pytorch_seeded'] = False
    
    # Try to seed TensorFlow if available
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
        info['tensorflow_seeded'] = True
    except ImportError:
        info['tensorflow_seeded'] = False
    
    # Try to seed JAX if available
    try:
        import jax
        jax.random.PRNGKey(seed)
        info['jax_seeded'] = True
    except ImportError:
        info['jax_seeded'] = False
    
    return info


def get_seed() -> int:
    """
    Get current seed value (or generate new one).
    
    Returns:
        Current seed value
    """
    return int.from_bytes(np.random.bytes(4), 'big')


# ============================================================================
# Random Sampling Functions
# ============================================================================

def sample_uniform(
    low: Union[float, NDArray] = 0.0,
    high: Union[float, NDArray] = 1.0,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from uniform distribution.
    
    Args:
        low: Lower bound (scalar or array)
        high: Upper bound (scalar or array)
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.uniform(low, high, size=size)


def sample_normal(
    loc: float = 0.0,
    scale: float = 1.0,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from normal (Gaussian) distribution.
    
    Args:
        loc: Mean of the distribution
        scale: Standard deviation
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.normal(loc, scale, size=size)


def sample_exponential(
    scale: float = 1.0,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from exponential distribution.
    
    Args:
        scale: Scale parameter (1/lambda)
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.exponential(scale, size=size)


def sample_gamma(
    shape: float,
    scale: float = 1.0,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from gamma distribution.
    
    Args:
        shape: Shape parameter (k)
        scale: Scale parameter (theta)
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.gamma(shape, scale, size=size)


def sample_beta(
    alpha: float,
    beta_param: float,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from beta distribution.
    
    Args:
        alpha: First shape parameter
        beta_param: Second shape parameter
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.beta(alpha, beta_param, size=size)


def sample_poisson(
    lam: float,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from Poisson distribution.
    
    Args:
        lam: Rate parameter (lambda)
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.poisson(lam, size=size)


def sample_binomial(
    n: int,
    p: float,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from binomial distribution.
    
    Args:
        n: Number of trials
        p: Probability of success
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.binomial(n, p, size=size)


def sample_multinomial(
    n: int,
    pvals: NDArray,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Sample from multinomial distribution.
    
    Args:
        n: Number of trials
        pvals: Probabilities for each outcome
        size: Output shape
        
    Returns:
        Random samples
    """
    return _global_rng.multinomial(n, pvals, size=size)


# ============================================================================
# Random Array Generation
# ============================================================================

def rand(
    *size: int
) -> NDArray:
    """
    Generate random floats in [0, 1).
    
    Args:
        *size: Shape of output
        
    Returns:
        Random array
    """
    return _global_rng.random(size=size)


def randn(
    *size: int
) -> NDArray:
    """
    Generate random floats from standard normal.
    
    Args:
        *size: Shape of output
        
    Returns:
        Random array
    """
    return _global_rng.standard_normal(size=size)


def randint(
    low: int,
    high: Optional[int] = None,
    size: Optional[Tuple[int, ...]] = None
) -> NDArray:
    """
    Generate random integers.
    
    Args:
        low: Lower bound (inclusive)
        high: Upper bound (exclusive)
        size: Output shape
        
    Returns:
        Random integer array
    """
    return _global_rng.integers(low, high, size=size, endpoint=False)


def choice(
    a: Union[int, NDArray],
    size: Optional[int] = None,
    replace: bool = True,
    p: Optional[NDArray] = None
) -> Union[int, NDArray]:
    """
    Random choice from array.
    
    Args:
        a: Array to choose from or number of options
        size: Number of samples
        replace: Whether to sample with replacement
        p: Probabilities for each element
        
    Returns:
        Selected element(s)
    """
    return _global_rng.choice(a, size=size, replace=replace, p=p)


def shuffle(x: NDArray, axis: int = 0) -> NDArray:
    """
    Shuffle array in-place along given axis.
    
    Args:
        x: Array to shuffle
        axis: Axis along which to shuffle
        
    Returns:
        Shuffled array (also modifies input)
    """
    if axis == 0:
        _global_rng.shuffle(x)
    else:
        x = np.swapaxes(x, 0, axis)
        _global_rng.shuffle(x)
        x = np.swapaxes(x, 0, axis)
    return x


def permutation(n: Union[int, NDArray]) -> NDArray:
    """
    Return a random permutation.
    
    Args:
        n: If int, return permutation of range(n). If array, shuffle it.
        
    Returns:
        Permutation array
    """
    return _global_rng.permutation(n)


# ============================================================================
# Advanced Sampling
# ============================================================================

def sample_without_replacement(
    n: int,
    k: int,
    method: str = 'partial'
) -> NDArray:
    """
    Sample k items from 0..n-1 without replacement.
    
    Args:
        n: Population size
        k: Number of samples
        method: 'partial' or 'full'
        
    Returns:
        Array of sampled indices
    """
    return _global_rng.choice(n, size=k, replace=False)


def stratified_sample(
    labels: NDArray,
    n_samples: Optional[int] = None,
    random_state: Optional[int] = None
) -> Tuple[NDArray, NDArray]:
    """
    Perform stratified sampling maintaining class ratios.
    
    Args:
        labels: Class labels for each sample
        n_samples: Total number of samples (None for same as input)
        random_state: Random seed
        
    Returns:
        Tuple of (sampled_indices, sampled_labels)
    """
    if random_state is not None:
        rng = np.random.default_rng(random_state)
    else:
        rng = _global_rng
    
    unique_labels = np.unique(labels)
    n_samples_per_class = {}
    
    for label in unique_labels:
        mask = labels == label
        n_class = np.sum(mask)
        
        if n_samples is not None:
            n_select = max(1, int(np.round(n_class * n_samples / len(labels))))
            n_select = min(n_select, n_class)
        else:
            n_select = n_class
        
        indices = np.where(mask)[0]
        sampled = rng.choice(indices, size=n_select, replace=False)
        n_samples_per_class[label] = sampled
    
    # Combine all sampled indices
    all_indices = np.concatenate(list(n_samples_per_class.values()))
    rng.shuffle(all_indices)
    
    return all_indices, labels[all_indices]


def bootstrap_sample(
    data: NDArray,
    n_bootstrap: int = 1000,
    statistic: Callable[[NDArray], float] = np.mean,
    confidence_level: float = 0.95
) -> Tuple[float, float, NDArray]:
    """
    Bootstrap confidence interval estimation.
    
    Args:
        data: Input data array
        n_bootstrap: Number of bootstrap samples
        statistic: Statistic to compute
        confidence_level: Confidence level for interval
        
    Returns:
        Tuple of (statistic_value, ci_half_width, bootstrap_statistics)
    """
    bootstrap_stats = np.zeros(n_bootstrap)
    
    for i in range(n_bootstrap):
        sample = _global_rng.choice(data, size=len(data), replace=True)
        bootstrap_stats[i] = statistic(sample)
    
    stat_value = statistic(data)
    alpha = 1 - confidence_level
    ci_lower = np.percentile(bootstrap_stats, alpha / 2 * 100)
    ci_upper = np.percentile(bootstrap_stats, (1 - alpha / 2) * 100)
    
    return stat_value, (ci_upper - ci_lower) / 2, bootstrap_stats


def stratified_bootstrap(
    data: NDArray,
    labels: NDArray,
    n_bootstrap: int = 1000,
    statistic: Callable[[NDArray], float] = np.mean
) -> Tuple[NDArray, NDArray]:
    """
    Stratified bootstrap sampling.
    
    Args:
        data: Input data
        labels: Class labels
        n_bootstrap: Number of bootstrap samples
        statistic: Statistic to compute
        
    Returns:
        Tuple of (original_stats, bootstrap_stats)
    """
    original_stats = statistic(data)
    bootstrap_stats = np.zeros(n_bootstrap)
    
    unique_labels = np.unique(labels)
    
    for i in range(n_bootstrap):
        sample_indices = []
        
        for label in unique_labels:
            mask = labels == label
            indices = np.where(mask)[0]
            sampled = _global_rng.choice(indices, size=len(indices), replace=True)
            sample_indices.extend(sampled)
        
        sample_data = data[sample_indices]
        bootstrap_stats[i] = statistic(sample_data)
    
    return original_stats, bootstrap_stats


# ============================================================================
# Reproducibility Helpers
# ============================================================================

class SeedContext:
    """
    Context manager for temporary seed setting.
    
    Example:
        with SeedContext(42):
            x = sample_normal()  # Uses seed 42
        # Original RNG state is restored
    """
    
    def __init__(self, seed: int):
        self.seed = seed
        self.previous_state = None
    
    def __enter__(self):
        self.previous_state = get_rng_state()
        set_seed(self.seed)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        set_rng_state(self.previous_state)


class RNGStream:
    """
    Independent random number stream for parallel processing.
    
    Example:
        stream1 = RNGStream(seed=42)
        stream2 = RNGStream(seed=123)
        
        x = stream1.sample_normal()
        y = stream2.sample_normal()
    """
    
    def __init__(self, seed: Optional[int] = None):
        if seed is None:
            seed = get_seed()
        self.rng = np.random.default_rng(seed)
    
    def uniform(self, low: float = 0.0, high: float = 1.0, size: Optional[Tuple] = None):
        return self.rng.uniform(low, high, size=size)
    
    def normal(self, loc: float = 0.0, scale: float = 1.0, size: Optional[Tuple] = None):
        return self.rng.normal(loc, scale, size=size)
    
    def integers(self, low: int, high: Optional[int] = None, size: Optional[Tuple] = None):
        return self.rng.integers(low, high, size=size, endpoint=False)
    
    def choice(self, a: Union[int, NDArray], size: Optional[int] = None, replace: bool = True):
        return self.rng.choice(a, size=size, replace=replace)
    
    def shuffle(self, x: NDArray):
        self.rng.shuffle(x)
        return x
    
    def permutation(self, n: Union[int, NDArray]):
        return self.rng.permutation(n)


# ============================================================================
# Random Matrix Generation
# ============================================================================

def random_matrix(
    shape: Tuple[int, ...],
    density: float = 1.0,
    format: str = 'dense',
    random_state: Optional[int] = None
) -> NDArray:
    """
    Generate random matrix with specified density.
    
    Args:
        shape: Matrix shape
        density: Fraction of non-zero elements
        format: 'dense' or 'sparse'
        random_state: Random seed
        
    Returns:
        Random matrix
    """
    if random_state is not None:
        rng = np.random.default_rng(random_state)
    else:
        rng = _global_rng
    
    if format == 'dense':
        if density == 1.0:
            return rng.random(shape)
        else:
            mask = rng.random(shape) < density
            return rng.random(shape) * mask
    else:
        raise NotImplementedError("Sparse format not yet implemented")


def random_orthogonal_matrix(
    n: int,
    seed: Optional[int] = None
) -> NDArray:
    """
    Generate random orthogonal matrix.
    
    Args:
        n: Matrix dimension
        seed: Random seed
        
    Returns:
        Orthogonal matrix (n, n)
    """
    if seed is not None:
        rng = np.random.default_rng(seed)
    else:
        rng = _global_rng
    
    H = rng.standard_normal((n, n))
    Q, R = np.linalg.qr(H)
    return Q


def random_symmetric_matrix(
    n: int,
    seed: Optional[int] = None
) -> NDArray:
    """
    Generate random symmetric matrix.
    
    Args:
        n: Matrix dimension
        seed: Random seed
        
    Returns:
        Symmetric matrix (n, n)
    """
    if seed is not None:
        rng = np.random.default_rng(seed)
    else:
        rng = _global_rng
    
    A = rng.standard_normal((n, n))
    return (A + A.T) / 2


def random_positive_definite_matrix(
    n: int,
    seed: Optional[int] = None
) -> NDArray:
    """
    Generate random positive definite matrix.
    
    Args:
        n: Matrix dimension
        seed: Random seed
        
    Returns:
        Positive definite matrix (n, n)
    """
    if seed is not None:
        rng = np.random.default_rng(seed)
    else:
        rng = _global_rng
    
    A = rng.standard_normal((n, n))
    return A @ A.T + np.eye(n)  # Ensure positive definite
