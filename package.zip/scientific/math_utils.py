"""
Math Utilities Module
=====================

Provides pure mathematical helpers including activation functions,
transforms, and numerical utilities. Designed for machine learning
and scientific computing with numerical stability.

Author: MiniMax Agent
"""

import numpy as np
from scipy import special
from typing import Union, Tuple, Optional, Callable, List
from numpy.typing import NDArray


# ============================================================================
# Activation Functions
# ============================================================================

def sigmoid(x: NDArray) -> NDArray:
    """
    Sigmoid (logistic) activation function.
    
    sigmoid(x) = 1 / (1 + exp(-x))
    
    Numerically stable implementation to prevent overflow.
    
    Args:
        x: Input array
        
    Returns:
        Sigmoid activated values in range (0, 1)
    """
    return special.expit(x)


def sigmoid_derivative(x: NDArray) -> NDArray:
    """
    Derivative of sigmoid function.
    
    d/dx sigmoid(x) = sigmoid(x) * (1 - sigmoid(x))
    
    Args:
        x: Input array (should be sigmoid outputs)
        
    Returns:
        Gradient values
    """
    s = sigmoid(x) if np.max(np.abs(x)) > 1 else special.expit(x)
    return s * (1 - s)


def relu(x: NDArray, alpha: float = 0.0) -> NDArray:
    """
    Rectified Linear Unit activation.
    
    relu(x) = max(0, x)
    
    Supports Leaky ReLU when alpha > 0.
    
    Args:
        x: Input array
        alpha: Leakage parameter for Leaky ReLU
        
    Returns:
        ReLU activated values
    """
    return np.where(x > 0, x, alpha * x)


def relu_derivative(x: NDArray, alpha: float = 0.0) -> NDArray:
    """
    Derivative of ReLU function.
    
    Args:
        x: Input array
        alpha: Leakage parameter
        
    Returns:
        Gradient values (1 where x > 0, alpha otherwise)
    """
    return np.where(x > 0, 1.0, alpha)


def leaky_relu(x: NDArray, alpha: float = 0.01) -> NDArray:
    """
    Leaky Rectified Linear Unit.
    
    Args:
        x: Input array
        alpha: Negative slope
        
    Returns:
        Leaky ReLU values
    """
    return relu(x, alpha=alpha)


def elu(x: NDArray, alpha: float = 1.0) -> NDArray:
    """
    Exponential Linear Unit.
    
    elu(x) = x if x > 0, else alpha * (exp(x) - 1)
    
    Args:
        x: Input array
        alpha: Scale for negative values
        
    Returns:
        ELU activated values
    """
    return np.where(x > 0, x, alpha * (np.exp(x) - 1))


def selu(x: NDArray) -> NDArray:
    """
    Scaled Exponential Linear Unit.
    
    Self-normalizing properties for neural networks.
    
    Args:
        x: Input array
        
    Returns:
        SELU activated values
    """
    alpha = 1.6732632423543772848170429916717
    scale = 1.0507009873554804934193349852946
    return scale * elu(x, alpha=alpha)


def tanh(x: NDArray) -> NDArray:
    """
    Hyperbolic tangent activation.
    
    tanh(x) = (exp(x) - exp(-x)) / (exp(x) + exp(-x))
    
    Args:
        x: Input array
        
    Returns:
        Tanh activated values in range (-1, 1)
    """
    return np.tanh(x)


def tanh_derivative(x: NDArray) -> NDArray:
    """
    Derivative of tanh function.
    
    d/dx tanh(x) = 1 - tanh²(x)
    
    Args:
        x: Input array
        
    Returns:
        Gradient values
    """
    return 1 - np.tanh(x) ** 2


def softmax(x: NDArray, axis: int = -1) -> NDArray:
    """
    Softmax activation function.
    
    softmax(x_i) = exp(x_i) / sum(exp(x_j))
    
    Numerically stable implementation.
    
    Args:
        x: Input array
        axis: Axis along which to compute softmax
        
    Returns:
        Probability values summing to 1
    """
    x_max = np.max(x, axis=axis, keepdims=True)
    exp_x = np.exp(x - x_max)
    return exp_x / np.sum(exp_x, axis=axis, keepdims=True)


def log_softmax(x: NDArray, axis: int = -1) -> NDArray:
    """
    Log-softmax activation (numerically stable).
    
    Args:
        x: Input array
        axis: Axis along which to compute
        
    Returns:
        Log-probability values
    """
    x_max = np.max(x, axis=axis, keepdims=True)
    return x - x_max - np.log(np.sum(np.exp(x - x_max), axis=axis, keepdims=True))


def swish(x: NDArray, beta: float = 1.0) -> NDArray:
    """
    Swish activation function.
    
    swish(x) = x * sigmoid(beta * x)
    
    Args:
        x: Input array
        beta: Learnable parameter (default: 1.0)
        
    Returns:
        Swish activated values
    """
    return x * sigmoid(beta * x)


def mish(x: NDArray) -> NDArray:
    """
    Mish activation function.
    
    mish(x) = x * tanh(softplus(x))
    
    where softplus(x) = log(1 + exp(x))
    
    Args:
        x: Input array
        
    Returns:
        Mish activated values
    """
    return x * np.tanh(softplus(x))


def softplus(x: NDArray) -> NDArray:
    """
    Softplus activation.
    
    softplus(x) = log(1 + exp(x))
    
    Args:
        x: Input array
        
    Returns:
        Softplus activated values
    """
    return np.log(1 + np.exp(x))


def gelu(x: NDArray, approximate: bool = True) -> NDArray:
    """
    Gaussian Error Linear Unit (GELU).
    
    gelu(x) = x * Phi(x) where Phi is the normal CDF
    
    Args:
        x: Input array
        approximate: Use approximation for speed
        
    Returns:
        GELU activated values
    """
    if approximate:
        # Approximation from paper
        return 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x ** 3)))
    else:
        # Exact version using error function
        return x * (1 + special.erf(x / np.sqrt(2))) / 2


def maxout(x: NDArray, axis: int = 1) -> NDArray:
    """
    Maxout activation.
    
    Takes maximum across consecutive feature planes.
    
    Args:
        x: Input array
        axis: Axis along which to take max
        
    Returns:
        Maxout activated values
    """
    return np.max(x, axis=axis)


# ============================================================================
# Loss Function Helpers
# ============================================================================

def cross_entropy_loss(
    predictions: NDArray,
    targets: NDArray,
    reduction: str = 'mean'
) -> float:
    """
    Cross-entropy loss for classification.
    
    Args:
        predictions: Predicted logits or probabilities
        targets: Ground truth labels (one-hot or indices)
        reduction: 'mean', 'sum', or 'none'
        
    Returns:
        Loss value
    """
    eps = 1e-7
    
    # If targets are indices, convert to one-hot
    if targets.ndim == 1:
        n_classes = predictions.shape[-1]
        targets = np.eye(n_classes)[targets]
    
    # Compute cross-entropy
    log_preds = np.log(predictions + eps)
    loss = -np.sum(targets * log_preds, axis=-1)
    
    if reduction == 'mean':
        return np.mean(loss)
    elif reduction == 'sum':
        return np.sum(loss)
    else:
        return loss


def focal_loss(
    predictions: NDArray,
    targets: NDArray,
    gamma: float = 2.0,
    alpha: Optional[float] = None,
    reduction: str = 'mean'
) -> float:
    """
    Focal loss for addressing class imbalance.
    
    focal_loss = -alpha * (1 - p_t)^gamma * log(p_t)
    
    Args:
        predictions: Predicted probabilities
        targets: Ground truth (one-hot)
        gamma: Focusing parameter
        alpha: Class weighting factor
        reduction: 'mean', 'sum', or 'none'
        
    Returns:
        Loss value
    """
    eps = 1e-7
    p_t = np.sum(predictions * targets, axis=-1, keepdims=True)
    p_t = np.clip(p_t, eps, 1 - eps)
    
    focal_weight = (1 - p_t) ** gamma
    
    if alpha is not None:
        alpha_t = np.sum(alpha * targets, axis=-1, keepdims=True)
        focal_weight = alpha_t * focal_weight
    
    loss = -focal_weight * np.log(p_t)
    loss = np.squeeze(loss, axis=-1)
    
    if reduction == 'mean':
        return np.mean(loss)
    elif reduction == 'sum':
        return np.sum(loss)
    else:
        return loss


def huber_loss(
    predictions: NDArray,
    targets: NDArray,
    delta: float = 1.0,
    reduction: str = 'mean'
) -> float:
    """
    Huber loss (smooth L1 loss).
    
    huber(x) = 0.5 * x² if |x| <= delta, else delta * |x| - 0.5 * delta²
    
    Args:
        predictions: Predicted values
        targets: Ground truth values
        delta: Threshold between L1 and L2
        reduction: 'mean', 'sum', or 'none'
        
    Returns:
        Loss value
    """
    diff = np.abs(predictions - targets)
    loss = np.where(
        diff <= delta,
        0.5 * diff ** 2,
        delta * diff - 0.5 * delta ** 2
    )
    
    if reduction == 'mean':
        return np.mean(loss)
    elif reduction == 'sum':
        return np.sum(loss)
    else:
        return loss


def cosine_similarity(
    a: NDArray,
    b: NDArray,
    axis: int = -1,
    eps: float = 1e-8
) -> NDArray:
    """
    Compute cosine similarity between vectors.
    
    Args:
        a: First array
        b: Second array
        axis: Axis for dot product
        eps: Small constant for stability
        
    Returns:
        Cosine similarity values in range [-1, 1]
    """
    a_norm = np.linalg.norm(a, axis=axis, keepdims=True)
    b_norm = np.linalg.norm(b, axis=axis, keepdims=True)
    
    return np.sum(a * b, axis=axis) / (a_norm * b_norm + eps)


# ============================================================================
# Mathematical Transforms
# ============================================================================

def fft(x: NDArray, axis: int = -1) -> NDArray:
    """
    Fast Fourier Transform.
    
    Args:
        x: Input signal
        axis: Axis along which to compute FFT
        
    Returns:
        Fourier coefficients
    """
    return np.fft.fft(x, axis=axis)


def ifft(x: NDArray, axis: int = -1) -> NDArray:
    """
    Inverse Fast Fourier Transform.
    
    Args:
        x: Fourier coefficients
        axis: Axis along which to compute
        
    Returns:
        Reconstructed signal
    """
    return np.fft.ifft(x, axis=axis)


def fft2(x: NDArray, axes: Tuple[int, int] = (-2, -1)) -> NDArray:
    """
    2D FFT.
    
    Args:
        x: Input 2D array
        axes: Axes for transformation
        
    Returns:
        2D Fourier coefficients
    """
    return np.fft.fft2(x, axes=axes)


def dct(x: NDArray, type: int = 2, axis: int = -1) -> NDArray:
    """
    Discrete Cosine Transform.
    
    Args:
        x: Input array
        type: DCT type (1, 2, 3, or 4)
        axis: Axis along which to compute
        
    Returns:
        DCT coefficients
    """
    return special.dct(x, type=type, axis=axis)


def wavelet_transform(
    x: NDArray,
    wavelet: str = 'db4',
    level: Optional[int] = None
) -> List[NDArray]:
    """
    Wavelet decomposition.
    
    Args:
        x: Input signal
        wavelet: Wavelet name (e.g., 'db4', 'haar', 'sym4')
        level: Decomposition level
        
    Returns:
        List of wavelet coefficients
    """
    import pywt
    return pywt.wavedec(x, wavelet, level=level)


# ============================================================================
# Numerical Utilities
# ============================================================================

def safe_divide(
    numerator: NDArray,
    denominator: NDArray,
    epsilon: float = 1e-8
) -> NDArray:
    """
    Numerically safe division.
    
    Args:
        numerator: Numerator array
        denominator: Denominator array
        epsilon: Small constant to prevent division by zero
        
    Returns:
        Division result
    """
    return numerator / (denominator + epsilon)


def log_sum_exp(arr: NDArray, axis: int = None) -> NDArray:
    """
    Log-Sum-Exp with numerical stability.
    
    Computes log(sum(exp(arr))) in a numerically stable way.
    
    Args:
        arr: Input array
        axis: Axis along which to compute
        
    Returns:
        Log-sum-exp value
    """
    arr_max = np.max(arr, axis=axis, keepdims=True)
    return arr_max + np.log(np.sum(np.exp(arr - arr_max), axis=axis, keepdims=True) + 1e-8)


def clamp(
    x: NDArray,
    min_val: Optional[float] = None,
    max_val: Optional[float] = None
) -> NDArray:
    """
    Clamp values to range.
    
    Args:
        x: Input array
        min_val: Minimum value
        max_val: Maximum value
        
    Returns:
        Clamped array
    """
    return np.clip(x, min_val, max_val)


def lerp(
    a: Union[float, NDArray],
    b: Union[float, NDArray],
    t: Union[float, NDArray]
) -> Union[float, NDArray]:
    """
    Linear interpolation.
    
    lerp(a, b, t) = a + (b - a) * t
    
    Args:
        a: Start value
        b: End value
        t: Interpolation parameter [0, 1]
        
    Returns:
        Interpolated value
    """
    return a + (b - a) * t


def inv_lerp(
    a: float,
    b: float,
    v: NDArray
) -> NDArray:
    """
    Inverse linear interpolation.
    
    Finds t such that lerp(a, b, t) = v
    
    Args:
        a: Start value
        b: End value
        v: Value to interpolate
        
    Returns:
        Interpolation parameter
    """
    return (v - a) / (b - a + 1e-8)


def remap(
    value: NDArray,
    in_min: float,
    in_max: float,
    out_min: float,
    out_max: float
) -> NDArray:
    """
    Remap value from one range to another.
    
    Args:
        value: Input value
        in_min: Input range minimum
        in_max: Input range maximum
        out_min: Output range minimum
        out_max: Output range maximum
        
    Returns:
        Remapped value
    """
    t = (value - in_min) / (in_max - in_min + 1e-8)
    return lerp(out_min, out_max, t)


def sign(x: NDArray, epsilon: float = 1e-8) -> NDArray:
    """
    Sign function with smooth transition near zero.
    
    Args:
        x: Input array
        epsilon: Smoothing parameter
        
    Returns:
        Sign values (-1, 0, or 1)
    """
    return np.where(np.abs(x) < epsilon, 0, np.sign(x))


def smoothstep(
    edge0: float,
    edge1: float,
    x: NDArray
) -> NDArray:
    """
    Smoothstep function (Sigmoid curve).
    
    Args:
        edge0: Lower edge
        edge1: Upper edge
        x: Input value
        
    Returns:
        Smoothed values in range [0, 1]
    """
    t = clamp((x - edge0) / (edge1 - edge0 + 1e-8), 0, 1)
    return t * t * (3 - 2 * t)


def gaussian(
    x: NDArray,
    mu: float = 0.0,
    sigma: float = 1.0
) -> NDArray:
    """
    Gaussian function.
    
    Args:
        x: Input value
        mu: Mean
        sigma: Standard deviation
        
    Returns:
        Gaussian values
    """
    return np.exp(-0.5 * ((x - mu) / sigma) ** 2) / (sigma * np.sqrt(2 * np.pi))


def sinc(x: NDArray, epsilon: float = 1e-8) -> NDArray:
    """
    Sinc function.
    
    sinc(x) = sin(x) / x
    
    Args:
        x: Input array
        epsilon: Small constant for stability
        
    Returns:
        Sinc values
    """
    return np.where(np.abs(x) < epsilon, 1.0, np.sin(x) / x)


# ============================================================================
# Polynomial Operations
# ============================================================================

def polyval(coeffs: List[float], x: NDArray) -> NDArray:
    """
    Evaluate polynomial at given points.
    
    Args:
        coeffs: Polynomial coefficients (highest degree first)
        x: Input values
        
    Returns:
        Polynomial values
    """
    return np.polyval(coeffs, x)


def polyfit(
    x: NDArray,
    y: NDArray,
    degree: int
) -> Tuple[List[float], Dict[str, Any]]:
    """
    Fit polynomial to data.
    
    Args:
        x: x values
        y: y values
        degree: Polynomial degree
        
    Returns:
        Tuple of (coefficients, residuals)
    """
    coeffs, residuals, _, _, _ = np.polyfit(x, y, degree, full=True)
    return coeffs, {'residuals': residuals}


def polyder(coeffs: List[float]) -> List[float]:
    """
    Compute polynomial derivative.
    
    Args:
        coeffs: Polynomial coefficients
        
    Returns:
        Derivative coefficients
    """
    return np.polyder(coeffs).tolist()


def polyint(coeffs: List[float], c: float = 0.0) -> List[float]:
    """
    Compute polynomial integral.
    
    Args:
        coeffs: Polynomial coefficients
        c: Integration constant
        
    Returns:
        Integral coefficients
    """
    return np.polyint(coeffs, c=c).tolist()


# ============================================================================
# Distance Functions
# ============================================================================

def euclidean_distance(a: NDArray, b: NDArray) -> float:
    """
    Euclidean distance between points.
    
    Args:
        a: First point
        b: Second point
        
    Returns:
        Distance value
    """
    return np.linalg.norm(a - b)


def manhattan_distance(a: NDArray, b: NDArray) -> float:
    """
    Manhattan (city block) distance.
    
    Args:
        a: First point
        b: Second point
        
    Returns:
        Distance value
    """
    return np.sum(np.abs(a - b))


def chebyshev_distance(a: NDArray, b: NDArray) -> float:
    """
    Chebyshev (chessboard) distance.
    
    Args:
        a: First point
        b: Second point
        
    Returns:
        Distance value
    """
    return np.max(np.abs(a - b))


def minkowski_distance(a: NDArray, b: NDArray, p: float = 2.0) -> float:
    """
    Minkowski distance.
    
    Args:
        a: First point
        b: Second point
        p: Order of norm (1=Manhattan, 2=Euclidean, inf=Chebyshev)
        
    Returns:
        Distance value
    """
    return np.sum(np.abs(a - b) ** p) ** (1/p)


def mahalanobis_distance(
    x: NDArray,
    mean: NDArray,
    cov: NDArray
) -> float:
    """
    Mahalanobis distance.
    
    Args:
        x: Point to evaluate
        mean: Distribution mean
        cov: Covariance matrix
        
    Returns:
        Distance value
    """
    diff = x - mean
    cov_inv = np.linalg.inv(cov + np.eye(len(cov)) * 1e-6)
    return np.sqrt(diff @ cov_inv @ diff.T)
