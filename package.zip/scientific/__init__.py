"""
Tinkerflow-AI Scientific Stack
==============================

A production-grade scientific computing layer providing clean abstractions
for NumPy, SciPy, and mathematical operations. Built for reproducibility,
auditability, and zero-knowledge aligned research.

Author: MiniMax Agent
Version: 1.0.0
"""

from scientific.numpy_ops import *
from scientific.scipy_ops import *
from scientific.linalg import *
from scientific.stats import *
from scientific.math_utils import *
from scientific.random_utils import *

__version__ = "1.0.0"
__author__ = "MiniMax Agent"

__all__ = [
    # NumPy operations
    "broadcast_arrays",
    "stack_arrays", 
    "chunk_data",
    "normalize",
    "denormalize",
    # SciPy operations
    "optimize",
    "interpolate",
    "signal_process",
    "filter_signal",
    # Linear algebra
    "solve_linear",
    "eigen_decomposition", 
    "svd_decomposition",
    "matrix_power",
    # Statistics
    "compute_mean",
    "compute_std",
    "compute_covariance",
    "hypothesis_test",
    "confidence_interval",
    # Math utilities
    "safe_divide",
    "log_sum_exp",
    "softmax",
    "sigmoid",
    "relu",
    # Random utilities
    "set_seed",
    "get_rng_state",
    "sample_uniform",
    "sample_normal",
    "sample_gamma",
]
