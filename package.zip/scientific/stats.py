"""
Statistics Module
=================

Provides comprehensive statistical operations including probability
distributions, hypothesis testing, confidence intervals, and
descriptive statistics. Built for reproducibility and auditability.

Author: MiniMax Agent
"""

import numpy as np
from scipy import stats as scipy_stats
from scipy.special import gamma, beta as beta_func, erf, erfinv
from typing import Union, Tuple, Optional, List, Dict, Callable
from numpy.typing import NDArray


def compute_mean(
    data: NDArray,
    axis: Optional[int] = None,
    weights: Optional[NDArray] = None,
    keepdims: bool = False
) -> Union[float, NDArray]:
    """
    Compute weighted mean with axis support.
    
    Args:
        data: Input array
        axis: Axis along which to compute mean
        weights: Optional weights for each element
        keepdims: Whether to keep dimensions
        
    Returns:
        Mean value(s)
    """
    if weights is not None:
        weights = np.broadcast_to(weights, data.shape)
        weighted_sum = np.sum(data * weights, axis=axis)
        weight_sum = np.sum(weights, axis=axis)
        return weighted_sum / weight_sum
    
    return np.mean(data, axis=axis, keepdims=keepdims)


def compute_variance(
    data: NDArray,
    axis: Optional[int] = None,
    ddof: int = 0,
    weights: Optional[NDArray] = None
) -> Union[float, NDArray]:
    """
    Compute variance with optional degrees of freedom adjustment.
    
    Args:
        data: Input array
        axis: Axis along which to compute variance
        ddof: Delta degrees of freedom (0 for population, 1 for sample)
        weights: Optional weights
        
    Returns:
        Variance value(s)
    """
    mean = compute_mean(data, axis=axis, weights=weights)
    
    if weights is not None:
        weights = np.broadcast_to(weights, data.shape)
        squared_diff = (data - mean) ** 2
        return np.sum(weights * squared_diff, axis=axis) / np.sum(weights, axis=axis)
    
    return np.var(data, axis=axis, ddof=ddof)


def compute_std(
    data: NDArray,
    axis: Optional[int] = None,
    ddof: int = 0
) -> Union[float, NDArray]:
    """
    Compute standard deviation.
    
    Args:
        data: Input array
        axis: Axis along which to compute
        ddof: Delta degrees of freedom
        
    Returns:
        Standard deviation value(s)
    """
    return np.sqrt(compute_variance(data, axis=axis, ddof=ddof))


def compute_covariance(
    x: NDArray,
    y: Optional[NDArray] = None,
    rowvar: bool = True,
    ddof: int = 1
) -> NDArray:
    """
    Compute covariance matrix.
    
    Args:
        x: Input array (n features) or (n samples, n features)
        y: Optional second array
        rowvar: If True, each row is a variable; if False, each column
        ddof: Delta degrees of freedom
        
    Returns:
        Covariance matrix
    """
    if y is not None:
        x = np.column_stack([x, y])
    
    return np.cov(x, rowvar=rowvar, ddof=ddof)


def compute_correlation(
    x: NDArray,
    y: Optional[NDArray] = None,
    method: str = 'pearson'
) -> Union[float, NDArray]:
    """
    Compute correlation coefficient(s).
    
    Args:
        x: First array
        y: Optional second array
        method: 'pearson', 'spearman', or 'kendall'
        
    Returns:
        Correlation coefficient(s)
    """
    if y is not None:
        x = x.flatten()
        y = y.flatten()
        
        if method == 'pearson':
            return np.corrcoef(x, y)[0, 1]
        elif method == 'spearman':
            return scipy_stats.spearmanr(x, y)[0]
        elif method == 'kendall':
            return scipy_stats.kendalltau(x, y)[0]
        else:
            raise ValueError(f"Unknown method: {method}")
    
    # Correlation matrix for multiple variables
    if method == 'pearson':
        return np.corrcoef(x)
    elif method == 'spearman':
        return scipy_stats.spearmanr(x, axis=0)[0]
    elif method == 'kendall':
        return scipy_stats.kendalltau(x, axis=0)[0]
    else:
        raise ValueError(f"Unknown method: {method}")


def compute_percentiles(
    data: NDArray,
    percentiles: Union[float, List[float]],
    axis: Optional[int] = None,
    method: str = 'linear'
) -> NDArray:
    """
    Compute percentiles of data.
    
    Args:
        data: Input array
        percentiles: Percentile value(s) to compute (0-100)
        axis: Axis along which to compute
        method: Interpolation method
        
    Returns:
        Percentile value(s)
    """
    percentiles = np.atleast_1d(percentiles)
    return np.percentile(data, percentiles, axis=axis, method=method)


def compute_iqr(
    data: NDArray,
    axis: Optional[int] = None
) -> Union[float, NDArray]:
    """
    Compute interquartile range (IQR).
    
    Args:
        data: Input array
        axis: Axis along which to compute
        
    Returns:
        IQR value(s)
    """
    q75 = np.percentile(data, 75, axis=axis)
    q25 = np.percentile(data, 25, axis=axis)
    return q75 - q25


def compute_skewness(
    data: NDArray,
    axis: Optional[int] = None,
    fisher: bool = True
) -> Union[float, NDArray]:
    """
    Compute skewness (measure of asymmetry).
    
    Args:
        data: Input array
        axis: Axis along which to compute
        fisher: If True, Fisher's definition (0 for normal); else Pearson's
        
    Returns:
        Skewness value(s)
    """
    mean = compute_mean(data, axis=axis)
    std = compute_std(data, axis=axis, ddof=1)
    
    # Handle zero standard deviation
    std = np.where(std == 0, 1.0, std)
    
    n = data.shape[axis] if axis is not None else data.size
    diff = data - mean
    
    if axis is not None:
        diff = np.moveaxis(diff, axis, -1)
        moment = np.mean(diff ** 3, axis=-1)
        skew = moment / (std ** 3)
    else:
        skew = np.mean(diff ** 3) / (std ** 3)
    
    if fisher:
        return skew
    else:
        # Pearson's skewness
        return 3 * (mean - np.median(data)) / std


def compute_kurtosis(
    data: NDArray,
    axis: Optional[int] = None,
    fisher: bool = True
) -> Union[float, NDArray]:
    """
    Compute kurtosis (measure of tailedness).
    
    Args:
        data: Input array
        axis: Axis along which to compute
        fisher: If True, Fisher's definition (0 for normal); else Pearson's
        
    Returns:
        Kurtosis value(s)
    """
    mean = compute_mean(data, axis=axis)
    std = compute_std(data, axis=axis, ddof=1)
    
    # Handle zero standard deviation
    std = np.where(std == 0, 1.0, std)
    
    diff = data - mean
    
    if axis is not None:
        diff = np.moveaxis(diff, axis, -1)
        moment = np.mean(diff ** 4, axis=-1)
        kurt = moment / (std ** 4)
    else:
        kurt = np.mean(diff ** 4) / (std ** 4)
    
    if fisher:
        return kurt - 3  # Excess kurtosis
    else:
        return kurt


def hypothesis_test(
    x: NDArray,
    y: Optional[NDArray] = None,
    test: str = 'ttest',
    alternative: str = 'two-sided',
    alpha: float = 0.05
) -> Dict[str, Any]:
    """
    Perform hypothesis test.
    
    Args:
        x: First sample or population parameter
        y: Second sample (for two-sample tests)
        test: Test type ('ttest', 'ztest', 'chisquare', 'ks', 'mannwhitneyu', 'wilcoxon')
        alternative: Alternative hypothesis ('two-sided', 'less', 'greater')
        alpha: Significance level
        
    Returns:
        Dictionary with test results
    """
    result = {
        'test': test,
        'alternative': alternative,
        'alpha': alpha,
        'reject': False,
        'p_value': None,
        'statistic': None,
        'ci': None
    }
    
    if test == 'ttest':
        if y is None:
            # One-sample t-test
            stat, p = scipy_stats.ttest_1samp(x, 0)
        else:
            # Two-sample t-test
            stat, p = scipy_stats.ttest_ind(x, y, equal_var=False)
        result['statistic'] = stat
        result['p_value'] = p
        
    elif test == 'ztest':
        from statsmodels.stats.weightstats import ztest
        if y is None:
            stat, p = ztest(x)
        else:
            stat, p = ztest(x, y)
        result['statistic'] = stat
        result['p_value'] = p
        
    elif test == 'chisquare':
        stat, p = scipy_stats.chisquare(x)
        result['statistic'] = stat
        result['p_value'] = p
        
    elif test == 'ks':
        if y is None:
            stat, p = scipy_stats.kstest(x, 'norm')
        else:
            stat, p = scipy_stats.ks_2samp(x, y)
        result['statistic'] = stat
        result['p_value'] = p
        
    elif test == 'mannwhitneyu':
        stat, p = scipy_stats.mannwhitneyu(x, y, alternative=alternative)
        result['statistic'] = stat
        result['p_value'] = p
        
    elif test == 'wilcoxon':
        stat, p = scipy_stats.wilcoxon(x, y, alternative=alternative)
        result['statistic'] = stat
        result['p_value'] = p
    
    result['reject'] = result['p_value'] < alpha
    
    return result


def confidence_interval(
    data: NDArray,
    confidence: float = 0.95,
    method: str = 'normal'
) -> Tuple[float, float]:
    """
    Compute confidence interval for the mean.
    
    Args:
        data: Input sample
        confidence: Confidence level (0-1)
        method: 'normal', 't', or 'bootstrap'
        
    Returns:
        Tuple of (lower_bound, upper_bound)
    """
    mean = np.mean(data)
    se = scipy_stats.sem(data)
    n = len(data)
    
    if method == 'normal':
        z = scipy_stats.norm.ppf((1 + confidence) / 2)
        return mean - z * se, mean + z * se
    
    elif method == 't':
        df = n - 1
        t = scipy_stats.t.ppf((1 + confidence) / 2, df)
        return mean - t * se, mean + t * se
    
    elif method == 'bootstrap':
        # Bootstrap confidence interval
        n_bootstrap = 10000
        bootstrap_means = []
        for _ in range(n_bootstrap):
            sample = np.random.choice(data, size=n, replace=True)
            bootstrap_means.append(np.mean(sample))
        
        alpha = 1 - confidence
        lower = np.percentile(bootstrap_means, alpha / 2 * 100)
        upper = np.percentile(bootstrap_means, (1 - alpha / 2) * 100)
        return lower, upper
    
    else:
        raise ValueError(f"Unknown method: {method}")


def normal_distribution_pdf(
    x: NDArray,
    mu: float = 0.0,
    sigma: float = 1.0
) -> NDArray:
    """
    Normal (Gaussian) probability density function.
    
    Args:
        x: Input values
        mu: Mean parameter
        sigma: Standard deviation parameter
        
    Returns:
        PDF values
    """
    return (1 / (sigma * np.sqrt(2 * np.pi))) * np.exp(-0.5 * ((x - mu) / sigma) ** 2)


def normal_distribution_cdf(
    x: NDArray,
    mu: float = 0.0,
    sigma: float = 1.0
) -> NDArray:
    """
    Normal cumulative distribution function.
    
    Args:
        x: Input values
        mu: Mean parameter
        sigma: Standard deviation parameter
        
    Returns:
        CDF values
    """
    z = (x - mu) / sigma
    return 0.5 * (1 + erf(z / np.sqrt(2)))


def sample_normal(
    size: int,
    mu: float = 0.0,
    sigma: float = 1.0
) -> NDArray:
    """
    Sample from normal distribution.
    
    Args:
        size: Number of samples
        mu: Mean parameter
        sigma: Standard deviation parameter
        
    Returns:
        Random samples
    """
    return scipy_stats.norm.rvs(loc=mu, scale=sigma, size=size)


def sample_uniform(
    size: int,
    low: float = 0.0,
    high: float = 1.0
) -> NDArray:
    """
    Sample from uniform distribution.
    
    Args:
        size: Number of samples
        low: Lower bound
        high: Upper bound
        
    Returns:
        Random samples
    """
    return scipy_stats.uniform.rvs(loc=low, scale=high - low, size=size)


def sample_gamma(
    size: int,
    shape: float,
    scale: float = 1.0
) -> NDArray:
    """
    Sample from gamma distribution.
    
    Args:
        size: Number of samples
        shape: Shape parameter (k)
        scale: Scale parameter (theta)
        
    Returns:
        Random samples
    """
    return scipy_stats.gamma.rvs(a=shape, scale=scale, size=size)


def sample_beta(
    size: int,
    alpha: float,
    beta_param: float
) -> NDArray:
    """
    Sample from beta distribution.
    
    Args:
        size: Number of samples
        alpha: First shape parameter
        beta_param: Second shape parameter
        
    Returns:
        Random samples
    """
    return scipy_stats.beta.rvs(a=alpha, b=beta_param, size=size)


def sample_poisson(
    size: int,
    lam: float
) -> NDArray:
    """
    Sample from Poisson distribution.
    
    Args:
        size: Number of samples
        lam: Rate parameter (lambda)
        
    Returns:
        Random samples
    """
    return scipy_stats.poisson.rvs(mu=lam, size=size)


def entropy(
    data: NDArray,
    base: float = np.e
) -> float:
    """
    Compute entropy of data distribution.
    
    Args:
        data: Input array (will be treated as probability distribution)
        base: Logarithm base for entropy
        
    Returns:
        Entropy value
    """
    # Normalize to make it a probability distribution
    p = np.abs(data) / np.sum(np.abs(data))
    p = p[p > 0]  # Remove zeros
    return -np.sum(p * np.log(p)) / np.log(base)


def kl_divergence(
    p: NDArray,
    q: NDArray
) -> float:
    """
    Compute Kullback-Leibler divergence D(P||Q).
    
    Args:
        p: First distribution
        q: Second distribution
        
    Returns:
        KL divergence
    """
    p = np.abs(p) / np.sum(np.abs(p))
    q = np.abs(q) / np.sum(np.abs(q))
    
    # Avoid division by zero
    q = np.where(q == 0, 1e-10, q)
    p = np.where(p == 0, 1e-10, p)
    
    return np.sum(p * np.log(p / q))


def mutual_information(
    x: NDArray,
    y: NDArray,
    bins: int = 10
) -> float:
    """
    Compute mutual information between two variables.
    
    Args:
        x: First variable
        y: Second variable
        bins: Number of bins for histogram
        
    Returns:
        Mutual information value
    """
    x = x.flatten()
    y = y.flatten()
    
    # Compute joint histogram
    hist_2d, _, _ = np.histogram2d(x, y, bins=bins)
    
    # Convert to probability distributions
    pxy = hist_2d / np.sum(hist_2d)
    px = np.sum(pxy, axis=1)
    py = np.sum(pxy, axis=0)
    
    # Compute MI
    px_py = np.outer(px, py)
    px_py = np.where(pxy > 0, px_py, 1)  # Avoid division by zero
    
    return np.sum(pxy * np.log(pxy / px_py))


def chi_square_test(
    observed: NDArray,
    expected: Optional[NDArray] = None
) -> Tuple[float, float]:
    """
    Chi-square goodness-of-fit test.
    
    Args:
        observed: Observed frequencies
        expected: Expected frequencies (if None, assumes uniform)
        
    Returns:
        Tuple of (chi2 statistic, p-value)
    """
    if expected is None:
        expected = np.ones_like(observed) * np.sum(observed) / len(observed)
    
    return scipy_stats.chisquare(observed, f_exp=expected)


def anova_test(
    *groups: NDArray
) -> Tuple[float, float]:
    """
    One-way ANOVA test.
    
    Args:
        *groups: Variable number of group arrays
        
    Returns:
        Tuple of (F statistic, p-value)
    """
    return scipy_stats.f_oneway(*groups)


def lilliefors_test(
    data: NDArray
) -> Tuple[float, float]:
    """
    Lilliefors test for normality.
    
    Args:
        data: Input data
        
    Returns:
        Tuple of (statistic, p-value)
    """
    return scipy_stats.lilliefors(data)
