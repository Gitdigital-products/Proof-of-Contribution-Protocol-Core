"""
NumPy Operations Module
=======================

Provides clean abstractions for vector operations, matrix operations,
broadcasting helpers, and data manipulation utilities. Designed for
reproducibility and auditability in scientific computing.

Author: MiniMax Agent
"""

import numpy as np
from typing import Union, Tuple, List, Optional, Callable
from numpy.typing import NDArray


def broadcast_arrays(*arrays: NDArray) -> Tuple[NDArray, ...]:
    """
    Broadcast arrays to a common shape with validation.
    
    This function extends numpy broadcasting with additional safety checks
    to ensure numerical stability and prevent unexpected behavior in
    production environments.
    
    Args:
        *arrays: Variable number of numpy arrays to broadcast
        
    Returns:
        Tuple of broadcasted arrays
        
    Raises:
        ValueError: If arrays cannot be broadcast together
        TypeError: If inputs are not numpy arrays
        
    Example:
        >>> a = np.ones((1, 10))
        >>> b = np.ones((5, 1))
        >>> a_broadcast, b_broadcast = broadcast_arrays(a, b)
        >>> a_broadcast.shape
        (5, 10)
    """
    for i, arr in enumerate(arrays):
        if not isinstance(arr, np.ndarray):
            raise TypeError(f"Argument {i} must be a numpy array, got {type(arr)}")
    
    try:
        broadcasted = np.broadcast_arrays(*arrays)
        return tuple(broadcasted)
    except ValueError as e:
        raise ValueError(f"Cannot broadcast arrays: {e}")


def stack_arrays(arrays: List[NDArray], axis: int = 0) -> NDArray:
    """
    Stack arrays along specified axis with validation.
    
    Args:
        arrays: List of numpy arrays to stack
        axis: Axis along which to stack (default: 0)
        
    Returns:
        Stacked numpy array
        
    Raises:
        ValueError: If arrays have incompatible shapes
    """
    if not arrays:
        raise ValueError("Cannot stack empty array list")
    
    shapes = [arr.shape for arr in arrays]
    if len(set(shapes)) > 1:
        raise ValueError(f"All arrays must have same shape for stacking, got shapes: {shapes}")
    
    return np.stack(arrays, axis=axis)


def chunk_data(data: NDArray, chunk_size: int, axis: int = 0) -> List[NDArray]:
    """
    Split data into chunks of specified size.
    
    Useful for batch processing and memory-efficient computation
    in training pipelines.
    
    Args:
        data: Input numpy array
        chunk_size: Size of each chunk
        axis: Axis along which to chunk (default: 0)
        
    Returns:
        List of data chunks
    """
    if chunk_size <= 0:
        raise ValueError(f"chunk_size must be positive, got {chunk_size}")
    
    n = data.shape[axis]
    chunks = []
    for i in range(0, n, chunk_size):
        chunk = np.take(data, range(i, min(i + chunk_size, n)), axis=axis)
        chunks.append(chunk)
    
    return chunks


def normalize(data: NDArray, axis: Optional[int] = None, 
              epsilon: float = 1e-8) -> Tuple[NDArray, NDArray, NDArray]:
    """
    Normalize data to zero mean and unit variance.
    
    Args:
        data: Input data array
        axis: Axis along which to normalize (None for global)
        epsilon: Small constant for numerical stability
        
    Returns:
        Tuple of (normalized_data, mean, std)
    """
    mean = np.mean(data, axis=axis, keepdims=True)
    std = np.std(data, axis=axis, keepdims=True)
    std = np.where(std < epsilon, 1.0, std)
    
    normalized = (data - mean) / std
    return normalized, mean.squeeze(), std.squeeze()


def denormalize(data: NDArray, mean: NDArray, std: NDArray) -> NDArray:
    """
    Reverse normalization using stored statistics.
    
    Args:
        data: Normalized data
        mean: Original mean used for normalization
        std: Original standard deviation used for normalization
        
    Returns:
        Denormalized data
    """
    return data * std + mean


def clip_gradient(grad: NDArray, max_norm: float, 
                   axis: Optional[int] = None) -> NDArray:
    """
    Clip gradient values to prevent exploding gradients.
    
    Args:
        grad: Gradient array
        max_norm: Maximum gradient norm
        axis: Axis along which to compute norm (None for global)
        
    Returns:
        Clipped gradient
    """
    total_norm = np.sqrt(np.sum(grad ** 2, axis=axis, keepdims=True))
    clip_coef = max_norm / (total_norm + 1e-6)
    
    if clip_coef < 1:
        return grad * clip_coef
    
    return grad


def batch_dot(a: NDArray, b: NDArray, axis: int = -1) -> NDArray:
    """
    Compute batch-wise dot product along specified axis.
    
    Args:
        a: First array (must be 2D or higher)
        b: Second array (must be 2D or higher)
        axis: Axis along which to compute dot product
        
    Returns:
        Batch dot product result
    """
    if a.ndim < 2 or b.ndim < 2:
        raise ValueError("Both arrays must be at least 2D for batch dot product")
    
    return np.sum(a * b, axis=axis)


def one_hot_encode(labels: NDArray, num_classes: int) -> NDArray:
    """
    Convert labels to one-hot encoded format.
    
    Args:
        labels: Array of integer labels
        num_classes: Total number of classes
        
    Returns:
        One-hot encoded array
    """
    return np.eye(num_classes, dtype=np.float32)[labels]


def sliding_window_view(data: NDArray, window_size: int, 
                        step: int = 1) -> NDArray:
    """
    Create sliding window view of data.
    
    Args:
        data: Input array
        window_size: Size of sliding window
        step: Step size between windows
        
    Returns:
        Sliding window view
    """
    if window_size > data.shape[-1]:
        raise ValueError(f"window_size {window_size} cannot exceed data length {data.shape[-1]}")
    
    shape = data.shape[:-1] + ((data.shape[-1] - window_size) // step + 1, window_size)
    strides = data.strides[:-1] + (data.strides[-1] * step, data.strides[-1])
    
    return np.lib.stride_tricks.as_strided(data, shape=shape, strides=strides)


def moving_average(data: NDArray, window_size: int, 
                   mode: str = 'valid') -> NDArray:
    """
    Compute moving average with optional padding modes.
    
    Args:
        data: Input array
        window_size: Size of averaging window
        mode: 'valid', 'same', or 'full'
        
    Returns:
        Moving average array
    """
    if mode == 'same':
        pad_size = window_size // 2
        data_padded = np.pad(data, (pad_size, window_size - pad_size - 1), mode='edge')
    else:
        data_padded = data
    
    kernel = np.ones(window_size) / window_size
    return np.convolve(data_padded.squeeze(), kernel, mode=mode)


def compute_pairwise_distances(a: NDArray, b: NDArray, 
                                metric: str = 'euclidean') -> NDArray:
    """
    Compute pairwise distances between two sets of points.
    
    Args:
        a: First set of points (n, d)
        b: Second set of points (m, d)
        metric: Distance metric ('euclidean', 'manhattan', 'cosine')
        
    Returns:
        Distance matrix (n, m)
    """
    if metric == 'euclidean':
        # Use broadcasting for efficiency
        a_sq = np.sum(a ** 2, axis=1, keepdims=True)
        b_sq = np.sum(b ** 2, axis=1, keepdims=True)
        ab = np.dot(a, b.T)
        distances = np.sqrt(a_sq + b_sq.T - 2 * ab + 1e-8)
    elif metric == 'manhattan':
        distances = np.sum(np.abs(a[:, None, :] - b[None, :, :]), axis=2)
    elif metric == 'cosine':
        a_norm = a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-8)
        b_norm = b / (np.linalg.norm(b, axis=1, keepdims=True) + 1e-8)
        distances = 1 - np.dot(a_norm, b_norm.T)
    else:
        raise ValueError(f"Unknown metric: {metric}")
    
    return distances


def batch_outer_product(a: NDArray, b: NDArray) -> NDArray:
    """
    Compute batch-wise outer product.
    
    Args:
        a: First array (batch_size, n)
        b: Second array (batch_size, m)
        
    Returns:
        Outer products (batch_size, n, m)
    """
    return a[:, :, None] * b[:, None, :]


def safe_divide(a: NDArray, b: NDArray, epsilon: float = 1e-8) -> NDArray:
    """
    Division with numerical stability safeguards.
    
    Args:
        a: Numerator array
        b: Denominator array
        epsilon: Small constant to prevent division by zero
        
    Returns:
        Safe division result
    """
    return a / (b + epsilon)


def log_sum_exp(arr: NDArray, axis: int = None) -> NDArray:
    """
    Compute log-sum-exp with numerical stability.
    
    This is more stable than naive log(sum(exp(arr))) for large values.
    
    Args:
        arr: Input array
        axis: Axis along which to compute (None for global)
        
    Returns:
        Log-sum-exp result
    """
    arr_max = np.max(arr, axis=axis, keepdims=True)
    return arr_max + np.log(np.sum(np.exp(arr - arr_max), axis=axis, keepdims=True) + 1e-8)


def softmax(logits: NDArray, axis: int = -1) -> NDArray:
    """
    Compute numerically stable softmax.
    
    Args:
        logits: Input logits
        axis: Axis along which to compute softmax
        
    Returns:
        Softmax probabilities
    """
    exp_logits = np.exp(logits - np.max(logits, axis=axis, keepdims=True))
    return exp_logits / np.sum(exp_logits, axis=axis, keepdims=True)


def weighted_mean(values: NDArray, weights: NDArray, 
                  axis: Optional[int] = None) -> float:
    """
    Compute weighted mean with validation.
    
    Args:
        values: Input values
        weights: Weights for each value
        axis: Axis along which to compute (None for global)
        
    Returns:
        Weighted mean
    """
    weights = np.broadcast_to(weights, values.shape)
    weights_sum = np.sum(weights, axis=axis)
    
    if np.any(weights_sum == 0):
        raise ValueError("Weights sum to zero along specified axis")
    
    return np.sum(values * weights, axis=axis) / weights_sum
