"""
Configuration Module
====================

Provides centralized configuration management with environment
variable support and hierarchical settings.

Author: MiniMax Agent
"""

import os
import json
import yaml
from typing import Dict, Any, Optional, Union
from dataclasses import dataclass, field, asdict
from pathlib import Path
from dotenv import load_dotenv


@dataclass
class Config:
    """
    Central configuration class.
    
    Provides hierarchical configuration with environment variables,
    JSON/YAML file support, and dot notation access.
    
    Attributes:
        _data: Internal dictionary storage
        _env_prefix: Environment variable prefix
    """
    _data: Dict[str, Any] = field(default_factory=dict)
    _env_prefix: str = "TINKERFLOW"
    
    def __init__(self, config_dict: Optional[Dict[str, Any]] = None, env_prefix: str = "TINKERFLOW"):
        """Initialize configuration."""
        self._env_prefix = env_prefix
        self._data = config_dict or {}
        
        # Load environment variables
        self._load_from_env()
    
    def _load_from_env(self) -> None:
        """Load configuration from environment variables."""
        for key, value in os.environ.items():
            if key.startswith(f"{self._env_prefix}_"):
                config_key = key[len(self._env_prefix) + 1:].lower()
                self._data[config_key] = self._parse_value(value)
    
    def _parse_value(self, value: str) -> Any:
        """Parse environment variable value."""
        # Try to parse as JSON
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            pass
        
        # Parse common types
        if value.lower() == 'true':
            return True
        elif value.lower() == 'false':
            return False
        elif value.lower() == 'none':
            return None
        
        # Try numeric
        try:
            if '.' in value:
                return float(value)
            return int(value)
        except ValueError:
            return value
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value using dot notation.
        
        Args:
            key: Configuration key (e.g., 'model.hidden_dim')
            default: Default value if key not found
            
        Returns:
            Configuration value
        """
        keys = key.split('.')
        value = self._data
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any) -> None:
        """
        Set configuration value using dot notation.
        
        Args:
            key: Configuration key
            value: Value to set
        """
        keys = key.split('.')
        data = self._data
        
        for k in keys[:-1]:
            if k not in data:
                data[k] = {}
            data = data[k]
        
        data[keys[-1]] = value
    
    def update(self, config_dict: Dict[str, Any]) -> None:
        """Update configuration with dictionary."""
        self._data.update(config_dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Get configuration as dictionary."""
        return self._data.copy()
    
    def to_json(self, filepath: Optional[str] = None) -> str:
        """
        Export configuration as JSON.
        
        Args:
            filepath: Optional path to save JSON
            
        Returns:
            JSON string
        """
        json_str = json.dumps(self._data, indent=2)
        
        if filepath:
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w') as f:
                f.write(json_str)
        
        return json_str
    
    def to_yaml(self, filepath: Optional[str] = None) -> str:
        """
        Export configuration as YAML.
        
        Args:
            filepath: Optional path to save YAML
            
        Returns:
            YAML string
        """
        yaml_str = yaml.dump(self._data, default_flow_style=False)
        
        if filepath:
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            with open(filepath, 'w') as f:
                f.write(yaml_str)
        
        return yaml_str
    
    @classmethod
    def from_json(cls, filepath: str) -> "Config":
        """Load configuration from JSON file."""
        with open(filepath, 'r') as f:
            config_dict = json.load(f)
        return cls(config_dict)
    
    @classmethod
    def from_yaml(cls, filepath: str) -> "Config":
        """Load configuration from YAML file."""
        with open(filepath, 'r') as f:
            config_dict = yaml.safe_load(f)
        return cls(config_dict)
    
    @classmethod
    def from_env(cls, env_file: str = ".env") -> "Config":
        """Load configuration from environment file."""
        load_dotenv(env_file)
        return cls()
    
    def __getitem__(self, key: str) -> Any:
        """Get item using bracket notation."""
        return self.get(key)
    
    def __setitem__(self, key: str, value: Any) -> None:
        """Set item using bracket notation."""
        self.set(key, value)
    
    def __contains__(self, key: str) -> bool:
        """Check if key exists."""
        return self.get(key) is not None


def get_config(
    config_path: Optional[str] = None,
    env_file: str = ".env"
) -> Config:
    """
    Get configuration from file or environment.
    
    Args:
        config_path: Path to config file (JSON or YAML)
        env_file: Path to environment file
        
    Returns:
        Config instance
    """
    # Load environment
    load_dotenv(env_file)
    
    if config_path:
        path = Path(config_path)
        if path.suffix == '.json':
            return Config.from_json(str(path))
        elif path.suffix in ['.yaml', '.yml']:
            return Config.from_yaml(str(path))
    
    return Config.from_env(env_file)
