"""
Paths Module
============

Provides path management and project structure utilities.

Author: MiniMax Agent
"""

from pathlib import Path
from typing import Dict, Optional
import os


class ProjectPaths:
    """
    Manages project directory structure.
    
    Provides easy access to common project directories.
    """
    
    def __init__(self, root: Optional[str] = None):
        """
        Initialize project paths.
        
        Args:
            root: Project root directory (defaults to current directory)
        """
        self.root = Path(root or os.getcwd())
        
        # Create standard directories
        self.data = self.root / "data"
        self.models = self.root / "models"
        self.checkpoints = self.root / "checkpoints"
        self.logs = self.root / "logs"
        self.output = self.root / "output"
        self.cache = self.root / "cache"
        self.docs = self.root / "docs"
        
        # Create directories
        for path in [self.data, self.models, self.checkpoints, self.logs, 
                     self.output, self.cache, self.docs]:
            path.mkdir(parents=True, exist_ok=True)
    
    def get_model_path(self, name: str) -> Path:
        """Get path for saved model."""
        return self.models / f"{name}.pt"
    
    def get_checkpoint_path(self, name: str) -> Path:
        """Get path for checkpoint."""
        return self.checkpoints / f"{name}.pt"
    
    def get_log_path(self, name: str) -> Path:
        """Get path for log file."""
        return self.logs / f"{name}.log"
    
    def get_data_path(self, name: str) -> Path:
        """Get path for data file."""
        return self.data / name


def get_project_paths(root: Optional[str] = None) -> ProjectPaths:
    """
    Get project paths instance.
    
    Args:
        root: Project root directory
        
    Returns:
        ProjectPaths instance
    """
    return ProjectPaths(root)


def ensure_dir(path: str) -> Path:
    """
    Ensure directory exists.
    
    Args:
        path: Directory path
        
    Returns:
        Path object
    """
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_relative_path(path: str, start: Optional[str] = None) -> Path:
    """
    Get relative path from start directory.
    
    Args:
        path: Target path
        start: Start directory (defaults to cwd)
        
    Returns:
        Relative path
    """
    return Path(path).relative_to(start or Path.cwd())
