"""
Logging Module
=============

Provides unified logging configuration for the project.

Author: MiniMax Agent
"""

import logging
import sys
from pathlib import Path
from typing import Optional
from datetime import datetime


def setup_logging(
    log_level: str = "INFO",
    log_file: Optional[str] = None,
    log_format: Optional[str] = None,
    name: Optional[str] = None
) -> logging.Logger:
    """
    Setup logging configuration.
    
    Args:
        log_level: Logging level ('DEBUG', 'INFO', 'WARNING', 'ERROR')
        log_file: Optional path to log file
        log_format: Optional custom format string
        name: Logger name
        
    Returns:
        Configured logger
    """
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, log_level.upper()))
    logger.handlers = []
    
    if log_format is None:
        log_format = "%(asctime)s | %(name)s | %(levelname)s | %(message)s"
    
    formatter = logging.Formatter(log_format)
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.FileHandler(log_path)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


class TrainingLogger:
    """
    Logger for training progress with structured output.
    """
    
    def __init__(
        self,
        log_file: Optional[str] = None,
        log_every: int = 10
    ):
        """
        Initialize training logger.
        
        Args:
            log_file: Optional path to log file
            log_every: Log every N steps
        """
        self.log_file = log_file
        self.log_every = log_every
        self.logger = setup_logging(log_file=log_file, name="training")
    
    def log_epoch(
        self,
        epoch: int,
        train_loss: float,
        val_loss: Optional[float] = None,
        metrics: Optional[dict] = None,
        lr: Optional[float] = None
    ) -> None:
        """Log epoch summary."""
        msg = f"Epoch {epoch} | Train Loss: {train_loss:.4f}"
        
        if val_loss is not None:
            msg += f" | Val Loss: {val_loss:.4f}"
        
        if lr is not None:
            msg += f" | LR: {lr:.2e}"
        
        if metrics:
            metric_str = " | ".join([f"{k}: {v:.4f}" for k, v in metrics.items()])
            msg += f" | {metric_str}"
        
        self.logger.info(msg)
    
    def log_step(
        self,
        step: int,
        loss: float,
        **kwargs
    ) -> None:
        """Log training step."""
        if step % self.log_every == 0:
            msg = f"Step {step} | Loss: {loss:.4f}"
            
            for k, v in kwargs.items():
                if isinstance(v, float):
                    msg += f" | {k}: {v:.4f}"
                else:
                    msg += f" | {k}: {v}"
            
            self.logger.debug(msg)


def get_logger(name: str) -> logging.Logger:
    """
    Get logger by name.
    
    Args:
        name: Logger name
        
    Returns:
        Logger instance
    """
    return logging.getLogger(name)
