"""
Seed Module
===========

Provides comprehensive seeding for reproducibility across all libraries.

Author: MiniMax Agent
"""

import os
import random
import numpy as np
import torch
from typing import Optional


def set_seed(
    seed: int = 42,
    deterministic: bool = True,
    benchmark: bool = False
) -> dict:
    """
    Set random seed for all libraries.
    
    Seeds Python random, NumPy, and PyTorch (and TensorFlow if available).
    
    Args:
        seed: Random seed value
        deterministic: Enforce deterministic algorithms
        benchmark: Enable cuDNN benchmarking
        
    Returns:
        Dictionary with seeding information
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    info = {
        'seed': seed,
        'python_random': True,
        'numpy': True,
        'pytorch': True,
        'deterministic': deterministic,
        'benchmark': benchmark
    }
    
    # PyTorch CUDA seeds
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        
        if deterministic:
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = benchmark
            torch.use_deterministic_algorithms(deterministic)
        
        info['cuda'] = True
    else:
        info['cuda'] = False
    
    # TensorFlow
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
        info['tensorflow'] = True
    except ImportError:
        info['tensorflow'] = False
    
    # Set environment variable
    os.environ['PYTHONHASHSEED'] = str(seed)
    
    return info


def set_seed_everywhere(seed: int) -> None:
    """
    Convenience function to set seed everywhere.
    
    Args:
        seed: Random seed value
    """
    set_seed(seed)


def get_random_state() -> dict:
    """
    Get current random state from all libraries.
    
    Returns:
        Dictionary with random states
    """
    state = {
        'python': random.getstate(),
        'numpy': np.random.get_state()
    }
    
    try:
        state['torch'] = torch.get_rng_state()
        if torch.cuda.is_available():
            state['torch_cuda'] = torch.cuda.get_rng_state_all()
    except:
        pass
    
    return state


def set_random_state(state: dict) -> None:
    """
    Restore random state from saved dictionary.
    
    Args:
        state: Dictionary from get_random_state()
    """
    random.setstate(state['python'])
    np.random.set_state(state['numpy'])
    
    if 'torch' in state:
        torch.set_rng_state(state['torch'])
        if 'torch_cuda' in state and torch.cuda.is_available():
            torch.cuda.set_rng_state_all(state['torch_cuda'])
