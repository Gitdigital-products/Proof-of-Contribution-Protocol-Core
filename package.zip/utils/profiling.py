"""
Profiling Module
================

Provides performance profiling utilities for code optimization.

Author: MiniMax Agent
"""

import time
import psutil
import functools
from typing import Callable, Optional, Dict, Any
from contextlib import contextmanager


class Profiler:
    """
    Performance profiler for tracking execution time and memory.
    """
    
    def __init__(self):
        """Initialize profiler."""
        self.timings: Dict[str, float] = {}
        self.memory_usage: Dict[str, float] = {}
        self.call_counts: Dict[str, int] = {}
    
    def start(self, name: str) -> None:
        """Start timing for named section."""
        if not hasattr(self, '_start_times'):
            self._start_times = {}
        self._start_times[name] = time.time()
    
    def end(self, name: str) -> float:
        """
        End timing and record duration.
        
        Returns:
            Elapsed time in seconds
        """
        if not hasattr(self, '_start_times') or name not in self._start_times:
            return 0.0
        
        elapsed = time.time() - self._start_times[name]
        
        if name in self.timings:
            self.timings[name] += elapsed
            self.call_counts[name] += 1
        else:
            self.timings[name] = elapsed
            self.call_counts[name] = 1
        
        return elapsed
    
    def get_average_time(self, name: str) -> float:
        """Get average time for named section."""
        if name not in self.timings:
            return 0.0
        return self.timings[name] / self.call_counts[name]
    
    def get_summary(self) -> Dict[str, Any]:
        """Get profiling summary."""
        return {
            'timings': self.timings,
            'call_counts': self.call_counts,
            'average_times': {
                name: self.get_average_time(name)
                for name in self.timings
            }
        }
    
    def reset(self) -> None:
        """Reset all profiling data."""
        self.timings.clear()
        self.memory_usage.clear()
        self.call_counts.clear()
        if hasattr(self, '_start_times'):
            self._start_times.clear()


@contextmanager
def ProfileContext(name: str = "block", profiler: Optional[Profiler] = None):
    """
    Context manager for profiling code blocks.
    
    Example:
        >>> with ProfileContext("my_function"):
        ...     my_function()
    """
    if profiler is None:
        profiler = Profiler()
    
    profiler.start(name)
    try:
        yield profiler
    finally:
        profiler.end(name)


def profile_function(func: Callable) -> Callable:
    """
    Decorator for profiling function execution.
    
    Example:
        >>> @profile_function
        ... def my_function():
        ...     pass
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start_time
        
        print(f"{func.__name__} took {elapsed:.4f}s")
        return result
    
    return wrapper


def get_memory_usage() -> Dict[str, float]:
    """
    Get current memory usage.
    
    Returns:
        Dictionary with memory statistics in MB
    """
    process = psutil.Process()
    memory_info = process.memory_info()
    
    return {
        'rss': memory_info.rss / 1024 / 1024,  # Resident Set Size
        'vms': memory_info.vms / 1024 / 1024,  # Virtual Memory Size
        'percent': process.memory_percent()
    }


class MemoryProfiler:
    """Track memory usage over time."""
    
    def __init__(self):
        """Initialize memory profiler."""
        self.snapshots: list = []
    
    def take_snapshot(self, label: str = "") -> None:
        """Take memory usage snapshot."""
        import gc
        gc.collect()  # Force garbage collection
        
        snapshot = {
            'label': label,
            'time': time.time(),
            'memory': get_memory_usage()
        }
        self.snapshots.append(snapshot)
    
    def get_peak_memory(self) -> float:
        """Get peak memory usage in MB."""
        if not self.snapshots:
            return 0.0
        return max(s['memory']['rss'] for s in self.snapshots)
    
    def get_memory_delta(self) -> float:
        """Get memory change since first snapshot."""
        if len(self.snapshots) < 2:
            return 0.0
        return self.snapshots[-1]['memory']['rss'] - self.snapshots[0]['memory']['rss']
