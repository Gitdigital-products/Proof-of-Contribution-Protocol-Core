"""
Model Serialization Module
===========================

Provides model saving/loading with TorchScript, ONNX, and
various optimization options for deployment.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, Tuple, List, Callable
from dataclasses import dataclass
from pathlib import Path
import json


@dataclass
class SerializationConfig:
    """
    Configuration for model serialization.
    
    Attributes:
        save_optimizer: Whether to save optimizer state
        save_checkpoint: Whether to save full checkpoint
        save_jit: Whether to save TorchScript version
        save_onnx: Whether to save ONNX version
        onnx_opset_version: ONNX opset version
        optimize_for_inference: Apply inference optimizations
        quantization: Quantization type ('dynamic', 'static', None)
    """
    save_optimizer: bool = False
    save_checkpoint: bool = True
    save_jit: bool = True
    save_onnx: bool = True
    onnx_opset_version: int = 14
    optimize_for_inference: bool = True
    quantization: Optional[str] = None


class ModelSerializer:
    """
    Handles model serialization for deployment.
    
    Supports multiple formats including PyTorch checkpoints,
    TorchScript, and ONNX.
    
    Example:
        >>> serializer = ModelSerializer(model, config)
        >>> serializer.save("output_dir", checkpoint_path)
    """
    
    def __init__(
        self,
        model: nn.Module,
        config: Optional[SerializationConfig] = None
    ):
        """
        Initialize model serializer.
        
        Args:
            model: PyTorch model
            config: Serialization configuration
        """
        self.model = model
        self.config = config or SerializationConfig()
    
    def save(
        self,
        output_dir: str,
        checkpoint_path: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, str]:
        """
        Save model in multiple formats.
        
        Args:
            output_dir: Directory to save models
            checkpoint_path: Optional path to checkpoint for loading state
            metadata: Optional metadata to save with model
            
        Returns:
            Dictionary mapping format names to saved paths
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        saved_paths = {}
        
        # Load checkpoint state if provided
        if checkpoint_path is not None:
            checkpoint = torch.load(checkpoint_path, map_location="cpu")
            if "model_state_dict" in checkpoint:
                self.model.load_state_dict(checkpoint["model_state_dict"])
            elif "state_dict" in checkpoint:
                self.model.load_state_dict(checkpoint["state_dict"])
        
        self.model.eval()
        
        # Save PyTorch checkpoint
        if self.config.save_checkpoint:
            checkpoint_path = output_dir / "model_checkpoint.pt"
            self._save_checkpoint(checkpoint_path, metadata)
            saved_paths["checkpoint"] = str(checkpoint_path)
        
        # Save TorchScript
        if self.config.save_jit:
            jit_path = output_dir / "model_jit.pt"
            self._save_jit(jit_path)
            saved_paths["jit"] = str(jit_path)
        
        # Save ONNX
        if self.config.save_onnx:
            onnx_path = output_dir / "model.onnx"
            self._save_onnx(onnx_path)
            saved_paths["onnx"] = str(onnx_path)
        
        # Save metadata
        if metadata is not None:
            metadata_path = output_dir / "metadata.json"
            with open(metadata_path, 'w') as f:
                json.dump(metadata, f, indent=2)
            saved_paths["metadata"] = str(metadata_path)
        
        return saved_paths
    
    def _save_checkpoint(
        self,
        path: Path,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """Save PyTorch checkpoint."""
        checkpoint = {
            "model_state_dict": self.model.state_dict(),
            "model_class": self.model.__class__.__name__,
        }
        
        if metadata is not None:
            checkpoint["metadata"] = metadata
        
        # Try to get model config if available
        if hasattr(self.model, "config"):
            checkpoint["config"] = self.model.config.__dict__
        
        torch.save(checkpoint, path)
    
    def _save_jit(self, path: Path) -> None:
        """Save TorchScript model."""
        # Try scripted model first
        if isinstance(self.model, torch.jit.ScriptModule):
            self.model.save(str(path))
            return
        
        # Trace model with sample input
        try:
            scripted = torch.jit.trace(
                self.model,
                torch.randn(1, self._get_input_dim())
            )
            scripted.save(str(path))
        except Exception as e:
            # Fallback to script
            try:
                scripted = torch.jit.script(self.model)
                scripted.save(str(path))
            except Exception:
                print(f"Warning: Could not save TorchScript model: {e}")
    
    def _save_onnx(self, path: Path) -> None:
        """Save ONNX model."""
        try:
            dummy_input = torch.randn(1, self._get_input_dim())
            
            torch.onnx.export(
                self.model,
                dummy_input,
                str(path),
                export_params=True,
                opset_version=self.config.onnx_opset_version,
                do_constant_folding=True,
                input_names=["input"],
                output_names=["output"],
                dynamic_axes={
                    "input": {0: "batch_size"},
                    "output": {0: "batch_size"}
                }
            )
        except Exception as e:
            print(f"Warning: Could not save ONNX model: {e}")
    
    def _get_input_dim(self) -> int:
        """Get expected input dimension from model."""
        if hasattr(self.model, "config"):
            return self.model.config.input_dim
        
        # Try to infer from first linear layer
        for module in self.model.modules():
            if isinstance(module, nn.Linear):
                return module.in_features
        
        return 784  # Default fallback
    
    @classmethod
    def load_checkpoint(
        cls,
        path: str,
        model: Optional[nn.Module] = None,
        device: Optional[torch.device] = None
    ) -> Tuple[Optional[nn.Module], Dict[str, Any]]:
        """
        Load model from checkpoint.
        
        Args:
            path: Path to checkpoint
            model: Optional model to load state into
            device: Device to load tensors to
            
        Returns:
            Tuple of (model, metadata)
        """
        checkpoint = torch.load(path, map_location=device)
        
        metadata = {}
        
        if model is None:
            raise ValueError("Model must be provided to load checkpoint")
        
        if "model_state_dict" in checkpoint:
            model.load_state_dict(checkpoint["model_state_dict"])
            metadata = checkpoint.get("metadata", {})
        elif "state_dict" in checkpoint:
            model.load_state_dict(checkpoint["state_dict"])
            metadata = checkpoint.get("metadata", {})
        
        return model, metadata
    
    @classmethod
    def load_jit(
        cls,
        path: str,
        device: Optional[torch.device] = None
    ) -> torch.jit.ScriptModule:
        """
        Load TorchScript model.
        
        Args:
            path: Path to TorchScript model
            device: Device to load model to
            
        Returns:
            Loaded TorchScript model
        """
        model = torch.jit.load(path, map_location=device)
        return model
    
    @classmethod
    def load_onnx(
        cls,
        path: str
    ) -> Any:
        """
        Load ONNX model (requires onnxruntime).
        
        Args:
            path: Path to ONNX model
            
        Returns:
            ONNX inference session
        """
        try:
            import onnxruntime as ort
            
            session = ort.InferenceSession(path)
            return session
        except ImportError:
            raise ImportError("onnxruntime is required for ONNX inference")


def export_for_deployment(
    model: nn.Module,
    output_dir: str,
    checkpoint_path: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, str]:
    """
    Convenience function to export model for deployment.
    
    Example:
        >>> paths = export_for_deployment(model, "./export", metadata={"version": "1.0"})
    """
    config = SerializationConfig(
        save_checkpoint=True,
        save_jit=True,
        save_onnx=True
    )
    
    serializer = ModelSerializer(model, config)
    return serializer.save(output_dir, checkpoint_path, metadata)


def optimize_for_inference(model: nn.Module) -> nn.Module:
    """
    Apply inference optimizations to model.
    
    Args:
        model: PyTorch model
        
    Returns:
        Optimized model
    """
    # Enable CUDNN benchmarking
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
    
    # Set model to eval mode
    model.eval()
    
    # Fuse layers where possible
    try:
        model = torch.jit.freeze(model)
    except Exception:
        pass
    
    return model
