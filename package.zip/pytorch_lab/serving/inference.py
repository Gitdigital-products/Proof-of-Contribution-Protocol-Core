"""
Inference Pipeline Module
==========================

Provides optimized inference pipeline with batching, pre/post processing,
and performance monitoring.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Union, Callable
from dataclasses import dataclass
import time
import numpy as np
from pathlib import Path


@dataclass
class InferenceConfig:
    """
    Configuration for inference.
    
    Attributes:
        device: Device for inference ('cuda', 'cpu', 'auto')
        batch_size: Batch size for inference
        use_half_precision: Use FP16 for faster inference
        use_quantization: Use quantization for smaller models
        num_workers: Number of workers for data loading
        prefetch_factor: Prefetch batches
        timeout: Timeout for inference in seconds
    """
    device: str = "auto"
    batch_size: int = 32
    use_half_precision: bool = False
    use_quantization: bool = False
    num_workers: int = 4
    prefetch_factor: int = 2
    timeout: float = 30.0


class InferencePipeline:
    """
    Optimized inference pipeline for PyTorch models.
    
    Handles model loading, batching, pre/post processing,
    and performance monitoring.
    
    Example:
        >>> pipeline = InferencePipeline(model, config)
        >>> pipeline.load_model(checkpoint_path)
        >>> results = pipeline.predict(input_data)
    """
    
    def __init__(
        self,
        model: Optional[nn.Module] = None,
        config: Optional[InferenceConfig] = None,
        preprocess_fn: Optional[Callable] = None,
        postprocess_fn: Optional[Callable] = None
    ):
        """
        Initialize inference pipeline.
        
        Args:
            model: PyTorch model (can be loaded later)
            config: Inference configuration
            preprocess_fn: Optional preprocessing function
            postprocess_fn: Optional postprocessing function
        """
        self.config = config or InferenceConfig()
        self.model = model
        self.preprocess_fn = preprocess_fn
        self.postprocess_fn = postprocess_fn
        
        # Setup device
        self.device = self._setup_device()
        
        # Move model to device if provided
        if self.model is not None:
            self.model.to(self.device)
            self.model.eval()
        
        # Half precision
        if self.config.use_half_precision:
            self._enable_half_precision()
        
        # Quantization
        if self.config.use_quantization:
            self._apply_quantization()
        
        # Performance tracking
        self.inference_times: List[float] = []
        self.num_inferences = 0
    
    def _setup_device(self) -> torch.device:
        """Setup inference device."""
        if self.config.device == "auto":
            return torch.device("cuda" if torch.cuda.is_available() else "cpu")
        return torch.device(self.config.device)
    
    def _enable_half_precision(self) -> None:
        """Enable FP16 inference."""
        if self.model is not None and self.device.type == "cuda":
            self.model = self.model.half()
    
    def _apply_quantization(self) -> None:
        """Apply dynamic quantization to model."""
        if self.model is not None:
            self.model = torch.quantization.quantize_dynamic(
                self.model,
                {nn.Linear, nn.Conv2d},
                dtype=torch.qint8
            )
    
    def load_model(
        self,
        checkpoint_path: str,
        map_location: Optional[str] = None
    ) -> None:
        """
        Load model from checkpoint.
        
        Args:
            checkpoint_path: Path to model checkpoint
            map_location: Device to map tensors to
        """
        if map_location is None:
            map_location = str(self.device)
        
        checkpoint = torch.load(checkpoint_path, map_location=map_location)
        
        if "model_state_dict" in checkpoint:
            self.model.load_state_dict(checkpoint["model_state_dict"])
        else:
            self.model.load_state_dict(checkpoint)
        
        self.model.to(self.device)
        self.model.eval()
        
        if self.config.use_half_precision:
            self._enable_half_precision()
        
        if self.config.use_quantization:
            self._apply_quantization()
    
    @torch.no_grad()
    def predict(
        self,
        inputs: Union[torch.Tensor, np.ndarray, List]
    ) -> Dict[str, Any]:
        """
        Run inference on inputs.
        
        Args:
            inputs: Input data (tensor, numpy array, or list)
            
        Returns:
            Dictionary with predictions and metadata
        """
        # Preprocess inputs
        inputs = self._preprocess(inputs)
        
        # Move to device
        inputs = inputs.to(self.device)
        
        # Half precision conversion
        if self.config.use_half_precision and inputs.dtype == torch.float32:
            inputs = inputs.half()
        
        # Time inference
        start_time = time.time()
        outputs = self.model(inputs)
        inference_time = time.time() - start_time
        
        # Update statistics
        self.inference_times.append(inference_time)
        self.num_inferences += inputs.size(0)
        
        # Postprocess outputs
        results = self._postprocess(outputs)
        
        # Add metadata
        results["inference_time"] = inference_time
        results["batch_size"] = inputs.size(0)
        results["device"] = str(self.device)
        
        return results
    
    @torch.no_grad()
    def predict_batch(
        self,
        inputs: Union[torch.Tensor, np.ndarray],
        batch_size: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Run inference on large input with batching.
        
        Args:
            inputs: Input tensor or array
            batch_size: Batch size (uses config if None)
            
        Returns:
            List of prediction results
        """
        if isinstance(inputs, np.ndarray):
            inputs = torch.from_numpy(inputs)
        
        batch_size = batch_size or self.config.batch_size
        
        results = []
        num_batches = (inputs.size(0) + batch_size - 1) // batch_size
        
        for i in range(num_batches):
            start_idx = i * batch_size
            end_idx = min((i + 1) * batch_size, inputs.size(0))
            
            batch_inputs = inputs[start_idx:end_idx]
            batch_results = self.predict(batch_inputs)
            results.append(batch_results)
        
        return results
    
    def _preprocess(self, inputs: Union[torch.Tensor, np.ndarray, List]) -> torch.Tensor:
        """Preprocess inputs."""
        if self.preprocess_fn is not None:
            return self.preprocess_fn(inputs)
        
        if isinstance(inputs, np.ndarray):
            inputs = torch.from_numpy(inputs)
        
        if isinstance(inputs, list):
            inputs = torch.stack(inputs)
        
        return inputs.float()
    
    def _postprocess(self, outputs: torch.Tensor) -> Dict[str, Any]:
        """Postprocess outputs."""
        if self.postprocess_fn is not None:
            return self.postprocess_fn(outputs)
        
        # Default: return logits and probabilities
        probs = torch.softmax(outputs, dim=-1)
        
        return {
            "logits": outputs,
            "probabilities": probs,
            "predictions": outputs.argmax(dim=-1),
            "confidences": probs.max(dim=-1)[0]
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get inference performance statistics.
        
        Returns:
            Dictionary with performance metrics
        """
        if not self.inference_times:
            return {}
        
        times = np.array(self.inference_times)
        
        return {
            "total_inferences": self.num_inferences,
            "total_time": float(np.sum(times)),
            "avg_time_per_batch": float(np.mean(times)),
            "std_time": float(np.std(times)),
            "min_time": float(np.min(times)),
            "max_time": float(np.max(times)),
            "throughput": self.num_inferences / np.sum(times) if np.sum(times) > 0 else 0,
        }
    
    def reset_statistics(self) -> None:
        """Reset performance statistics."""
        self.inference_times.clear()
        self.num_inferences = 0


def create_inference_pipeline(
    model: nn.Module,
    checkpoint_path: str,
    device: str = "auto",
    use_half_precision: bool = False
) -> InferencePipeline:
    """
    Convenience function to create inference pipeline.
    
    Example:
        >>> pipeline = create_inference_pipeline(model, "checkpoint.pt", device="cuda")
    """
    config = InferenceConfig(
        device=device,
        use_half_precision=use_half_precision
    )
    
    pipeline = InferencePipeline(model, config)
    pipeline.load_model(checkpoint_path)
    
    return pipeline
