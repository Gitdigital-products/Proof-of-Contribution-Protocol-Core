"""
Evaluator Module
================

Provides comprehensive evaluation pipeline with batch processing,
metric tracking, and detailed reporting.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from pathlib import Path
import json
import time
from datetime import datetime

from pytorch_lab.evaluation.metrics import Metrics, MetricsConfig


@dataclass
class EvaluationResult:
    """
    Container for evaluation results.
    
    Attributes:
        metrics: Dictionary of computed metrics
        predictions: Model predictions (optional)
        targets: Ground truth labels (optional)
        inference_time: Total inference time
        num_samples: Number of evaluated samples
        timestamp: Evaluation timestamp
        config: Evaluation configuration
    """
    metrics: Dict[str, float]
    predictions: Optional[torch.Tensor] = None
    targets: Optional[torch.Tensor] = None
    inference_time: float = 0.0
    num_samples: int = 0
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    config: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary."""
        result = {
            "metrics": self.metrics,
            "inference_time": self.inference_time,
            "num_samples": self.num_samples,
            "timestamp": self.timestamp,
            "config": self.config,
        }
        
        if self.predictions is not None:
            result["predictions_shape"] = list(self.predictions.shape)
        
        if self.targets is not None:
            result["targets_shape"] = list(self.targets.shape)
        
        return result
    
    def save(self, filepath: str) -> None:
        """Save results to JSON file."""
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    def get_summary(self) -> str:
        """Get formatted summary of results."""
        lines = [
            "Evaluation Results",
            "=" * 50,
            f"Timestamp: {self.timestamp}",
            f"Samples: {self.num_samples}",
            f"Inference Time: {self.inference_time:.2f}s",
            "",
            "Metrics:",
            "-" * 50,
        ]
        
        for key, value in sorted(self.metrics.items()):
            if isinstance(value, float):
                lines.append(f"  {key}: {value:.4f}")
            else:
                lines.append(f"  {key}: {value}")
        
        return "\n".join(lines)


class Evaluator:
    """
    Comprehensive evaluation pipeline.
    
    Handles model evaluation with batch processing, metric computation,
    prediction storage, and detailed reporting.
    
    Example:
        >>> evaluator = Evaluator(model, test_loader, config)
        >>> result = evaluator.evaluate()
        >>> print(result.get_summary())
    """
    
    def __init__(
        self,
        model: nn.Module,
        data_loader: DataLoader,
        config: Optional[MetricsConfig] = None,
        device: Optional[torch.device] = None,
        loss_fn: Optional[nn.Module] = None,
        output_dir: Optional[str] = None,
        store_predictions: bool = False
    ):
        """
        Initialize evaluator.
        
        Args:
            model: PyTorch model to evaluate
            data_loader: Data loader for evaluation
            config: Metrics configuration
            device: Device to use for evaluation
            loss_fn: Optional loss function
            output_dir: Directory to save results
            store_predictions: Whether to store predictions
        """
        self.model = model
        self.data_loader = data_loader
        self.metrics_config = config or MetricsConfig()
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.loss_fn = loss_fn
        self.output_dir = Path(output_dir) if output_dir else None
        self.store_predictions = store_predictions
        
        # Move model to device and set to eval mode
        self.model.to(self.device)
        self.model.eval()
        
        # Initialize metrics
        self.metrics = Metrics(self.metrics_config)
        
        # Timing
        self.total_inference_time = 0.0
    
    def evaluate(
        self,
        return_predictions: bool = False
    ) -> EvaluationResult:
        """
        Run full evaluation.
        
        Args:
            return_predictions: Whether to return predictions
            
        Returns:
            EvaluationResult with metrics and optional predictions
        """
        print(f"Starting evaluation on {self.device}")
        print(f"Device: {self.device}")
        print(f"Evaluation samples: {len(self.data_loader.dataset)}")
        print("-" * 60)
        
        # Reset state
        self.metrics.reset()
        self.total_inference_time = 0.0
        
        all_predictions = []
        all_targets = []
        
        # Evaluation loop
        with torch.no_grad():
            for batch_idx, (inputs, targets) in enumerate(self.data_loader):
                # Move data to device
                inputs = inputs.to(self.device)
                targets = targets.to(self.device)
                
                # Time inference
                start_time = time.time()
                
                # Forward pass
                outputs = self.model(inputs)
                
                # Compute loss if loss function provided
                loss = None
                if self.loss_fn is not None:
                    loss = self.loss_fn(outputs, targets).item()
                
                inference_time = time.time() - start_time
                self.total_inference_time += inference_time
                
                # Update metrics
                self.metrics.update(outputs, targets, loss)
                
                # Store predictions if requested
                if return_predictions or self.store_predictions:
                    all_predictions.append(outputs.cpu())
                    all_targets.append(targets.cpu())
                
                # Progress logging
                if (batch_idx + 1) % 10 == 0:
                    print(f"  Batch [{batch_idx + 1}/{len(self.data_loader)}]")
        
        # Compute final metrics
        metrics = self.metrics.compute()
        
        # Compute throughput
        throughput = len(self.data_loader.dataset) / self.total_inference_time
        metrics["throughput_samples_per_sec"] = throughput
        metrics["avg_inference_time_per_sample"] = self.total_inference_time / len(self.data_loader.dataset)
        
        # Prepare result
        predictions_tensor = torch.cat(all_predictions) if all_predictions else None
        targets_tensor = torch.cat(all_targets) if all_targets else None
        
        result = EvaluationResult(
            metrics=metrics,
            predictions=predictions_tensor,
            targets=targets_tensor,
            inference_time=self.total_inference_time,
            num_samples=len(self.data_loader.dataset),
            config=self.metrics_config.__dict__
        )
        
        # Print summary
        print(result.get_summary())
        
        # Save results if output directory specified
        if self.output_dir:
            self._save_results(result)
        
        return result
    
    def evaluate_per_class(
        self,
        class_names: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Evaluate and return per-class metrics.
        
        Args:
            class_names: Optional list of class names
            
        Returns:
            Dictionary with per-class results
        """
        from pytorch_lab.evaluation.metrics import compute_per_class_metrics
        
        # Get all predictions and targets
        all_preds = []
        all_targets = []
        
        with torch.no_grad():
            for inputs, targets in self.data_loader:
                inputs = inputs.to(self.device)
                outputs = self.model(inputs)
                all_preds.append(outputs.cpu())
                all_targets.append(targets)
        
        predictions = torch.cat(all_preds, dim=0)
        targets = torch.cat(all_targets, dim=0)
        
        # Compute per-class metrics
        per_class = compute_per_class_metrics(
            predictions,
            targets,
            self.metrics_config.num_classes
        )
        
        # Format results
        results = {
            "per_class_metrics": {},
            "class_names": class_names or [f"class_{i}" for i in range(self.metrics_config.num_classes)]
        }
        
        for class_idx, metrics in per_class.items():
            class_name = results["class_names"][class_idx] if class_idx < len(results["class_names"]) else f"class_{class_idx}"
            results["per_class_metrics"][class_name] = metrics
        
        return results
    
    def evaluate_with_confidence(
        self,
        confidence_threshold: float = 0.5
    ) -> Dict[str, Any]:
        """
        Evaluate with confidence analysis.
        
        Args:
            confidence_threshold: Minimum confidence for counting prediction
            
        Returns:
            Dictionary with confidence analysis
        """
        all_preds = []
        all_targets = []
        all_confidences = []
        
        with torch.no_grad():
            for inputs, targets in self.data_loader:
                inputs = inputs.to(self.device)
                outputs = self.model(inputs)
                
                # Get probabilities and confidence
                probs = torch.softmax(outputs, dim=1)
                confidences, _ = probs.max(dim=1)
                
                all_preds.append(outputs.cpu())
                all_targets.append(targets)
                all_confidences.append(confidences.cpu())
        
        predictions = torch.cat(all_preds, dim=0)
        targets = torch.cat(all_targets, dim=0)
        confidences = torch.cat(all_confidences, dim=0)
        
        # Compute metrics at different confidence thresholds
        results = {
            "confidence_distribution": {
                "mean": confidences.mean().item(),
                "std": confidences.std().item(),
                "min": confidences.min().item(),
                "max": confidences.max().item(),
                "median": confidences.median().item(),
            },
            "threshold_analysis": []
        }
        
        for threshold in [0.5, 0.7, 0.8, 0.9, 0.95]:
            high_conf_mask = confidences >= threshold
            if high_conf_mask.sum() > 0:
                from pytorch_lab.evaluation.metrics import compute_accuracy
                
                high_conf_acc = compute_accuracy(
                    predictions[high_conf_mask],
                    targets[high_conf_mask]
                )
                
                results["threshold_analysis"].append({
                    "threshold": threshold,
                    "num_samples": int(high_conf_mask.sum()),
                    "accuracy": high_conf_acc
                })
        
        return results
    
    @torch.no_grad()
    def predict(
        self,
        inputs: torch.Tensor
    ) -> torch.Tensor:
        """
        Run inference on a single batch or tensor.
        
        Args:
            inputs: Input tensor
            
        Returns:
            Model predictions
        """
        inputs = inputs.to(self.device)
        return self.model(inputs)
    
    def _save_results(self, result: EvaluationResult) -> None:
        """Save evaluation results to files."""
        if self.output_dir is None:
            return
        
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Save metrics as JSON
        metrics_path = self.output_dir / "evaluation_metrics.json"
        result.save(str(metrics_path))
        
        # Save predictions if requested
        if result.predictions is not None:
            predictions_path = self.output_dir / "predictions.pt"
            torch.save(result.predictions, predictions_path)
        
        # Save targets if available
        if result.targets is not None:
            targets_path = self.output_dir / "targets.pt"
            torch.save(result.targets, targets_path)
        
        print(f"\nResults saved to {self.output_dir}")


def evaluate_model(
    model: nn.Module,
    data_loader: DataLoader,
    device: Optional[torch.device] = None,
    loss_fn: Optional[nn.Module] = None
) -> Dict[str, float]:
    """
    Convenience function for quick model evaluation.
    
    Example:
        >>> metrics = evaluate_model(model, test_loader, device)
    """
    evaluator = Evaluator(
        model=model,
        data_loader=data_loader,
        device=device,
        loss_fn=loss_fn
    )
    
    result = evaluator.evaluate()
    return result.metrics
