"""
Metrics Module
==============

Provides comprehensive evaluation metrics for classification,
regression, and ranking tasks with consistent interface.

Author: MiniMax Agent
"""

import torch
import numpy as np
from typing import Dict, Any, Optional, List, Union, Tuple
from dataclasses import dataclass, field
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, confusion_matrix,
    mean_squared_error, mean_absolute_error, r2_score,
    mean_absolute_percentage_error
)


@dataclass
class MetricsConfig:
    """
    Configuration for metrics computation.
    
    Attributes:
        task_type: Task type ('classification', 'regression')
        num_classes: Number of classes for classification
        average: Averaging method for multiclass metrics
        threshold: Classification threshold
        top_k: Top-k accuracy for classification
    """
    task_type: str = "classification"
    num_classes: int = 10
    average: str = "macro"
    threshold: float = 0.5
    top_k: int = 1


class Metrics:
    """
    Metrics computation for model evaluation.
    
    Provides accurate, precision, recall, F1, AUC, and more
    for classification, along with MSE, MAE, R2 for regression.
    
    Example:
        >>> metrics = Metrics(task_type="classification", num_classes=10)
        >>> metrics.update(predictions, targets)
        >>> results = metrics.compute()
    """
    
    def __init__(self, config: Optional[MetricsConfig] = None):
        """
        Initialize metrics.
        
        Args:
            config: Metrics configuration
        """
        self.config = config or MetricsConfig()
        self.reset()
    
    def reset(self) -> None:
        """Reset accumulated predictions and targets."""
        self.predictions: List[torch.Tensor] = []
        self.targets: List[torch.Tensor] = []
        self.losses: List[float] = []
        self.num_samples = 0
    
    def update(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor,
        loss: Optional[float] = None
    ) -> None:
        """
        Update metrics with batch results.
        
        Args:
            predictions: Model predictions (logits or probabilities)
            targets: Ground truth labels
            loss: Optional loss value for this batch
        """
        self.predictions.append(predictions.detach().cpu())
        self.targets.append(targets.detach().cpu())
        self.num_samples += predictions.size(0)
        
        if loss is not None:
            self.losses.append(loss)
    
    def compute(self) -> Dict[str, float]:
        """
        Compute all metrics.
        
        Returns:
            Dictionary of metric names and values
        """
        if not self.predictions:
            return {}
        
        # Concatenate all batches
        predictions = torch.cat(self.predictions, dim=0)
        targets = torch.cat(self.targets, dim=0)
        
        if self.config.task_type == "classification":
            return self._compute_classification_metrics(predictions, targets)
        else:
            return self._compute_regression_metrics(predictions, targets)
    
    def _compute_classification_metrics(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor
    ) -> Dict[str, float]:
        """Compute classification metrics."""
        results = {}
        
        # Get predicted classes
        if predictions.ndim == 2:
            # Logits or probabilities
            pred_classes = predictions.argmax(dim=1)
            pred_probs = torch.softmax(predictions, dim=1)
        else:
            pred_classes = (predictions > self.config.threshold).long()
            pred_probs = predictions
        
        pred_classes = pred_classes.numpy()
        targets_np = targets.numpy()
        pred_probs_np = pred_probs.numpy()
        
        # Basic metrics
        results["accuracy"] = accuracy_score(targets_np, pred_classes)
        
        # Precision, recall, F1
        results["precision"] = precision_score(
            targets_np, pred_classes,
            average=self.config.average,
            zero_division=0
        )
        results["recall"] = recall_score(
            targets_np, pred_classes,
            average=self.config.average,
            zero_division=0
        )
        results["f1"] = f1_score(
            targets_np, pred_classes,
            average=self.config.average,
            zero_division=0
        )
        
        # Confusion matrix
        cm = confusion_matrix(targets_np, pred_classes)
        results["confusion_matrix"] = float(np.sum(cm))  # Store as scalar for logging
        
        # Per-class metrics
        if self.config.num_classes <= 20:
            for i in range(min(self.config.num_classes, len(np.unique(targets_np)))):
                mask = targets_np == i
                if mask.sum() > 0:
                    class_precision = precision_score(
                        mask, pred_classes == i, zero_division=0
                    )
                    class_recall = recall_score(
                        mask, pred_classes == i, zero_division=0
                    )
                    results[f"precision_class_{i}"] = class_precision
                    results[f"recall_class_{i}"] = class_recall
        
        # Top-k accuracy
        if predictions.ndim == 2 and self.config.top_k > 1:
            top_k_preds = torch.topk(predictions, min(self.config.top_k, predictions.size(1)), dim=1)[1]
            top_k_correct = 0
            for i in range(predictions.size(0)):
                if targets_np[i] in top_k_preds[i].numpy():
                    top_k_correct += 1
            results[f"top_{self.config.top_k}_accuracy"] = top_k_correct / predictions.size(0)
        
        # AUC and PR-AUC (only for multiclass or binary)
        if predictions.ndim == 2:
            if self.config.num_classes == 2:
                # Binary classification
                try:
                    results["auc"] = roc_auc_score(targets_np, pred_probs_np[:, 1])
                    results["average_precision"] = average_precision_score(
                        targets_np, pred_probs_np[:, 1]
                    )
                except ValueError:
                    results["auc"] = 0.0
                    results["average_precision"] = 0.0
            else:
                # Multiclass
                try:
                    results["auc"] = roc_auc_score(
                        targets_np, pred_probs_np,
                        multi_class='ovr',
                        average=self.config.average
                    )
                except ValueError:
                    results["auc"] = 0.0
        
        # Loss
        if self.losses:
            results["loss"] = np.mean(self.losses)
        
        return results
    
    def _compute_regression_metrics(
        self,
        predictions: torch.Tensor,
        targets: torch.Tensor
    ) -> Dict[str, float]:
        """Compute regression metrics."""
        results = {}
        
        predictions_np = predictions.numpy().flatten()
        targets_np = targets.numpy().flatten()
        
        # MSE and RMSE
        results["mse"] = mean_squared_error(targets_np, predictions_np)
        results["rmse"] = np.sqrt(results["mse"])
        
        # MAE
        results["mae"] = mean_absolute_error(targets_np, predictions_np)
        
        # R2 score
        results["r2"] = r2_score(targets_np, predictions_np)
        
        # MAPE
        try:
            results["mape"] = mean_absolute_percentage_error(targets_np, predictions_np)
        except Exception:
            results["mape"] = float('inf')
        
        # Explained variance
        diff = targets_np - predictions_np
        var_pred = np.var(predictions_np)
        var_diff = np.var(diff)
        if var_pred > 0:
            results["explained_variance"] = 1 - (var_diff / var_pred)
        else:
            results["explained_variance"] = 0.0
        
        # Median absolute error (robust to outliers)
        results["median_ae"] = np.median(np.abs(targets_np - predictions_np))
        
        # Loss
        if self.losses:
            results["loss"] = np.mean(self.losses)
        
        return results
    
    def get_summary(self) -> str:
        """
        Get formatted summary of metrics.
        
        Returns:
            Formatted string with all metrics
        """
        results = self.compute()
        
        if not results:
            return "No metrics to display"
        
        lines = ["Metrics Summary:", "=" * 40]
        
        for key, value in sorted(results.items()):
            if isinstance(value, float):
                lines.append(f"  {key}: {value:.4f}")
            else:
                lines.append(f"  {key}: {value}")
        
        return "\n".join(lines)


def compute_accuracy(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    top_k: int = 1
) -> float:
    """
    Compute top-k accuracy.
    
    Args:
        predictions: Model predictions (logits or probabilities)
        targets: Ground truth labels
        top_k: Top-k accuracy to compute
        
    Returns:
        Top-k accuracy value
    """
    if predictions.ndim == 1:
        predictions = predictions.unsqueeze(0)
    
    top_k_preds = torch.topk(predictions, min(top_k, predictions.size(1)), dim=1)[1]
    targets_expanded = targets.view(-1, 1).expand_as(top_k_preds)
    
    correct = (top_k_preds == targets_expanded).any(dim=1).float()
    return correct.mean().item()


def compute_confusion_matrix(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    num_classes: int
) -> np.ndarray:
    """
    Compute confusion matrix.
    
    Args:
        predictions: Predicted class indices
        targets: Ground truth class indices
        num_classes: Total number of classes
        
    Returns:
        Confusion matrix as numpy array
    """
    pred_classes = predictions.argmax(dim=1) if predictions.ndim > 1 else predictions
    return confusion_matrix(targets.numpy(), pred_classes.numpy(), labels=range(num_classes))


def compute_per_class_metrics(
    predictions: torch.Tensor,
    targets: torch.Tensor,
    num_classes: int
) -> Dict[int, Dict[str, float]]:
    """
    Compute per-class precision, recall, and F1.
    
    Args:
        predictions: Model predictions
        targets: Ground truth labels
        num_classes: Number of classes
        
    Returns:
        Dictionary mapping class index to metrics
    """
    pred_classes = predictions.argmax(dim=1) if predictions.ndim > 1 else predictions
    pred_np = pred_classes.numpy()
    targets_np = targets.numpy()
    
    results = {}
    
    for i in range(num_classes):
        mask = targets_np == i
        if mask.sum() == 0:
            continue
        
        pred_mask = pred_np == i
        
        tp = np.sum(mask & pred_mask)
        fp = np.sum(~mask & pred_mask)
        fn = np.sum(mask & ~pred_mask)
        
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        
        results[i] = {
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "support": int(mask.sum())
        }
    
    return results
