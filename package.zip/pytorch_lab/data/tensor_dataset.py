"""
Tensor Dataset Module
=====================

Provides dataset classes for tensor data with easy data loader creation.

Author: MiniMax Agent
"""

import torch
from torch.utils.data import Dataset, DataLoader, Subset
import numpy as np
from typing import Dict, Any, Optional, Tuple, List, Callable, Union
from pathlib import Path

from pytorch_lab.data.dataset_base import BaseDataset, DatasetConfig


class TensorDataset(BaseDataset):
    """
    Dataset for numpy arrays or PyTorch tensors.
    
    Provides easy initialization from numpy arrays or tensors
    with optional transforms.
    
    Example:
        >>> dataset = TensorDataset(X_train, y_train, transform=transform)
        >>> loader = DataLoader(dataset, batch_size=32, shuffle=True)
    """
    
    def __init__(
        self,
        data: Union[np.ndarray, torch.Tensor],
        labels: Optional[Union[np.ndarray, torch.Tensor]] = None,
        config: Optional[DatasetConfig] = None,
        transform: Optional[Callable] = None,
        target_transform: Optional[Callable] = None
    ):
        """
        Initialize tensor dataset.
        
        Args:
            data: Input data (N x D or N x C x H x W for images)
            labels: Optional labels (N,)
            config: Dataset configuration
            transform: Optional transform for inputs
            target_transform: Optional transform for labels
        """
        super().__init__(config=config, transform=transform, target_transform=target_transform)
        
        # Convert to numpy arrays if tensors
        if isinstance(data, torch.Tensor):
            self.data = data.numpy()
        else:
            self.data = np.asarray(data)
        
        if labels is not None:
            if isinstance(labels, torch.Tensor):
                self.labels = labels.numpy()
            else:
                self.labels = np.asarray(labels)
        else:
            self.labels = None
        
        self.num_samples = len(self.data)
        
        # Infer num_classes from labels if available
        if self.labels is not None and self.config.num_classes is None:
            self.config.num_classes = len(np.unique(self.labels))
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Get single sample.
        
        Args:
            idx: Sample index
            
        Returns:
            Tuple of (input, target) tensors
        """
        # Get data
        x = self.data[idx]
        
        # Convert to tensor if numpy array
        if isinstance(x, np.ndarray):
            x = torch.from_numpy(x)
        
        # Handle data type
        if x.dtype == np.uint8:
            x = x.float() / 255.0
        
        # Apply input transform
        x = self._apply_transform(x)
        
        # Get and process label
        if self.labels is not None:
            y = self.labels[idx]
            
            if isinstance(y, np.ndarray):
                y = torch.from_numpy(y)
            
            y = y.long() if y.ndim == 0 else y
            
            y = self._apply_target_transform(y)
            
            return x, y
        
        return x, torch.tensor(-1)  # Return dummy label if no labels
    
    def get_data_sample(self, idx: int) -> torch.Tensor:
        """
        Get data sample without label.
        
        Args:
            idx: Sample index
            
        Returns:
            Input tensor
        """
        x = self.data[idx]
        
        if isinstance(x, np.ndarray):
            x = torch.from_numpy(x)
        
        if x.dtype == np.uint8:
            x = x.float() / 255.0
        
        return self._apply_transform(x)


def create_data_loaders(
    train_data: Union[np.ndarray, torch.Tensor],
    train_labels: Optional[Union[np.ndarray, torch.Tensor]],
    val_data: Optional[Union[np.ndarray, torch.Tensor]] = None,
    val_labels: Optional[Union[np.ndarray, torch.Tensor]] = None,
    test_data: Optional[Union[np.ndarray, torch.Tensor]] = None,
    test_labels: Optional[Union[np.ndarray, torch.Tensor]] = None,
    batch_size: int = 32,
    num_workers: int = 4,
    shuffle: bool = True,
    pin_memory: bool = True,
    train_transform: Optional[Callable] = None,
    val_transform: Optional[Callable] = None,
    test_transform: Optional[Callable] = None,
    val_split: Optional[float] = None
) -> Dict[str, DataLoader]:
    """
    Create data loaders from numpy arrays or tensors.
    
    Handles automatic splitting if validation data not provided.
    
    Args:
        train_data: Training data
        train_labels: Training labels
        val_data: Optional validation data
        val_labels: Optional validation labels
        test_data: Optional test data
        test_labels: Optional test labels
        batch_size: Batch size
        num_workers: Number of worker processes
        shuffle: Whether to shuffle training data
        pin_memory: Whether to pin memory for GPU transfer
        train_transform: Transform for training data
        val_transform: Transform for validation data
        test_transform: Transform for test data
        val_split: Validation split ratio (if val_data not provided)
        
    Returns:
        Dictionary with 'train', 'val', and 'test' data loaders
    """
    loaders = {}
    
    # Create training dataset
    train_dataset = TensorDataset(
        train_data,
        train_labels,
        transform=train_transform
    )
    
    # Create training loader
    loaders["train"] = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory
    )
    
    # Handle validation data
    if val_data is not None:
        val_dataset = TensorDataset(
            val_data,
            val_labels,
            transform=val_transform
        )
        loaders["val"] = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=pin_memory
        )
    elif val_split is not None and val_split > 0:
        # Split training data
        n = len(train_data)
        indices = np.random.permutation(n)
        val_size = int(n * val_split)
        
        train_indices = indices[val_size:]
        val_indices = indices[:val_size]
        
        train_dataset = TensorDataset(
            train_data[train_indices],
            train_labels[train_indices] if train_labels is not None else None,
            transform=train_transform
        )
        
        val_dataset = TensorDataset(
            train_data[val_indices],
            train_labels[val_indices] if train_labels is not None else None,
            transform=val_transform
        )
        
        loaders["train"] = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=num_workers,
            pin_memory=pin_memory
        )
        loaders["val"] = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=pin_memory
        )
    
    # Handle test data
    if test_data is not None:
        test_dataset = TensorDataset(
            test_data,
            test_labels,
            transform=test_transform
        )
        loaders["test"] = DataLoader(
            test_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=pin_memory
        )
    
    return loaders


class RandomSplitDataset(BaseDataset):
    """
    Dataset that randomly splits another dataset.
    """
    
    def __init__(
        self,
        dataset: BaseDataset,
        lengths: List[float],
        seed: int = 42
    ):
        """
        Initialize random split dataset.
        
        Args:
            dataset: Base dataset to split
            lengths: Split ratios (must sum to 1)
            seed: Random seed
        """
        super().__init__(config=dataset.config)
        
        self.dataset = dataset
        self.lengths = lengths
        
        # Generate random splits
        np.random.seed(seed)
        indices = np.random.permutation(len(dataset))
        
        # Compute split boundaries
        splits = []
        start = 0
        for length in lengths[:-1]:
            end = start + int(len(dataset) * length)
            splits.append(indices[start:end])
            start = end
        splits.append(indices[start:])
        
        self.splits = splits
        self.num_samples = len(dataset)
        self.current_split = 0
    
    def set_split(self, split_idx: int) -> None:
        """Set current split for iteration."""
        if split_idx >= len(self.splits):
            raise ValueError(f"Invalid split index {split_idx}")
        self.current_split = split_idx
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Get sample from current split."""
        if self.current_split >= len(self.splits):
            raise RuntimeError("No split selected")
        
        actual_idx = self.splits[self.current_split][idx]
        return self.dataset[actual_idx]


def create_splits_from_indices(
    dataset: BaseDataset,
    train_indices: List[int],
    val_indices: List[int],
    test_indices: Optional[List[int]] = None,
    batch_size: int = 32,
    num_workers: int = 4,
    train_transform: Optional[Callable] = None,
    val_transform: Optional[Callable] = None
) -> Dict[str, DataLoader]:
    """
    Create data loaders from pre-defined indices.
    
    Args:
        dataset: Base dataset
        train_indices: Training indices
        val_indices: Validation indices
        test_indices: Optional test indices
        batch_size: Batch size
        num_workers: Number of workers
        train_transform: Training transform
        val_transform: Validation transform
        
    Returns:
        Dictionary with data loaders
    """
    loaders = {}
    
    # Training loader
    train_subset = Subset(dataset, train_indices)
    loaders["train"] = DataLoader(
        train_subset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers
    )
    
    # Validation loader
    val_subset = Subset(dataset, val_indices)
    loaders["val"] = DataLoader(
        val_subset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers
    )
    
    # Test loader if indices provided
    if test_indices is not None:
        test_subset = Subset(dataset, test_indices)
        loaders["test"] = DataLoader(
            test_subset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers
        )
    
    return loaders
