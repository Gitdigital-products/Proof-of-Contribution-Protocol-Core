"""
Dataset Base Module
===================

Provides abstract base class for datasets with consistent interface
and configuration management.

Author: MiniMax Agent
"""

import torch
from torch.utils.data import Dataset
from typing import Dict, Any, Optional, Tuple, List, Callable
from dataclasses import dataclass, field
import numpy as np
from pathlib import Path


@dataclass
class DatasetConfig:
    """
    Configuration for dataset.
    
    Attributes:
        name: Dataset name
        data_dir: Directory containing data
        num_classes: Number of classes
        image_size: Image dimensions (for image datasets)
        normalize: Whether to normalize data
        augment: Whether to apply data augmentation
        val_split: Validation split ratio
        test_split: Test split ratio
        seed: Random seed for reproducibility
    """
    name: str = "base_dataset"
    data_dir: str = "./data"
    num_classes: int = 10
    image_size: Tuple[int, int] = (32, 32)
    normalize: bool = True
    augment: bool = False
    val_split: float = 0.2
    test_split: float = 0.1
    seed: int = 42


class BaseDataset(Dataset):
    """
    Abstract base class for datasets.
    
    Provides common functionality for data loading, preprocessing,
    and split management.
    
    Subclasses must implement:
    - __len__(): Return dataset size
    - __getitem__(): Return single sample
    
    Example:
        class MyDataset(BaseDataset):
            def __len__(self):
                return len(self.data)
            
            def __getitem__(self, idx):
                return self.data[idx], self.labels[idx]
    """
    
    def __init__(
        self,
        config: Optional[DatasetConfig] = None,
        split: str = "train",
        transform: Optional[Callable] = None,
        target_transform: Optional[Callable] = None
    ):
        """
        Initialize dataset.
        
        Args:
            config: Dataset configuration
            split: Dataset split ('train', 'val', 'test')
            transform: Optional transform for inputs
            target_transform: Optional transform for labels
        """
        self.config = config or DatasetConfig()
        self.split = split
        self.transform = transform
        self.target_transform = target_transform
        
        # Set random seed for reproducibility
        if self.config.seed is not None:
            np.random.seed(self.config.seed)
            torch.manual_seed(self.config.seed)
        
        # Initialize data arrays
        self.data: Optional[np.ndarray] = None
        self.labels: Optional[np.ndarray] = None
        self.num_samples = 0
    
    def __len__(self) -> int:
        """Return dataset size."""
        return self.num_samples
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Get single sample.
        
        Args:
            idx: Sample index
            
        Returns:
            Tuple of (input, target) tensors
        """
        raise NotImplementedError("Subclasses must implement __getitem__")
    
    def _apply_transform(self, x: Any) -> Any:
        """Apply input transform if defined."""
        if self.transform is not None:
            return self.transform(x)
        return x
    
    def _apply_target_transform(self, y: Any) -> Any:
        """Apply target transform if defined."""
        if self.target_transform is not None:
            return self.target_transform(y)
        return y
    
    def get_class_distribution(self) -> Dict[int, int]:
        """
        Get distribution of classes in dataset.
        
        Returns:
            Dictionary mapping class index to count
        """
        if self.labels is None:
            return {}
        
        unique, counts = np.unique(self.labels, return_counts=True)
        return dict(zip(unique, counts))
    
    def get_sample(self, idx: int) -> Dict[str, Any]:
        """
        Get sample with full information.
        
        Args:
            idx: Sample index
            
        Returns:
            Dictionary with sample data and metadata
        """
        x, y = self[idx]
        
        return {
            "input": x,
            "target": y,
            "index": idx,
            "split": self.split,
        }
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get dataset statistics.
        
        Returns:
            Dictionary with dataset statistics
        """
        stats = {
            "name": self.config.name,
            "split": self.split,
            "num_samples": self.num_samples,
            "num_classes": self.config.num_classes,
        }
        
        if self.labels is not None:
            stats["class_distribution"] = self.get_class_distribution()
        
        if self.data is not None:
            stats["data_shape"] = list(self.data.shape)
            stats["data_dtype"] = str(self.data.dtype)
        
        return stats
    
    def split_dataset(
        indices: List[int],
        val_split: float = 0.2,
        test_split: float = 0.1,
        seed: int = 42
    ) -> Tuple[List[int], List[int], List[int]]:
        """
        Split dataset indices into train/val/test.
        
        Args:
            indices: List of dataset indices
            val_split: Validation split ratio
            test_split: Test split ratio
            seed: Random seed
            
        Returns:
            Tuple of (train_indices, val_indices, test_indices)
        """
        np.random.seed(seed)
        indices = np.array(indices)
        np.random.shuffle(indices)
        
        n = len(indices)
        test_size = int(n * test_split)
        val_size = int(n * val_split)
        
        test_indices = indices[:test_size].tolist()
        val_indices = indices[test_size:test_size + val_size].tolist()
        train_indices = indices[test_size + val_size:].tolist()
        
        return train_indices, val_indices, test_indices
    
    def save_subset(
        self,
        indices: List[int],
        output_path: str
    ) -> None:
        """
        Save subset of dataset to file.
        
        Args:
            indices: Indices to save
            output_path: Path to save data
        """
        subset_data = self.data[indices] if self.data is not None else None
        subset_labels = self.labels[indices] if self.labels is not None else None
        
        torch.save({
            "data": subset_data,
            "labels": subset_labels,
            "config": self.config.__dict__,
        }, output_path)
    
    @classmethod
    def load_subset(
        cls,
        path: str,
        split: str = "test"
    ) -> "BaseDataset":
        """
        Load dataset subset from file.
        
        Args:
            path: Path to saved subset
            split: Split name for loaded data
            
        Returns:
            Dataset instance
        """
        checkpoint = torch.load(path)
        
        dataset = cls(
            config=DatasetConfig(**checkpoint["config"]),
            split=split
        )
        
        dataset.data = checkpoint["data"]
        dataset.labels = checkpoint["labels"]
        dataset.num_samples = len(dataset.data)
        
        return dataset


class TransformedDataset(BaseDataset):
    """
    Dataset that applies transforms to another dataset.
    
    Useful for applying augmentations or preprocessing pipelines.
    """
    
    def __init__(
        self,
        base_dataset: BaseDataset,
        transform: Optional[Callable] = None,
        target_transform: Optional[Callable] = None
    ):
        """
        Initialize transformed dataset.
        
        Args:
            base_dataset: Underlying dataset
            transform: Transform to apply to inputs
            target_transform: Transform to apply to targets
        """
        super().__init__(
            config=base_dataset.config,
            split=base_dataset.split
        )
        
        self.base_dataset = base_dataset
        self.transform = transform or base_dataset.transform
        self.target_transform = target_transform or base_dataset.target_transform
        self.num_samples = len(base_dataset)
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Get transformed sample."""
        x, y = self.base_dataset[idx]
        
        x = self._apply_transform(x)
        y = self._apply_target_transform(y)
        
        return x, y


class ConcatDataset(BaseDataset):
    """
    Dataset that concatenates multiple datasets.
    """
    
    def __init__(self, datasets: List[BaseDataset]):
        """
        Initialize concatenated dataset.
        
        Args:
            datasets: List of datasets to concatenate
        """
        super().__init__()
        
        self.datasets = datasets
        self.num_samples = sum(len(d) for d in datasets)
        
        # Use config from first dataset
        if datasets:
            self.config = datasets[0].config
    
    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        """Get sample from appropriate dataset."""
        cumsum = 0
        for dataset in self.datasets:
            if idx < cumsum + len(dataset):
                return dataset[idx - cumsum]
            cumsum += len(dataset)
        
        raise IndexError(f"Index {idx} out of range")
