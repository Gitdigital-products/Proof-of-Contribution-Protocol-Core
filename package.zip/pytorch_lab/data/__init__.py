"""
Data Module
===========

Provides dataset classes and data loading utilities for PyTorch models.

Author: MiniMax Agent
"""

from pytorch_lab.data.dataset_base import BaseDataset, DatasetConfig
from pytorch_lab.data.tensor_dataset import TensorDataset, create_data_loaders

__all__ = [
    "BaseDataset",
    "DatasetConfig",
    "TensorDataset",
    "create_data_loaders",
]
