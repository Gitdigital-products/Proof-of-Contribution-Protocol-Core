"""
Audit Log Module
================

Provides comprehensive audit logging for training runs,
model changes, and system events.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from pathlib import Path
import json
import logging
from datetime import datetime
from enum import Enum
import hashlib


class EventType(Enum):
    """Types of auditable events."""
    TRAINING_START = "training_start"
    TRAINING_END = "training_end"
    EPOCH_COMPLETE = "epoch_complete"
    VALIDATION_COMPLETE = "validation_complete"
    CHECKPOINT_SAVED = "checkpoint_saved"
    CHECKPOINT_LOADED = "checkpoint_loaded"
    MODEL_CREATED = "model_created"
    MODEL_MODIFIED = "model_modified"
    MODEL_DEPLOYED = "model_deployed"
    CONFIG_CHANGED = "config_changed"
    HYPERPARAMETER_TUNED = "hyperparameter_tuned"
    DATA_LOADED = "data_loaded"
    METRIC_LOGGED = "metric_logged"
    ERROR_OCCURRED = "error_occurred"
    CUSTOM = "custom"


@dataclass
class AuditEntry:
    """
    Single audit log entry.
    
    Attributes:
        timestamp: Event timestamp
        event_type: Type of event
        event_id: Unique event identifier
        user_info: User/system information
        model_info: Model-related information
        config_snapshot: Configuration at time of event
        metrics: Metrics associated with event
        details: Additional event details
        checksum: Integrity checksum
    """
    timestamp: str
    event_type: str
    event_id: str
    user_info: Dict[str, Any] = field(default_factory=dict)
    model_info: Dict[str, Any] = field(default_factory=dict)
    config_snapshot: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    details: Dict[str, Any] = field(default_factory=dict)
    checksum: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert entry to dictionary."""
        return {
            "timestamp": self.timestamp,
            "event_type": self.event_type,
            "event_id": self.event_id,
            "user_info": self.user_info,
            "model_info": self.model_info,
            "config_snapshot": self.config_snapshot,
            "metrics": self.metrics,
            "details": self.details,
            "checksum": self.checksum,
        }


class AuditLogger:
    """
    Comprehensive audit logging for model development.
    
    Tracks all significant events during model lifecycle
    with integrity verification and querying capabilities.
    
    Example:
        >>> logger = AuditLogger("./audit_logs")
        >>> logger.log_event(EventType.TRAINING_START, model=model)
        >>> logger.log_metrics(epoch=0, loss=0.5, accuracy=0.9)
    """
    
    def __init__(
        self,
        log_dir: str = "./audit_logs",
        log_level: int = logging.INFO,
        verify_checksums: bool = True
    ):
        """
        Initialize audit logger.
        
        Args:
            log_dir: Directory to store log files
            log_level: Logging level
            verify_checksums: Whether to verify entry checksums
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        self.verify_checksums = verify_checksums
        self.current_session_id = self._generate_session_id()
        
        # Setup file logger
        self.log_file = self.log_dir / f"audit_{self.current_session_id}.jsonl"
        
        # Setup Python logger
        self.logger = logging.getLogger(f"audit_{self.current_session_id}")
        self.logger.setLevel(log_level)
        
        handler = logging.FileHandler(self.log_dir / f"audit_{self.current_session_id}.log")
        handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        self.logger.addHandler(handler)
        
        # Event counter
        self.event_count = 0
        
        # Log session start
        self._log_session_start()
    
    def _generate_session_id(self) -> str:
        """Generate unique session ID."""
        timestamp = datetime.now().isoformat()
        session_hash = hashlib.md5(timestamp.encode()).hexdigest()[:8]
        return f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{session_hash}"
    
    def _generate_event_id(self) -> str:
        """Generate unique event ID."""
        self.event_count += 1
        return f"{self.current_session_id}_event_{self.event_count}"
    
    def _compute_checksum(self, entry: AuditEntry) -> str:
        """Compute checksum for entry integrity."""
        data = f"{entry.timestamp}{entry.event_type}{entry.event_id}"
        return hashlib.sha256(data.encode()).hexdigest()[:16]
    
    def _log_session_start(self) -> None:
        """Log session start event."""
        self.log_event(
            EventType.TRAINING_START,
            details={"session_id": self.current_session_id},
            user_info={"system": "tinkerflow_ai"}
        )
    
    def log_event(
        self,
        event_type: EventType,
        model: Optional[nn.Module] = None,
        config: Optional[Dict[str, Any]] = None,
        metrics: Optional[Dict[str, float]] = None,
        details: Optional[Dict[str, Any]] = None,
        user_info: Optional[Dict[str, Any]] = None
    ) -> AuditEntry:
        """
        Log an audit event.
        
        Args:
            event_type: Type of event
            model: Optional model for model-related info
            config: Optional configuration snapshot
            metrics: Optional metrics
            details: Optional additional details
            user_info: Optional user/system info
            
        Returns:
            Created AuditEntry
        """
        # Get model info if provided
        model_info = {}
        if model is not None:
            model_info = self._get_model_info(model)
        
        # Create entry
        entry = AuditEntry(
            timestamp=datetime.now().isoformat(),
            event_type=event_type.value,
            event_id=self._generate_event_id(),
            user_info=user_info or {},
            model_info=model_info,
            config_snapshot=config or {},
            metrics=metrics or {},
            details=details or {}
        )
        
        # Compute checksum
        entry.checksum = self._compute_checksum(entry)
        
        # Write to JSONL file
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(entry.to_dict()) + '\n')
        
        # Log to Python logger
        self.logger.info(f"Event: {event_type.value} - {entry.event_id}")
        
        return entry
    
    def _get_model_info(self, model: nn.Module) -> Dict[str, Any]:
        """Get model information for logging."""
        info = {
            "class": model.__class__.__name__,
            "num_parameters": sum(p.numel() for p in model.parameters()),
            "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
        }
        
        if hasattr(model, "config"):
            info["config"] = model.config.__dict__ if hasattr(model.config, "__dict__") else {}
        
        if hasattr(model, "get_config_hash"):
            info["config_hash"] = model.get_config_hash()
        
        return info
    
    def log_metrics(
        self,
        epoch: int,
        step: Optional[int] = None,
        metrics: Optional[Dict[str, float]] = None,
        **kwargs: float
    ) -> AuditEntry:
        """
        Log training metrics.
        
        Args:
            epoch: Current epoch
            step: Current step
            metrics: Dictionary of metrics
            **kwargs: Additional metrics as keyword arguments
            
        Returns:
            Created AuditEntry
        """
        all_metrics = (metrics or {}).copy()
        all_metrics.update(kwargs)
        
        details = {"epoch": epoch}
        if step is not None:
            details["step"] = step
        
        return self.log_event(
            EventType.METRIC_LOGGED,
            details=details,
            metrics=all_metrics
        )
    
    def log_checkpoint(
        self,
        checkpoint_type: str,
        path: str,
        model: nn.Module,
        metrics: Optional[Dict[str, float]] = None
    ) -> AuditEntry:
        """
        Log checkpoint save/load event.
        
        Args:
            checkpoint_type: 'saved' or 'loaded'
            path: Checkpoint path
            model: Model being checkpointed
            metrics: Optional metrics
            
        Returns:
            Created AuditEntry
        """
        event_type = EventType.CHECKPOINT_SAVED if checkpoint_type == "saved" else EventType.CHECKPOINT_LOADED
        
        return self.log_event(
            event_type,
            model=model,
            details={"checkpoint_path": path, "type": checkpoint_type},
            metrics=metrics
        )
    
    def log_config_change(
        self,
        config_name: str,
        old_value: Any,
        new_value: Any,
        reason: Optional[str] = None
    ) -> AuditEntry:
        """
        Log configuration change.
        
        Args:
            config_name: Name of changed config
            old_value: Previous value
            new_value: New value
            reason: Optional reason for change
            
        Returns:
            Created AuditEntry
        """
        return self.log_event(
            EventType.CONFIG_CHANGED,
            details={
                "config_name": config_name,
                "old_value": str(old_value),
                "new_value": str(new_value),
                "reason": reason
            }
        )
    
    def log_error(
        self,
        error: Exception,
        context: Optional[Dict[str, Any]] = None
    ) -> AuditEntry:
        """
        Log error event.
        
        Args:
            error: Exception that occurred
            context: Optional error context
            
        Returns:
            Created AuditEntry
        """
        return self.log_event(
            EventType.ERROR_OCCURRED,
            details={
                "error_type": type(error).__name__,
                "error_message": str(error),
                "context": context or {}
            }
        )
    
    def query_events(
        self,
        event_type: Optional[str] = None,
        start_time: Optional[str] = None,
        end_time: Optional[str] = None,
        session_id: Optional[str] = None
    ) -> List[AuditEntry]:
        """
        Query audit log entries.
        
        Args:
            event_type: Filter by event type
            start_time: Filter by start time (ISO format)
            end_time: Filter by end time (ISO format)
            session_id: Filter by session ID
            
        Returns:
            List of matching entries
        """
        entries = []
        
        # Read from all log files in directory
        for log_file in sorted(self.log_dir.glob("audit_*.jsonl")):
            with open(log_file, 'r') as f:
                for line in f:
                    if not line.strip():
                        continue
                    
                    data = json.loads(line)
                    entry = AuditEntry(**data)
                    
                    # Apply filters
                    if event_type and entry.event_type != event_type:
                        continue
                    
                    if start_time and entry.timestamp < start_time:
                        continue
                    
                    if end_time and entry.timestamp > end_time:
                        continue
                    
                    if session_id and session_id not in entry.event_id:
                        continue
                    
                    # Verify checksum if enabled
                    if self.verify_checksums:
                        expected_checksum = self._compute_checksum(entry)
                        if entry.checksum != expected_checksum:
                            self.logger.warning(f"Checksum mismatch for event {entry.event_id}")
                    
                    entries.append(entry)
        
        return entries
    
    def get_training_summary(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get training summary from audit logs.
        
        Args:
            session_id: Optional specific session ID
            
        Returns:
            Summary dictionary
        """
        events = self.query_events(session_id=session_id or self.current_session_id)
        
        summary = {
            "total_events": len(events),
            "event_types": {},
            "metrics_history": [],
            "errors": [],
        }
        
        for event in events:
            # Count event types
            event_type = event.event_type
            summary["event_types"][event_type] = summary["event_types"].get(event_type, 0) + 1
            
            # Collect metrics
            if event.metrics:
                summary["metrics_history"].append({
                    "timestamp": event.timestamp,
                    "metrics": event.metrics
                })
            
            # Collect errors
            if event.event_type == EventType.ERROR_OCCURRED.value:
                summary["errors"].append(event.details)
        
        return summary
    
    def export_logs(self, output_path: str) -> None:
        """
        Export all logs to a single file.
        
        Args:
            output_path: Path for exported file
        """
        all_entries = []
        
        for log_file in sorted(self.log_dir.glob("audit_*.jsonl")):
            with open(log_file, 'r') as f:
                for line in f:
                    if line.strip():
                        all_entries.append(json.loads(line))
        
        with open(output_path, 'w') as f:
            json.dump(all_entries, f, indent=2)
    
    def close(self) -> None:
        """Close audit logger and flush handlers."""
        # Log session end
        self.log_event(
            EventType.TRAINING_END,
            details={"session_id": self.current_session_id}
        )
        
        # Close handlers
        for handler in self.logger.handlers[:]:
            handler.close()
            self.logger.removeHandler(handler)


def create_audit_logger(
    log_dir: str = "./audit_logs",
    log_level: int = logging.INFO
) -> AuditLogger:
    """
    Convenience function to create audit logger.
    
    Example:
        >>> logger = create_audit_logger()
    """
    return AuditLogger(log_dir=log_dir, log_level=log_level)
