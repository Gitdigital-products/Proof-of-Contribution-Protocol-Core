"""
Model Versioning Module
=======================

Provides model versioning for tracking changes and reproducibility.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from pathlib import Path
import json
import hashlib
from datetime import datetime
from collections import OrderedDict


@dataclass
class VersionInfo:
    """
    Information about a model version.
    
    Attributes:
        version: Version string (e.g., "1.0.0")
        parent_version: Parent version if any
        timestamp: Creation timestamp
        model_hash: Hash of model architecture
        checkpoint_hash: Hash of model weights
        config: Model configuration
        metrics: Training metrics
        notes: Version notes
        tags: List of tags
    """
    version: str
    parent_version: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    model_hash: str = ""
    checkpoint_hash: str = ""
    config: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, float] = field(default_factory=dict)
    notes: str = ""
    tags: List[str] = field(default_factory=list)


class ModelVersioning:
    """
    Manages model versions for reproducibility and tracking.
    
    Maintains a version history with metadata, computes model hashes,
    and enables reverting to previous versions.
    
    Example:
        >>> versioning = ModelVersioning("./versions")
        >>> versioning.create_version(model, "1.0.0", metrics={"acc": 0.95})
        >>> versioning.list_versions()
    """
    
    def __init__(self, version_dir: str = "./model_versions"):
        """
        Initialize model versioning.
        
        Args:
            version_dir: Directory to store version data
        """
        self.version_dir = Path(version_dir)
        self.version_dir.mkdir(parents=True, exist_ok=True)
        
        self.versions_file = self.version_dir / "versions.json"
        self.versions: OrderedDict[str, VersionInfo] = {}
        
        self._load_versions()
    
    def _load_versions(self) -> None:
        """Load version history from file."""
        if self.versions_file.exists():
            with open(self.versions_file, 'r') as f:
                data = json.load(f)
                self.versions = OrderedDict(
                    (k, VersionInfo(**v)) for k, v in data.items()
                )
    
    def _save_versions(self) -> None:
        """Save version history to file."""
        data = {k: v.__dict__ for k, v in self.versions.items()}
        
        with open(self.versions_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def _compute_model_hash(self, model: nn.Module) -> str:
        """
        Compute hash of model architecture.
        
        Args:
            model: PyTorch model
            
        Returns:
            Hash string
        """
        # Get architecture structure
        arch_str = []
        for name, module in model.named_modules():
            if len(list(module.children())) == 0:  # Leaf modules only
                arch_str.append(f"{name}:{module.__class__.__name__}")
        
        arch_str = sorted(arch_str)
        arch_hash = hashlib.md5(str(arch_str).encode()).hexdigest()[:12]
        
        return arch_hash
    
    def _compute_checkpoint_hash(
        self,
        model: nn.Module,
        state_dict: Dict[str, torch.Tensor]
    ) -> str:
        """
        Compute hash of model weights.
        
        Args:
            model: PyTorch model
            state_dict: Model state dictionary
            
        Returns:
            Hash string
        """
        # Get parameter shapes and types
        param_info = []
        for key, value in sorted(state_dict.items()):
            param_info.append(f"{key}:{value.shape}:{value.dtype}")
        
        param_str = str(param_info)
        return hashlib.md5(param_str.encode()).hexdigest()[:12]
    
    def create_version(
        self,
        model: nn.Module,
        version: str,
        checkpoint_path: Optional[str] = None,
        metrics: Optional[Dict[str, float]] = None,
        notes: str = "",
        tags: Optional[List[str]] = None,
        parent_version: Optional[str] = None
    ) -> VersionInfo:
        """
        Create new model version.
        
        Args:
            model: PyTorch model
            version: Version string
            checkpoint_path: Optional path to save checkpoint
            metrics: Optional training metrics
            notes: Version notes
            tags: Optional list of tags
            parent_version: Parent version if creating from existing
            
        Returns:
            VersionInfo for created version
        """
        # Get model state
        state_dict = model.state_dict()
        
        # Compute hashes
        model_hash = self._compute_model_hash(model)
        checkpoint_hash = self._compute_checkpoint_hash(model, state_dict)
        
        # Get model config if available
        config = {}
        if hasattr(model, "config"):
            config = model.config.__dict__ if hasattr(model.config, "__dict__") else {}
        
        # Determine parent version
        if parent_version is None and self.versions:
            parent_version = list(self.versions.keys())[-1]
        
        # Create version info
        version_info = VersionInfo(
            version=version,
            parent_version=parent_version,
            model_hash=model_hash,
            checkpoint_hash=checkpoint_hash,
            config=config,
            metrics=metrics or {},
            notes=notes,
            tags=tags or []
        )
        
        # Save checkpoint if path provided
        if checkpoint_path is not None:
            checkpoint_full_path = Path(checkpoint_path)
            checkpoint_full_path.parent.mkdir(parents=True, exist_ok=True)
            
            checkpoint_data = {
                "version": version,
                "model_state_dict": state_dict,
                "model_class": model.__class__.__name__,
                "metrics": metrics or {},
                "timestamp": version_info.timestamp,
            }
            
            torch.save(checkpoint_data, checkpoint_full_path)
        
        # Store version
        self.versions[version] = version_info
        self._save_versions()
        
        return version_info
    
    def get_version(self, version: str) -> Optional[VersionInfo]:
        """
        Get version information.
        
        Args:
            version: Version string
            
        Returns:
            VersionInfo if found, None otherwise
        """
        return self.versions.get(version)
    
    def list_versions(self) -> List[VersionInfo]:
        """
        List all versions.
        
        Returns:
            List of VersionInfo objects
        """
        return list(self.versions.values())
    
    def load_version(
        self,
        version: str,
        model: nn.Module,
        device: Optional[torch.device] = None
    ) -> bool:
        """
        Load model weights from specific version.
        
        Args:
            version: Version string
            model: Model to load weights into
            device: Device to map tensors to
            
        Returns:
            True if loaded successfully
        """
        if version not in self.versions:
            return False
        
        version_info = self.versions[version]
        
        # Look for checkpoint file
        checkpoint_path = self.version_dir / f"checkpoint_{version}.pt"
        
        if not checkpoint_path.exists():
            # Try to find in default location
            checkpoint_path = Path(f"./checkpoints/checkpoint_best.pt")
        
        if checkpoint_path.exists():
            checkpoint = torch.load(checkpoint_path, map_location=device)
            model.load_state_dict(checkpoint["model_state_dict"])
            return True
        
        return False
    
    def compare_versions(
        self,
        version1: str,
        version2: str
    ) -> Dict[str, Any]:
        """
        Compare two model versions.
        
        Args:
            version1: First version
            version2: Second version
            
        Returns:
            Dictionary with comparison results
        """
        v1 = self.versions.get(version1)
        v2 = self.versions.get(version2)
        
        if v1 is None or v2 is None:
            raise ValueError("One or both versions not found")
        
        return {
            "version1": version1,
            "version2": version2,
            "architecture_changed": v1.model_hash != v2.model_hash,
            "weights_changed": v1.checkpoint_hash != v2.checkpoint_hash,
            "metrics_diff": {
                k: v2.metrics.get(k, 0) - v1.metrics.get(k, 0)
                for k in set(v1.metrics.keys()) | set(v2.metrics.keys())
            },
            "time_diff": v2.timestamp != v1.timestamp,
        }
    
    def delete_version(self, version: str) -> bool:
        """
        Delete a version (keeps metadata, removes checkpoint).
        
        Args:
            version: Version to delete
            
        Returns:
            True if deleted successfully
        """
        if version not in self.versions:
            return False
        
        # Remove checkpoint file
        checkpoint_path = self.version_dir / f"checkpoint_{version}.pt"
        if checkpoint_path.exists():
            checkpoint_path.unlink()
        
        # Remove from versions
        del self.versions[version]
        self._save_versions()
        
        return True
    
    def tag_version(
        self,
        version: str,
        tag: str
    ) -> bool:
        """
        Add tag to version.
        
        Args:
            version: Version string
            tag: Tag to add
            
        Returns:
            True if successful
        """
        if version not in self.versions:
            return False
        
        if tag not in self.versions[version].tags:
            self.versions[version].tags.append(tag)
            self._save_versions()
        
        return True
    
    def get_versions_by_tag(self, tag: str) -> List[VersionInfo]:
        """
        Get all versions with specific tag.
        
        Args:
            tag: Tag to search for
            
        Returns:
            List of matching versions
        """
        return [v for v in self.versions.values() if tag in v.tags]


def create_version_tag(
    version: str,
    tag_type: str = "release"
) -> str:
    """
    Create formatted version tag.
    
    Args:
        version: Version string
        tag_type: Type of tag ('release', 'beta', 'alpha')
        
    Returns:
        Formatted tag string
    """
    prefixes = {
        "release": "v",
        "beta": "beta",
        "alpha": "alpha",
    }
    
    prefix = prefixes.get(tag_type, "v")
    return f"{prefix}{version}"
