"""
Checkpoints Module
==================

Provides checkpoint management for model saving, loading,
and lifecycle tracking.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, field
from pathlib import Path
import json
import shutil
from datetime import datetime
import hashlib


@dataclass
class CheckpointConfig:
    """
    Configuration for checkpoint management.
    
    Attributes:
        checkpoint_dir: Directory to save checkpoints
        save_best_only: Only save when model improves
        max_checkpoints: Maximum number of checkpoints to keep
        save_frequency: Save every N epochs
        monitor_metric: Metric to monitor for best model
        mode: 'min' or 'max' for metric
    """
    checkpoint_dir: str = "./checkpoints"
    save_best_only: bool = True
    max_checkpoints: int = 5
    save_frequency: int = 1
    monitor_metric: str = "val_loss"
    mode: str = "min"


class CheckpointManager:
    """
    Manages model checkpoints with versioning and cleanup.
    
    Handles saving, loading, and automatic cleanup of checkpoints
    based on configured policies.
    
    Example:
        >>> manager = CheckpointManager(config)
        >>> manager.save_checkpoint(model, optimizer, epoch, metrics)
        >>> manager.load_checkpoint(model, "best")
    """
    
    def __init__(self, config: Optional[CheckpointConfig] = None):
        """
        Initialize checkpoint manager.
        
        Args:
            config: Checkpoint configuration
        """
        self.config = config or CheckpointConfig()
        self.checkpoint_dir = Path(self.config.checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        # Track checkpoints
        self.checkpoints: List[Dict[str, Any]] = []
        self._load_checkpoint_history()
    
    def _get_checkpoint_path(self, name: str) -> Path:
        """Get full path for checkpoint file."""
        return self.checkpoint_dir / f"checkpoint_{name}.pt"
    
    def _compute_checkpoint_hash(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None
    ) -> str:
        """
        Compute hash of model state for integrity checking.
        
        Args:
            model: PyTorch model
            optimizer: Optional optimizer
            
        Returns:
            Hash string
        """
        state_dict = model.state_dict()
        state_str = json.dumps(state_dict, sort_keys=True)
        return hashlib.md5(state_str.encode()).hexdigest()[:8]
    
    def save_checkpoint(
        self,
        model: nn.Module,
        optimizer: Optional[torch.optim.Optimizer] = None,
        scheduler: Optional[Any] = None,
        epoch: int = 0,
        step: int = 0,
        metrics: Optional[Dict[str, float]] = None,
        name: str = "latest",
        include_metadata: bool = True
    ) -> str:
        """
        Save model checkpoint.
        
        Args:
            model: PyTorch model
            optimizer: Optional optimizer
            scheduler: Optional scheduler
            epoch: Current epoch
            step: Current step
            metrics: Current metrics
            name: Checkpoint name suffix
            include_metadata: Include metadata in checkpoint
            
        Returns:
            Path to saved checkpoint
        """
        checkpoint_path = self._get_checkpoint_path(name)
        
        checkpoint = {
            "model_state_dict": model.state_dict(),
            "model_class": model.__class__.__name__,
            "epoch": epoch,
            "step": step,
            "timestamp": datetime.now().isoformat(),
        }
        
        if optimizer is not None:
            checkpoint["optimizer_state_dict"] = optimizer.state_dict()
        
        if scheduler is not None:
            checkpoint["scheduler_state_dict"] = scheduler.state_dict()
        
        if metrics is not None:
            checkpoint["metrics"] = metrics
        
        if include_metadata and hasattr(model, "config"):
            checkpoint["model_config"] = model.config.__dict__
        
        # Compute integrity hash
        checkpoint["model_hash"] = self._compute_checkpoint_hash(model, optimizer)
        
        torch.save(checkpoint, checkpoint_path)
        
        # Update history
        self._add_to_history(
            name=name,
            path=str(checkpoint_path),
            epoch=epoch,
            metrics=metrics
        )
        
        # Cleanup old checkpoints
        if self.config.save_best_only:
            self._cleanup_old_checkpoints()
        
        return str(checkpoint_path)
    
    def load_checkpoint(
        self,
        model: nn.Module,
        name: str = "best",
        device: Optional[torch.device] = None,
        load_optimizer: bool = False,
        load_scheduler: bool = False
    ) -> Dict[str, Any]:
        """
        Load model checkpoint.
        
        Args:
            model: PyTorch model to load into
            name: Checkpoint name ('best', 'latest', or epoch number)
            device: Device to map tensors to
            load_optimizer: Whether to load optimizer state
            load_scheduler: Whether to load scheduler state
            
        Returns:
            Checkpoint metadata
        """
        checkpoint_path = self._get_checkpoint_path(name)
        
        if not checkpoint_path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")
        
        checkpoint = torch.load(checkpoint_path, map_location=device)
        
        # Verify integrity
        if "model_hash" in checkpoint:
            current_hash = self._compute_checkpoint_hash(model)
            if current_hash != checkpoint["model_hash"]:
                print(f"Warning: Model hash mismatch. Checkpoint may be corrupted.")
        
        # Load model state
        model.load_state_dict(checkpoint["model_state_dict"])
        
        metadata = {
            "epoch": checkpoint.get("epoch", 0),
            "step": checkpoint.get("step", 0),
            "metrics": checkpoint.get("metrics", {}),
            "timestamp": checkpoint.get("timestamp", ""),
        }
        
        return metadata
    
    def get_latest_checkpoint(self) -> Optional[str]:
        """Get path to latest checkpoint."""
        latest = self.checkpoint_dir / "checkpoint_latest.pt"
        if latest.exists():
            return str(latest)
        return None
    
    def get_best_checkpoint(self) -> Optional[str]:
        """Get path to best checkpoint."""
        best = self.checkpoint_dir / "checkpoint_best.pt"
        if best.exists():
            return str(best)
        return None
    
    def list_checkpoints(self) -> List[Dict[str, Any]]:
        """
        List all available checkpoints.
        
        Returns:
            List of checkpoint information
        """
        return sorted(self.checkpoints, key=lambda x: x.get("epoch", 0))
    
    def delete_checkpoint(self, name: str) -> None:
        """
        Delete specific checkpoint.
        
        Args:
            name: Checkpoint name
        """
        checkpoint_path = self._get_checkpoint_path(name)
        
        if checkpoint_path.exists():
            checkpoint_path.unlink()
            self._remove_from_history(name)
    
    def _add_to_history(
        self,
        name: str,
        path: str,
        epoch: int,
        metrics: Optional[Dict[str, float]]
    ) -> None:
        """Add checkpoint to history."""
        entry = {
            "name": name,
            "path": path,
            "epoch": epoch,
            "metrics": metrics or {},
            "timestamp": datetime.now().isoformat(),
        }
        
        # Check if updating existing entry
        for i, e in enumerate(self.checkpoints):
            if e["name"] == name:
                self.checkpoints[i] = entry
                break
        else:
            self.checkpoints.append(entry)
        
        self._save_history()
    
    def _remove_from_history(self, name: str) -> None:
        """Remove checkpoint from history."""
        self.checkpoints = [e for e in self.checkpoints if e["name"] != name]
        self._save_history()
    
    def _load_checkpoint_history(self) -> None:
        """Load checkpoint history from file."""
        history_path = self.checkpoint_dir / "history.json"
        
        if history_path.exists():
            with open(history_path, 'r') as f:
                self.checkpoints = json.load(f)
        else:
            self.checkpoints = []
    
    def _save_history(self) -> None:
        """Save checkpoint history to file."""
        history_path = self.checkpoint_dir / "history.json"
        
        with open(history_path, 'w') as f:
            json.dump(self.checkpoints, f, indent=2)
    
    def _cleanup_old_checkpoints(self) -> None:
        """Remove old checkpoints keeping only best and latest."""
        if self.config.max_checkpoints <= 0:
            return
        
        # Keep best and latest
        keep_names = {"best", "latest"}
        
        # Add checkpoints that meet criteria
        checkpoints_to_keep = ["best", "latest"]
        
        for checkpoint in sorted(
            self.checkpoints,
            key=lambda x: x.get("metrics", {}).get(self.config.monitor_metric, float('inf'))
        ):
            if len(checkpoints_to_keep) >= self.config.max_checkpoints:
                break
            
            if checkpoint["name"] not in keep_names:
                checkpoints_to_keep.append(checkpoint["name"])
        
        # Delete others
        for checkpoint in self.checkpoints:
            if checkpoint["name"] not in checkpoints_to_keep:
                self.delete_checkpoint(checkpoint["name"])


def save_checkpoint_with_metadata(
    model: nn.Module,
    filepath: str,
    metadata: Dict[str, Any],
    optimizer: Optional[torch.optim.Optimizer] = None
) -> None:
    """
    Convenience function to save checkpoint with metadata.
    
    Example:
        >>> save_checkpoint_with_metadata(model, "model.pt", {"version": "1.0"})
    """
    checkpoint = {
        "model_state_dict": model.state_dict(),
        "metadata": metadata,
    }
    
    if optimizer is not None:
        checkpoint["optimizer_state_dict"] = optimizer.state_dict()
    
    torch.save(checkpoint, filepath)


def load_checkpoint_metadata(filepath: str) -> Dict[str, Any]:
    """
    Load metadata from checkpoint without loading model.
    
    Example:
        >>> metadata = load_checkpoint_metadata("model.pt")
    """
    checkpoint = torch.load(filepath, map_location="cpu")
    
    return {
        "metadata": checkpoint.get("metadata", {}),
        "epoch": checkpoint.get("epoch", None),
        "metrics": checkpoint.get("metrics", {}),
        "timestamp": checkpoint.get("timestamp", ""),
    }
