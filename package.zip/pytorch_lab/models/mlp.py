"""
MLP (Multi-Layer Perceptron) Model
==================================

Implements a flexible multi-layer perceptron with configurable depth,
width, activations, and regularization options.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field

from pytorch_lab.models.base_model import BaseModel, ModelConfig


@dataclass
class MLPConfig(ModelConfig):
    """
    Configuration for MLP model.
    
    Attributes:
        name: Model name
        input_dim: Input feature dimension
        output_dim: Output dimension (num classes or 1 for regression)
        hidden_dims: List of hidden layer sizes
        activation: Activation function ('relu', 'gelu', 'tanh', 'sigmoid')
        dropout: Dropout probability
        batch_norm: Whether to use batch normalization
        bias: Whether to use bias in linear layers
        residual: Whether to use residual connections
        layer_norm: Whether to use layer normalization
        seed: Random seed for reproducibility
    """
    name: str = "mlp"
    input_dim: int = 784
    output_dim: int = 10
    hidden_dims: List[int] = field(default_factory=lambda: [512, 256, 128])
    activation: str = "relu"
    dropout: float = 0.2
    batch_norm: bool = True
    bias: bool = True
    residual: bool = False
    layer_norm: bool = False
    seed: Optional[int] = None
    
    def __post_init__(self):
        """Validate MLP-specific configuration."""
        super().__post_init__()
        if self.residual and len(self.hidden_dims) < 2:
            raise ValueError("Residual connections require at least 2 hidden layers")


class MLPBlock(nn.Module):
    """
    Single MLP block with optional batch norm, dropout, and residual connection.
    """
    
    def __init__(
        self,
        in_features: int,
        out_features: int,
        activation: str = "relu",
        dropout: float = 0.0,
        batch_norm: bool = False,
        layer_norm: bool = False,
        bias: bool = True,
        residual: bool = False
    ):
        """
        Initialize MLP block.
        
        Args:
            in_features: Input dimension
            out_features: Output dimension
            activation: Activation function name
            dropout: Dropout probability
            batch_norm: Whether to use batch normalization
            layer_norm: Whether to use layer normalization
            bias: Whether to use bias in linear layer
            residual: Whether to add residual connection
        """
        super().__init__()
        
        self.residual = residual and (in_features == out_features)
        
        # Linear transformation
        self.linear = nn.Linear(in_features, out_features, bias=bias)
        
        # Normalization
        if batch_norm:
            self.norm = nn.BatchNorm1d(out_features)
        elif layer_norm:
            self.norm = nn.LayerNorm(out_features)
        else:
            self.norm = None
        
        # Activation
        self.activation = self._get_activation(activation)
        
        # Dropout
        self.dropout = nn.Dropout(dropout) if dropout > 0 else None
    
    def _get_activation(self, name: str) -> nn.Module:
        """Get activation function by name."""
        activations = {
            "relu": nn.ReLU(inplace=True),
            "gelu": nn.GELU(),
            "tanh": nn.Tanh(),
            "sigmoid": nn.Sigmoid(),
            "leaky_relu": nn.LeakyReLU(0.2, inplace=True),
            "elu": nn.ELU(inplace=True),
            "selu": nn.SELU(inplace=True),
            "softplus": nn.Softplus(),
            "none": nn.Identity(),
        }
        return activations.get(name.lower(), nn.ReLU(inplace=True))
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through MLP block.
        
        Args:
            x: Input tensor of shape (batch_size, in_features)
            
        Returns:
            Output tensor of shape (batch_size, out_features)
        """
        identity = x
        
        # Linear transformation
        out = self.linear(x)
        
        # Normalization (apply to last dimension)
        if self.norm is not None:
            if isinstance(self.norm, nn.BatchNorm1d):
                out = self.norm(out)
            else:
                out = self.norm(out)
        
        # Activation
        out = self.activation(out)
        
        # Dropout
        if self.dropout is not None:
            out = self.dropout(out)
        
        # Residual connection
        if self.residual:
            out = out + identity
        
        return out


class MLP(BaseModel):
    """
    Multi-Layer Perceptron with flexible architecture.
    
    Implements a fully-connected neural network with configurable:
    - Number of layers and hidden dimensions
    - Activation functions
    - Regularization (dropout, batch norm, layer norm)
    - Residual connections
    
    Example:
        >>> config = MLPConfig(input_dim=784, output_dim=10, hidden_dims=[512, 256])
        >>> model = MLP(config)
        >>> x = torch.randn(32, 784)
        >>> output = model(x)
        >>> output.shape
        torch.Size([32, 10])
    """
    
    def __init__(self, config: Optional[MLPConfig] = None):
        """
        Initialize MLP model.
        
        Args:
            config: MLP configuration (uses default if None)
        """
        if config is None:
            config = self.get_default_config()
        super().__init__(config)
    
    @staticmethod
    def get_default_config() -> MLPConfig:
        """Get default MLP configuration."""
        return MLPConfig(
            name="mlp",
            input_dim=784,
            output_dim=10,
            hidden_dims=[512, 256, 128],
            activation="relu",
            dropout=0.2,
            batch_norm=True,
            bias=True,
            residual=False,
            layer_norm=False,
            seed=None
        )
    
    def _build_model(self) -> None:
        """Build MLP architecture."""
        config: MLPConfig = self.config
        
        layers: List[nn.Module] = []
        in_dim = config.input_dim
        
        # Build hidden layers
        for hidden_dim in config.hidden_dims:
            block = MLPBlock(
                in_features=in_dim,
                out_features=hidden_dim,
                activation=config.activation,
                dropout=config.dropout,
                batch_norm=config.batch_norm,
                layer_norm=config.layer_norm,
                bias=config.bias,
                residual=config.residual
            )
            layers.append(block)
            in_dim = hidden_dim
        
        self.hidden_layers = nn.ModuleList(layers)
        
        # Output projection
        self.output_proj = nn.Linear(in_dim, config.output_dim, bias=config.bias)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through MLP.
        
        Args:
            x: Input tensor of shape (batch_size, input_dim) or
               (batch_size, seq_length, input_dim) for sequential data
               
        Returns:
            Output logits of shape (batch_size, output_dim)
        """
        # Flatten input if multi-dimensional (except for last dimension)
        if x.ndim > 2:
            x = x.view(x.size(0), -1)
        
        # Pass through hidden layers
        for layer in self.hidden_layers:
            x = layer(x)
        
        # Output projection (no activation - logits for classification)
        x = self.output_proj(x)
        
        return x
    
    def get_intermediate_outputs(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Get outputs from all hidden layers.
        
        Args:
            x: Input tensor
            
        Returns:
            Dictionary mapping layer names to outputs
        """
        outputs = {"input": x.clone()}
        
        if x.ndim > 2:
            x = x.view(x.size(0), -1)
        
        for i, layer in enumerate(self.hidden_layers):
            x = layer(x)
            outputs[f"layer_{i}"] = x.clone()
        
        outputs["output"] = self.output_proj(x)
        
        return outputs
    
    def get_num_layers(self) -> int:
        """Get number of hidden layers."""
        return len(self.hidden_layers)
    
    def get_layer_dim(self, layer_idx: int) -> int:
        """
        Get dimension of specified hidden layer.
        
        Args:
            layer_idx: Index of hidden layer
            
        Returns:
            Layer dimension
        """
        if layer_idx < 0 or layer_idx >= len(self.hidden_layers):
            raise IndexError(f"Layer index {layer_idx} out of range")
        return self.config.hidden_dims[layer_idx]


class ResidualMLP(MLP):
    """
    MLP with mandatory residual connections.
    
    Uses residual (skip) connections between every two layers
    for improved gradient flow and training stability.
    """
    
    @staticmethod
    def get_default_config() -> MLPConfig:
        """Get default configuration for residual MLP."""
        return MLPConfig(
            name="residual_mlp",
            input_dim=784,
            output_dim=10,
            hidden_dims=[512, 256, 128],
            activation="relu",
            dropout=0.1,
            batch_norm=True,
            bias=True,
            residual=True,
            layer_norm=False,
            seed=None
        )


class DeepMLP(MLP):
    """
    Deep MLP variant optimized for many layers.
    
    Uses layer normalization and residual connections
    to enable training of very deep networks.
    """
    
    @staticmethod
    def get_default_config() -> MLPConfig:
        """Get default configuration for deep MLP."""
        return MLPConfig(
            name="deep_mlp",
            input_dim=784,
            output_dim=10,
            hidden_dims=[512] * 8,  # 8 hidden layers
            activation="gelu",
            dropout=0.1,
            batch_norm=False,
            bias=True,
            residual=True,
            layer_norm=True,
            seed=None
        )


class WideMLP(MLP):
    """
    Wide MLP variant with large hidden layers.
    
    Uses residual connections and SELU activation
    for self-normalizing properties.
    """
    
    @staticmethod
    def get_default_config() -> MLPConfig:
        """Get default configuration for wide MLP."""
        return MLPConfig(
            name="wide_mlp",
            input_dim=784,
            output_dim=10,
            hidden_dims=[2048, 1024],  # Wide layers
            activation="selu",
            dropout=0.05,
            batch_norm=False,
            bias=True,
            residual=True,
            layer_norm=False,
            seed=None
        )
