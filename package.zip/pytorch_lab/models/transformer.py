"""
Transformer Model
=================

Implements Transformer architecture for sequence modeling and
classification tasks with configurable attention mechanisms.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
import math
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, field

from pytorch_lab.models.base_model import BaseModel, ModelConfig


@dataclass
class TransformerConfig(ModelConfig):
    """
    Configuration for Transformer model.
    
    Attributes:
        name: Model name
        input_dim: Input feature dimension (embedding dimension)
        output_dim: Output dimension (num classes or 1 for regression)
        num_heads: Number of attention heads
        num_layers: Number of transformer layers
        hidden_dim: Feed-forward hidden dimension (typically 4 * input_dim)
        dropout: Dropout probability
        activation: Activation function for feed-forward layers
        max_seq_length: Maximum sequence length for positional encoding
        pos_encoding: Positional encoding type ('sinusoidal', 'learned', 'none')
        cls_token: Whether to add CLS token for classification
        attention_dropout: Dropout in attention layers
        layer_norm: Whether to use layer normalization
        bias: Whether to use bias in linear layers
    """
    name: str = "transformer"
    input_dim: int = 512
    output_dim: int = 10
    num_heads: int = 8
    num_layers: int = 6
    hidden_dim: int = 2048
    dropout: float = 0.1
    activation: str = "gelu"
    max_seq_length: int = 512
    pos_encoding: str = "sinusoidal"
    cls_token: bool = True
    attention_dropout: float = 0.0
    layer_norm: bool = True
    bias: bool = True
    seed: Optional[int] = None
    
    def __post_init__(self):
        """Validate Transformer-specific configuration."""
        super().__post_init__()
        
        if self.input_dim % self.num_heads != 0:
            raise ValueError(
                f"input_dim ({self.input_dim}) must be divisible by num_heads ({self.num_heads})"
            )
        
        if self.hidden_dim % self.num_heads != 0:
            raise ValueError(
                f"hidden_dim ({self.hidden_dim}) must be divisible by num_heads ({self.num_heads})"
            )


class PositionalEncoding(nn.Module):
    """
    Sinusoidal positional encoding for transformer.
    
    Uses fixed sinusoidal embeddings for position representation,
    allowing the model to attend to relative positions.
    """
    
    def __init__(self, d_model: int, max_len: int = 5000, dropout: float = 0.1):
        """
        Initialize positional encoding.
        
        Args:
            d_model: Embedding dimension
            max_len: Maximum sequence length
            dropout: Dropout probability
        """
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        
        # Create positional encoding matrix
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model)
        )
        
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # Add batch dimension
        
        self.register_buffer('pe', pe)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Add positional encoding to input.
        
        Args:
            x: Input tensor of shape (batch, seq_len, d_model)
            
        Returns:
            Tensor with positional encoding added
        """
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)


class LearnedPositionalEncoding(nn.Module):
    """
    Learnable positional encoding.
    
    Uses trainable embeddings for position representation.
    """
    
    def __init__(self, d_model: int, max_len: int = 5000, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)
        self.pe = nn.Embedding(max_len, d_model)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Add learnable positional encoding."""
        batch_size, seq_len, d_model = x.shape
        positions = torch.arange(seq_len, device=x.device).unsqueeze(0).expand(batch_size, -1)
        x = x + self.pe(positions)
        return self.dropout(x)


class MultiHeadAttention(nn.Module):
    """
    Multi-head self-attention mechanism.
    
    Implements scaled dot-product attention with multiple heads
    for parallel attention computation.
    """
    
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        dropout: float = 0.0,
        bias: bool = True
    ):
        """
        Initialize multi-head attention.
        
        Args:
            d_model: Model dimension
            num_heads: Number of attention heads
            dropout: Dropout probability
            bias: Whether to use bias in projections
        """
        super().__init__()
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"
        
        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        self.scale = math.sqrt(self.d_k)
        
        # Linear projections for Q, K, V
        self.q_linear = nn.Linear(d_model, d_model, bias=bias)
        self.k_linear = nn.Linear(d_model, d_model, bias=bias)
        self.v_linear = nn.Linear(d_model, d_model, bias=bias)
        
        # Output projection
        self.out_linear = nn.Linear(d_model, d_model, bias=bias)
        
        # Dropout
        self.dropout = nn.Dropout(dropout)
    
    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through multi-head attention.
        
        Args:
            query: Query tensor of shape (batch, seq_len, d_model)
            key: Key tensor of shape (batch, seq_len, d_model)
            value: Value tensor of shape (batch, seq_len, d_model)
            mask: Optional attention mask
            
        Returns:
            Tuple of (output tensor, attention weights)
        """
        batch_size = query.size(0)
        
        # Linear projections and reshape for multi-head
        Q = self.q_linear(query).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        K = self.k_linear(key).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        V = self.v_linear(value).view(batch_size, -1, self.num_heads, self.d_k).transpose(1, 2)
        
        # Scaled dot-product attention
        scores = torch.matmul(Q, K.transpose(-2, -1)) / self.scale
        
        # Apply mask if provided
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float('-inf'))
        
        # Attention weights
        attention_weights = torch.softmax(scores, dim=-1)
        attention_weights = self.dropout(attention_weights)
        
        # Apply attention to values
        context = torch.matmul(attention_weights, V)
        
        # Reshape and project output
        context = context.transpose(1, 2).contiguous().view(batch_size, -1, self.d_model)
        output = self.out_linear(context)
        
        return output, attention_weights


class FeedForward(nn.Module):
    """
    Position-wise feed-forward network.
    
    Two linear transformations with activation in between,
    as described in "Attention is All You Need".
    """
    
    def __init__(
        self,
        d_model: int,
        hidden_dim: int,
        activation: str = "gelu",
        dropout: float = 0.1,
        bias: bool = True
    ):
        super().__init__()
        
        self.linear1 = nn.Linear(d_model, hidden_dim, bias=bias)
        self.activation = self._get_activation(activation)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(hidden_dim, d_model, bias=bias)
    
    def _get_activation(self, name: str) -> nn.Module:
        """Get activation function by name."""
        activations = {
            "relu": nn.ReLU(inplace=True),
            "gelu": nn.GELU(),
            "tanh": nn.Tanh(),
            "sigmoid": nn.Sigmoid(),
        }
        return activations.get(name.lower(), nn.GELU())
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through feed-forward network."""
        x = self.linear1(x)
        x = self.activation(x)
        x = self.dropout(x)
        x = self.linear2(x)
        return x


class TransformerLayer(nn.Module):
    """
    Single Transformer encoder layer.
    
    Contains multi-head attention followed by feed-forward network,
    with residual connections and layer normalization.
    """
    
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        hidden_dim: int,
        dropout: float = 0.1,
        attention_dropout: float = 0.0,
        activation: str = "gelu",
        layer_norm: bool = True,
        bias: bool = True
    ):
        super().__init__()
        
        self.attention = MultiHeadAttention(
            d_model, num_heads, attention_dropout, bias
        )
        self.feed_forward = FeedForward(
            d_model, hidden_dim, activation, dropout, bias
        )
        
        if layer_norm:
            self.norm1 = nn.LayerNorm(d_model)
            self.norm2 = nn.LayerNorm(d_model)
        else:
            self.norm1 = None
            self.norm2 = None
        
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
    
    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass through transformer layer.
        
        Args:
            x: Input tensor
            mask: Optional attention mask
            
        Returns:
            Tuple of (output tensor, attention weights)
        """
        # Multi-head attention with residual
        attn_output, attn_weights = self.attention(x, x, x, mask)
        x = x + self.dropout1(attn_output)
        
        if self.norm1 is not None:
            x = self.norm1(x)
        
        # Feed-forward with residual
        ff_output = self.feed_forward(x)
        x = x + self.dropout2(ff_output)
        
        if self.norm2 is not None:
            x = self.norm2(x)
        
        return x, attn_weights


class Transformer(BaseModel):
    """
    Transformer encoder model for sequence classification.
    
    Implements a stack of transformer layers with optional
    positional encoding and classification head.
    
    Example:
        >>> config = TransformerConfig(input_dim=512, output_dim=10, num_heads=8, num_layers=6)
        >>> model = Transformer(config)
        >>> x = torch.randn(4, 32, 512)  # (batch, seq_len, features)
        >>> output = model(x)
        >>> output.shape
        torch.Size([4, 10])
    """
    
    def __init__(self, config: Optional[TransformerConfig] = None):
        """
        Initialize Transformer model.
        
        Args:
            config: Transformer configuration (uses default if None)
        """
        if config is None:
            config = self.get_default_config()
        super().__init__(config)
    
    @staticmethod
    def get_default_config() -> TransformerConfig:
        """Get default Transformer configuration."""
        return TransformerConfig(
            name="transformer",
            input_dim=512,
            output_dim=10,
            num_heads=8,
            num_layers=6,
            hidden_dim=2048,
            dropout=0.1,
            activation="gelu",
            max_seq_length=512,
            pos_encoding="sinusoidal",
            cls_token=True,
            attention_dropout=0.0,
            layer_norm=True,
            bias=True,
            seed=None
        )
    
    def _build_model(self) -> None:
        """Build Transformer architecture."""
        config: TransformerConfig = self.config
        
        # Input embedding projection
        self.input_proj = nn.Linear(config.input_dim, config.input_dim, bias=config.bias)
        
        # Positional encoding
        if config.pos_encoding == "sinusoidal":
            self.pos_encoder = PositionalEncoding(
                config.input_dim, config.max_seq_length, config.dropout
            )
        elif config.pos_encoding == "learned":
            self.pos_encoder = LearnedPositionalEncoding(
                config.input_dim, config.max_seq_length, config.dropout
            )
        else:
            self.pos_encoder = None
        
        # CLS token for classification
        if config.cls_token:
            self.cls_token = nn.Parameter(torch.randn(1, 1, config.input_dim))
        
        # Transformer layers
        self.layers = nn.ModuleList([
            TransformerLayer(
                d_model=config.input_dim,
                num_heads=config.num_heads,
                hidden_dim=config.hidden_dim,
                dropout=config.dropout,
                attention_dropout=config.attention_dropout,
                activation=config.activation,
                layer_norm=config.layer_norm,
                bias=config.bias
            )
            for _ in range(config.num_layers)
        ])
        
        # Output classification head
        self.classifier = nn.Linear(config.input_dim, config.output_dim, bias=config.bias)
        self.dropout = nn.Dropout(config.dropout)
    
    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
        return_attention: bool = False
    ) -> Dict[str, torch.Tensor]:
        """
        Forward pass through Transformer.
        
        Args:
            x: Input tensor of shape (batch, seq_len, input_dim)
            mask: Optional attention mask
            return_attention: Whether to return attention weights
            
        Returns:
            Dictionary containing 'logits' and optionally 'attention_weights'
        """
        config: TransformerConfig = self.config
        
        # Project input to model dimension
        x = self.input_proj(x)
        
        # Add positional encoding
        if self.pos_encoder is not None:
            x = self.pos_encoder(x)
        
        # Add CLS token if using
        if config.cls_token:
            cls_tokens = self.cls_token.expand(x.size(0), -1, -1)
            x = torch.cat([cls_tokens, x], dim=1)
            
            # Adjust mask for CLS token
            if mask is not None:
                cls_mask = torch.ones(mask.size(0), 1, device=mask.device)
                mask = torch.cat([cls_mask, mask], dim=1)
        
        # Pass through transformer layers
        attention_weights_list = []
        for layer in self.layers:
            x, attn_weights = layer(x, mask)
            if return_attention:
                attention_weights_list.append(attn_weights)
        
        # Get CLS token output for classification
        if config.cls_token:
            cls_output = x[:, 0]  # First token is CLS
        else:
            # Global average pooling
            cls_output = x.mean(dim=1)
        
        # Classification
        cls_output = self.dropout(cls_output)
        logits = self.classifier(cls_output)
        
        result = {"logits": logits}
        
        if return_attention:
            result["attention_weights"] = attention_weights_list
        
        return result
    
    def get_attention_weights(
        self,
        x: torch.Tensor,
        layer_idx: Optional[int] = None
    ) -> torch.Tensor:
        """
        Get attention weights from forward pass.
        
        Args:
            x: Input tensor
            layer_idx: Specific layer to get weights from (None for all)
            
        Returns:
            Attention weights tensor
        """
        with torch.no_grad():
            outputs = self.forward(x, return_attention=True)
        
        weights = outputs["attention_weights"]
        
        if layer_idx is not None:
            return weights[layer_idx]
        
        # Average across all layers
        return torch.stack(weights).mean(dim=0)


class ViTTransformer(Transformer):
    """
    Vision Transformer (ViT) for image classification.
    
    Splits images into patches and processes them as sequences.
    """
    
    @staticmethod
    def get_default_config() -> TransformerConfig:
        """Get default ViT configuration."""
        return TransformerConfig(
            name="vit",
            input_dim=768,  # Standard ViT dimension
            output_dim=10,
            num_heads=12,
            num_layers=12,
            hidden_dim=3072,
            dropout=0.1,
            activation="gelu",
            max_seq_length=197,  # 14x14 patches + CLS
            pos_encoding="sinusoidal",
            cls_token=True,
            attention_dropout=0.0,
            layer_norm=True,
            bias=True,
            seed=None
        )
