"""
CNN (Convolutional Neural Network) Model
=========================================

Implements flexible CNN architectures for image classification and
feature extraction with configurable depth, width, and operations.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, field

from pytorch_lab.models.base_model import BaseModel, ModelConfig


@dataclass
class CNNConfig(ModelConfig):
    """
    Configuration for CNN model.
    
    Attributes:
        name: Model name
        input_channels: Number of input channels
        input_height: Input height (for validation)
        input_width: Input width (for validation)
        output_dim: Output dimension (num classes)
        conv_channels: List of convolutional channel sizes
        kernel_sizes: List of kernel sizes for each conv layer
        stride: Convolution stride
        padding: Padding mode ('same', 'valid', or int)
        activation: Activation function
        pooling: Pooling type ('max', 'avg', or 'none')
        pool_size: Pooling window size
        pool_stride: Pooling stride
        dropout: Dropout probability
        batch_norm: Whether to use batch normalization
        global_pool: Whether to use global pooling before classifier
        num_classes: Output classes (alias for output_dim)
    """
    name: str = "cnn"
    input_channels: int = 3
    input_height: int = 32
    input_width: int = 32
    output_dim: int = 10
    conv_channels: List[int] = field(default_factory=lambda: [64, 128, 256])
    kernel_sizes: List[int] = field(default_factory=lambda: [3, 3, 3])
    stride: int = 1
    padding: str = "same"
    activation: str = "relu"
    pooling: str = "max"
    pool_size: int = 2
    pool_stride: int = 2
    dropout: float = 0.25
    batch_norm: bool = True
    global_pool: bool = True
    seed: Optional[int] = None
    
    def __post_init__(self):
        """Validate CNN-specific configuration."""
        super().__post_init__()
        
        if len(self.conv_channels) != len(self.kernel_sizes):
            raise ValueError(
                f"conv_channels and kernel_sizes must have same length, "
                f"got {len(self.conv_channels)} and {len(self.kernel_sizes)}"
            )
        
        if self.pooling not in ['max', 'avg', 'none']:
            raise ValueError(f"pooling must be 'max', 'avg', or 'none', got {self.pooling}")


class ConvBlock(nn.Module):
    """
    Convolutional block with Conv2d, optional BatchNorm, Activation, and Pooling.
    """
    
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        padding: str = "same",
        activation: str = "relu",
        batch_norm: bool = True,
        pooling: Optional[str] = "max",
        pool_size: int = 2,
        pool_stride: int = 2,
        dropout: float = 0.0
    ):
        """
        Initialize convolutional block.
        
        Args:
            in_channels: Number of input channels
            out_channels: Number of output channels
            kernel_size: Convolution kernel size
            stride: Convolution stride
            padding: Padding mode ('same', 'valid', or int)
            activation: Activation function name
            batch_norm: Whether to use batch normalization
            pooling: Pooling type ('max', 'avg', or None)
            pool_size: Pooling window size
            pool_stride: Pooling stride
            dropout: Dropout probability
        """
        super().__init__()
        
        # Compute padding
        if padding == "same":
            pad = kernel_size // 2
        elif padding == "valid":
            pad = 0
        else:
            pad = padding
        
        # Convolution
        self.conv = nn.Conv2d(
            in_channels,
            out_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=pad,
            bias=not batch_norm
        )
        
        # Batch normalization
        self.bn = nn.BatchNorm2d(out_channels) if batch_norm else None
        
        # Activation
        self.activation = self._get_activation(activation)
        
        # Pooling
        if pooling == "max":
            self.pool = nn.MaxPool2d(kernel_size=pool_size, stride=pool_stride)
        elif pooling == "avg":
            self.pool = nn.AvgPool2d(kernel_size=pool_size, stride=pool_stride)
        else:
            self.pool = None
        
        # Dropout
        self.dropout = nn.Dropout2d(dropout) if dropout > 0 else None
    
    def _get_activation(self, name: str) -> nn.Module:
        """Get activation function by name."""
        activations = {
            "relu": nn.ReLU(inplace=True),
            "gelu": nn.GELU(),
            "tanh": nn.Tanh(),
            "sigmoid": nn.Sigmoid(),
            "leaky_relu": nn.LeakyReLU(0.2, inplace=True),
            "elu": nn.ELU(inplace=True),
            "selu": nn.SELU(inplace=True),
            "none": nn.Identity(),
        }
        return activations.get(name.lower(), nn.ReLU(inplace=True))
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through conv block.
        
        Args:
            x: Input tensor of shape (batch, channels, height, width)
            
        Returns:
            Output tensor
        """
        x = self.conv(x)
        
        if self.bn is not None:
            x = self.bn(x)
        
        x = self.activation(x)
        
        if self.pool is not None:
            x = self.pool(x)
        
        if self.dropout is not None:
            x = self.dropout(x)
        
        return x


class CNN(BaseModel):
    """
    Convolutional Neural Network for image classification.
    
    Implements a flexible CNN with configurable:
    - Number of convolutional layers
    - Channel sizes per layer
    - Kernel sizes
    - Pooling strategies
    - Regularization
    
    Example:
        >>> config = CNNConfig(input_channels=3, output_dim=10)
        >>> model = CNN(config)
        >>> x = torch.randn(4, 3, 32, 32)
        >>> output = model(x)
        >>> output.shape
        torch.Size([4, 10])
    """
    
    def __init__(self, config: Optional[CNNConfig] = None):
        """
        Initialize CNN model.
        
        Args:
            config: CNN configuration (uses default if None)
        """
        if config is None:
            config = self.get_default_config()
        super().__init__(config)
    
    @staticmethod
    def get_default_config() -> CNNConfig:
        """Get default CNN configuration."""
        return CNNConfig(
            name="cnn",
            input_channels=3,
            input_height=32,
            input_width=32,
            output_dim=10,
            conv_channels=[64, 128, 256],
            kernel_sizes=[3, 3, 3],
            stride=1,
            padding="same",
            activation="relu",
            pooling="max",
            pool_size=2,
            pool_stride=2,
            dropout=0.25,
            batch_norm=True,
            global_pool=True,
            seed=None
        )
    
    def _build_model(self) -> None:
        """Build CNN architecture."""
        config: CNNConfig = self.config
        
        layers: List[nn.Module] = []
        in_channels = config.input_channels
        
        # Build convolutional layers
        for i, (out_channels, kernel_size) in enumerate(
            zip(config.conv_channels, config.kernel_sizes)
        ):
            # Add pooling to all but first layer
            pool = config.pooling if i > 0 else None
            
            block = ConvBlock(
                in_channels=in_channels,
                out_channels=out_channels,
                kernel_size=kernel_size,
                stride=config.stride,
                padding=config.padding,
                activation=config.activation,
                batch_norm=config.batch_norm,
                pooling=pool,
                pool_size=config.pool_size,
                pool_stride=config.pool_stride,
                dropout=config.dropout if i > 0 else 0.0
            )
            layers.append(block)
            in_channels = out_channels
        
        self.conv_layers = nn.ModuleList(layers)
        
        # Compute feature map size after convolutions
        self.feature_size = self._compute_feature_size(config)
        
        # Global average pooling
        if config.global_pool:
            self.global_pool = nn.AdaptiveAvgPool2d((1, 1))
        
        # Classifier head
        classifier_input = config.conv_channels[-1] if config.global_pool else self.feature_size
        
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Dropout(config.dropout),
            nn.Linear(classifier_input, config.output_dim)
        )
    
    def _compute_feature_size(self, config: CNNConfig) -> int:
        """
        Compute flattened feature size after convolutions.
        
        Args:
            config: CNN configuration
            
        Returns:
            Feature size (channels * height * width)
        """
        h, w = config.input_height, config.input_width
        
        for i in range(len(config.conv_channels)):
            # Account for stride
            if i > 0:  # Pool after first layer
                h = h // config.pool_stride
                w = w // config.pool_stride
            
            # Account for convolution
            if config.padding == "same":
                pass  # Output size same as input
            elif config.padding == "valid":
                h = h - config.kernel_sizes[i] + 1
                w = w - config.kernel_sizes[i] + 1
        
        return config.conv_channels[-1] * h * w
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through CNN.
        
        Args:
            x: Input tensor of shape (batch, channels, height, width)
            
        Returns:
            Output logits of shape (batch, output_dim)
        """
        # Apply convolutional layers
        for layer in self.conv_layers:
            x = layer(x)
        
        # Global pooling
        if self.config.global_pool:
            x = self.global_pool(x)
        
        # Classification
        x = self.classifier(x)
        
        return x
    
    def get_feature_maps(self, x: torch.Tensor) -> List[torch.Tensor]:
        """
        Extract feature maps from all convolutional layers.
        
        Args:
            x: Input tensor
            
        Returns:
            List of feature maps
        """
        features = []
        
        for layer in self.conv_layers:
            x = layer(x)
            features.append(x)
        
        return features
    
    def freeze_convolutional_layers(self) -> None:
        """Freeze all convolutional layers (transfer learning)."""
        for layer in self.conv_layers:
            for param in layer.parameters():
                param.requires_grad = False
    
    def unfreeze_convolutional_layers(self) -> None:
        """Unfreeze all convolutional layers."""
        for layer in self.conv_layers:
            for param in layer.parameters():
                param.requires_grad = True


class ResidualConvBlock(nn.Module):
    """
    Residual convolutional block with skip connection.
    """
    
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        downsample: Optional[nn.Module] = None
    ):
        super().__init__()
        
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        
        self.activation = nn.ReLU(inplace=True)
        self.downsample = downsample
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = x
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.activation(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        
        if self.downsample is not None:
            identity = self.downsample(x)
        
        out += identity
        out = self.activation(out)
        
        return out


class ResNet_like(CNN):
    """
    ResNet-style CNN with residual connections.
    
    Adapted from standard ResNet architecture for simpler
    configuration and flexibility.
    """
    
    @staticmethod
    def get_default_config() -> CNNConfig:
        """Get default ResNet-style configuration."""
        return CNNConfig(
            name="resnet_cnn",
            input_channels=3,
            input_height=32,
            input_width=32,
            output_dim=10,
            conv_channels=[64, 128, 256, 512],
            kernel_sizes=[3, 3, 3, 3],
            stride=1,
            padding="same",
            activation="relu",
            pooling="none",  # Handle pooling in residual blocks
            pool_size=2,
            pool_stride=2,
            dropout=0.3,
            batch_norm=True,
            global_pool=True,
            seed=None
        )


class LightweightCNN(CNN):
    """
    Lightweight CNN optimized for mobile/edge deployment.
    
    Uses depthwise separable convolutions and fewer parameters.
    """
    
    @staticmethod
    def get_default_config() -> CNNConfig:
        """Get default lightweight CNN configuration."""
        return CNNConfig(
            name="lightweight_cnn",
            input_channels=3,
            input_height=32,
            input_width=32,
            output_dim=10,
            conv_channels=[32, 64, 128],
            kernel_sizes=[3, 3, 3],
            stride=1,
            padding="same",
            activation="relu",
            pooling="max",
            pool_size=2,
            pool_stride=2,
            dropout=0.2,
            batch_norm=True,
            global_pool=True,
            seed=None
        )
