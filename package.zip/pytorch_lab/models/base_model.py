"""
Base Model Class
================

Provides abstract base class and configuration for all PyTorch models.
Ensures consistent interface and functionality across model architectures.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import json
import hashlib


@dataclass
class ModelConfig:
    """
    Base configuration for all models.
    
    Attributes:
        name: Model name for identification
        input_dim: Input dimension
        output_dim: Output dimension (for classification/regression)
        hidden_dims: List of hidden layer dimensions
        activation: Activation function name
        dropout: Dropout probability
        batch_norm: Whether to use batch normalization
        bias: Whether to use bias in linear layers
        seed: Random seed for reproducibility
    """
    name: str = "base_model"
    input_dim: int = 784
    output_dim: int = 10
    hidden_dims: List[int] = field(default_factory=lambda: [256, 128])
    activation: str = "relu"
    dropout: float = 0.0
    batch_norm: bool = False
    bias: bool = True
    seed: Optional[int] = None
    
    def __post_init__(self):
        """Validate configuration after initialization."""
        if self.output_dim <= 0:
            raise ValueError(f"output_dim must be positive, got {self.output_dim}")
        if self.dropout < 0 or self.dropout > 1:
            raise ValueError(f"dropout must be in [0, 1], got {self.dropout}")
        if any(d <= 0 for d in self.hidden_dims):
            raise ValueError(f"hidden_dims must contain positive values")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return {
            "name": self.name,
            "input_dim": self.input_dim,
            "output_dim": self.output_dim,
            "hidden_dims": self.hidden_dims,
            "activation": self.activation,
            "dropout": self.dropout,
            "batch_norm": self.batch_norm,
            "bias": self.bias,
            "seed": self.seed,
        }
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "ModelConfig":
        """Create config from dictionary."""
        return cls(**config_dict)
    
    def get_hash(self) -> str:
        """Generate unique hash for this configuration."""
        config_str = json.dumps(self.to_dict(), sort_keys=True)
        return hashlib.md5(config_str.encode()).hexdigest()[:8]


class BaseModel(nn.Module, ABC):
    """
    Abstract base class for all PyTorch models.
    
    Provides common functionality including:
    - Configuration management
    - Parameter initialization with seeding
    - Model summary generation
    - Save/load functionality
    - Gradient flow analysis
    
    Subclasses must implement:
    - forward(): Forward pass computation
    - get_default_config(): Return model-specific configuration
    
    Example:
        class MyModel(BaseModel):
            def __init__(self, config: ModelConfig):
                super().__init__(config)
                # Define layers
                
            def forward(self, x):
                # Forward pass
                return x
                
            @staticmethod
            def get_default_config() -> ModelConfig:
                return ModelConfig(name="my_model")
    """
    
    def __init__(self, config: ModelConfig):
        """
        Initialize base model.
        
        Args:
            config: Model configuration
        """
        super().__init__()
        self.config = config
        self._build_model()
        
        # Initialize weights if seed provided
        if config.seed is not None:
            self._initialize_weights(config.seed)
        
        # Track forward pass hooks
        self._activation_stats: Dict[str, List[torch.Tensor]] = {}
    
    @abstractmethod
    def _build_model(self) -> None:
        """
        Build model architecture.
        
        This method should be implemented by subclasses to define
        the model layers and components.
        """
        pass
    
    @staticmethod
    @abstractmethod
    def get_default_config() -> ModelConfig:
        """
        Get default configuration for this model.
        
        Returns:
            ModelConfig with default values
        """
        pass
    
    def _initialize_weights(self, seed: int) -> None:
        """
        Initialize model weights with seeding.
        
        Args:
            seed: Random seed for initialization
        """
        torch.manual_seed(seed)
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.kaiming_normal_(module.weight, mode='fan_out', nonlinearity='relu')
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.Conv2d):
                nn.init.kaiming_normal_(module.weight, mode='fan_out', nonlinearity='relu')
                if module.bias is not None:
                    nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.BatchNorm2d) or isinstance(module, nn.BatchNorm1d):
                nn.init.constant_(module.weight, 1)
                nn.init.constant_(module.bias, 0)
            elif isinstance(module, nn.LayerNorm):
                nn.init.constant_(module.weight, 1)
                nn.init.constant_(module.bias, 0)
    
    def get_activation(self, name: str) -> torch.Tensor:
        """
        Get stored activation for analysis.
        
        Args:
            name: Name of the activation
            
        Returns:
            Stored activation tensor
        """
        return self._activation_stats.get(name, None)
    
    def clear_activation_stats(self) -> None:
        """Clear all stored activation statistics."""
        self._activation_stats.clear()
    
    def count_parameters(self, trainable_only: bool = True) -> int:
        """
        Count model parameters.
        
        Args:
            trainable_only: Whether to count only trainable parameters
            
        Returns:
            Number of parameters
        """
        if trainable_only:
            return sum(p.numel() for p in self.parameters() if p.requires_grad)
        return sum(p.numel() for p in self.parameters())
    
    def get_device(self) -> torch.device:
        """
        Get the device of model parameters.
        
        Returns:
            Device where model is located
        """
        return next(self.parameters()).device
    
    def freeze(self) -> None:
        """Freeze all parameters (disable gradient computation)."""
        for param in self.parameters():
            param.requires_grad = False
    
    def unfreeze(self) -> None:
        """Unfreeze all parameters (enable gradient computation)."""
        for param in self.parameters():
            param.requires_grad = True
    
    def freeze_until(self, layer_name: str) -> None:
        """
        Freeze parameters up to specified layer.
        
        Args:
            layer_name: Name of layer to freeze until (exclusive)
        """
        found_layer = False
        for name, param in self.named_parameters():
            if layer_name in name:
                found_layer = True
            if not found_layer:
                param.requires_grad = False
    
    def get_grad_norm(self) -> float:
        """
        Compute gradient norm across all parameters.
        
        Returns:
            Total gradient norm
        """
        total_norm = 0.0
        for p in self.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5
    
    def summary(self) -> str:
        """
        Generate model summary string.
        
        Returns:
            Formatted model summary
        """
        lines = [
            f"Model: {self.config.name}",
            f"Configuration:",
        ]
        
        for key, value in self.config.to_dict().items():
            lines.append(f"  {key}: {value}")
        
        lines.extend([
            "",
            "Architecture:",
            str(self),
            "",
            f"Total Parameters: {self.count_parameters(trainable_only=False):,}",
            f"Trainable Parameters: {self.count_parameters(trainable_only=True):,}",
        ])
        
        return "\n".join(lines)
    
    def save(self, filepath: str, include_optimizer: bool = False) -> None:
        """
        Save model to file.
        
        Args:
            filepath: Path to save file
            include_optimizer: Whether to save optimizer state
        """
        checkpoint = {
            "model_state_dict": self.state_dict(),
            "config": self.config.to_dict(),
            "model_class": self.__class__.__name__,
        }
        
        if include_optimizer:
            raise NotImplementedError("Optimizer saving requires trainer integration")
        
        torch.save(checkpoint, filepath)
    
    @classmethod
    def load(cls, filepath: str, device: Optional[torch.device] = None) -> "BaseModel":
        """
        Load model from file.
        
        Args:
            filepath: Path to checkpoint file
            device: Device to load model to
            
        Returns:
            Loaded model instance
        """
        checkpoint = torch.load(filepath, map_location=device)
        
        config = ModelConfig.from_dict(checkpoint["config"])
        model = cls(config)
        model.load_state_dict(checkpoint["model_state_dict"])
        
        return model
    
    def get_config_hash(self) -> str:
        """
        Get unique hash for this model's configuration.
        
        Returns:
            Configuration hash string
        """
        return self.config.get_hash()


def register_activation_hook(model: nn.Module, name: str) -> None:
    """
    Register hook to capture layer activations.
    
    Args:
        model: PyTorch model
        name: Name for this activation
    """
    def hook_fn(module, input, output):
        if isinstance(output, torch.Tensor):
            model._activation_stats[name] = output.detach()
    
    return hook_fn
