"""
Training Module
===============

Provides training engine, optimizer factory, and loss functions
for model training with comprehensive logging and checkpointing.

Author: MiniMax Agent
"""

from pytorch_lab.training.trainer import Trainer, TrainerConfig
from pytorch_lab.training.optimizer_factory import OptimizerFactory, OptimizerConfig
from pytorch_lab.training.losses import LossFactory, LossConfig

__all__ = [
    "Trainer",
    "TrainerConfig",
    "OptimizerFactory",
    "OptimizerConfig",
    "LossFactory",
    "LossConfig",
]
