"""
Optimizer Factory Module
========================

Provides factory for creating optimizers and learning rate schedulers
with consistent interface and configuration management.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass


@dataclass
class OptimizerConfig:
    """
    Configuration for optimizer.
    
    Attributes:
        name: Optimizer name ('adam', 'sgd', 'adamw', 'rmsprop')
        learning_rate: Initial learning rate
        weight_decay: L2 regularization
        momentum: Momentum for SGD
        beta1: First moment decay for Adam
        beta2: Second moment decay for Adam
        epsilon: Small constant for numerical stability
        amsgrad: Whether to use AMSGrad variant
    """
    name: str = "adam"
    learning_rate: float = 0.001
    weight_decay: float = 0.0001
    momentum: float = 0.9
    beta1: float = 0.9
    beta2: float = 0.999
    epsilon: float = 1e-8
    amsgrad: bool = False


class OptimizerFactory:
    """
    Factory for creating optimizers with configuration management.
    
    Example:
        >>> factory = OptimizerFactory({"name": "adam", "learning_rate": 0.001})
        >>> optimizer = factory.create(model)
    """
    
    _optimizers = {
        "adam": torch.optim.Adam,
        "sgd": torch.optim.SGD,
        "adamw": torch.optim.AdamW,
        "rmsprop": torch.optim.RMSprop,
        "adagrad": torch.optim.Adagrad,
        "adadelta": torch.optim.Adadelta,
        "adamax": torch.optim.Adamax,
        "nadam": torch.optim.NAdam,
    }
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize optimizer factory.
        
        Args:
            config: Optimizer configuration dictionary
        """
        self.config = OptimizerConfig(**(config or {}))
    
    def create(self, model: nn.Module) -> torch.optim.Optimizer:
        """
        Create optimizer for model.
        
        Args:
            model: PyTorch model
            
        Returns:
            Configured optimizer
        """
        optimizer_name = self.config.name.lower()
        
        if optimizer_name not in self._optimizers:
            raise ValueError(
                f"Unknown optimizer: {optimizer_name}. "
                f"Available: {list(self._optimizers.keys())}"
            )
        
        optimizer_class = self._optimizers[optimizer_name]
        
        # Separate parameters with and without weight decay
        params = self._get_parameter_groups(model)
        
        return optimizer_class(params, **self._get_optimizer_kwargs())
    
    def _get_parameter_groups(self, model: nn.Module) -> List[Dict[str, Any]]:
        """
        Get parameter groups with different settings.
        
        Applies weight decay only to weight matrices, not biases
        or normalization parameters for better training stability.
        """
        params_with_decay = []
        params_without_decay = []
        
        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            
            # Apply weight decay to weights, not biases or normalization
            if "bias" in name or "bn" in name or "norm" in name:
                params_without_decay.append(param)
            else:
                params_with_decay.append(param)
        
        # Create parameter groups
        if params_without_decay:
            return [
                {"params": params_with_decay, "weight_decay": self.config.weight_decay},
                {"params": params_without_decay, "weight_decay": 0.0},
            ]
        else:
            return [{"params": params_with_decay, "weight_decay": self.config.weight_decay}]
    
    def _get_optimizer_kwargs(self) -> Dict[str, Any]:
        """Get optimizer-specific keyword arguments."""
        name = self.config.name.lower()
        
        base_kwargs = {
            "lr": self.config.learning_rate,
            "eps": self.config.epsilon,
        }
        
        if name == "sgd":
            base_kwargs["momentum"] = self.config.momentum
            base_kwargs["nesterov"] = True
        elif name in ["adam", "adamw", "adamax", "nadam"]:
            base_kwargs["betas"] = (self.config.beta1, self.config.beta2)
            if name == "adamw":
                base_kwargs["weight_decay"] = self.config.weight_decay
            if name == "adam" and self.config.amsgrad:
                base_kwargs["amsgrad"] = True
        elif name == "rmsprop":
            base_kwargs["momentum"] = self.config.momentum
            base_kwargs["alpha"] = 0.99
        
        return base_kwargs
    
    @classmethod
    def register_optimizer(
        cls,
        name: str,
        optimizer_class: type
    ) -> None:
        """
        Register custom optimizer.
        
        Args:
            name: Optimizer name
            optimizer_class: Optimizer class
        """
        cls._optimizers[name.lower()] = optimizer_class


class LRSchedulerFactory:
    """
    Factory for creating learning rate schedulers.
    """
    
    _schedulers = {
        "step": torch.optim.lr_scheduler.StepLR,
        "exponential": torch.optim.lr_scheduler.ExponentialLR,
        "cosine": torch.optim.lr_scheduler.CosineAnnealingLR,
        "plateau": torch.optim.lr_scheduler.ReduceLROnPlateau,
        "cosine_warmup": torch.optim.lr_scheduler.CosineAnnealingWarmRestarts,
        "warmup": torch.optim.lr_scheduler.LinearLR,
        "cyclic": torch.optim.lr_scheduler.CyclicLR,
        "one_cycle": torch.optim.lr_scheduler.OneCycleLR,
    }
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize scheduler factory.
        
        Args:
            config: Scheduler configuration dictionary
        """
        self.config = config or {}
        self.scheduler_type = self.config.get("type", "plateau")
    
    def create(
        self,
        optimizer: torch.optim.Optimizer,
        num_training_steps: Optional[int] = None
    ) -> torch.optim.lr_scheduler._LRScheduler:
        """
        Create learning rate scheduler.
        
        Args:
            optimizer: PyTorch optimizer
            num_training_steps: Total training steps (for OneCycleLR)
            
        Returns:
            Configured scheduler
        """
        if self.scheduler_type not in self._schedulers:
            raise ValueError(
                f"Unknown scheduler: {self.scheduler_type}. "
                f"Available: {list(self._schedulers.keys())}"
            )
        
        scheduler_class = self._schedulers[self.scheduler_type]
        
        return self._create_scheduler(
            scheduler_class,
            optimizer,
            num_training_steps
        )
    
    def _create_scheduler(
        self,
        scheduler_class: type,
        optimizer: torch.optim.Optimizer,
        num_training_steps: Optional[int]
    ) -> torch.optim.lr_scheduler._LRScheduler:
        """Create specific scheduler instance."""
        
        if self.scheduler_type == "step":
            return scheduler_class(
                optimizer,
                step_size=self.config.get("step_size", 10),
                gamma=self.config.get("gamma", 0.1)
            )
        
        elif self.scheduler_type == "exponential":
            return scheduler_class(
                optimizer,
                gamma=self.config.get("gamma", 0.95)
            )
        
        elif self.scheduler_type == "cosine":
            return scheduler_class(
                optimizer,
                T_max=self.config.get("T_max", 100),
                eta_min=self.config.get("eta_min", 0)
            )
        
        elif self.scheduler_type == "plateau":
            return scheduler_class(
                optimizer,
                mode=self.config.get("mode", "min"),
                factor=self.config.get("factor", 0.1),
                patience=self.config.get("patience", 5),
                threshold=self.config.get("threshold", 0.0001)
            )
        
        elif self.scheduler_type == "cosine_warmup":
            return scheduler_class(
                optimizer,
                T_0=self.config.get("T_0", 10),
                T_mult=self.config.get("T_mult", 1),
                eta_min=self.config.get("eta_min", 0)
            )
        
        elif self.scheduler_type == "warmup":
            return scheduler_class(
                optimizer,
                start_factor=self.config.get("start_factor", 0.1),
                end_factor=self.config.get("end_factor", 1.0),
                total_iters=self.config.get("total_iters", 5)
            )
        
        elif self.scheduler_type == "cyclic":
            return scheduler_class(
                optimizer,
                base_lr=self.config.get("base_lr", 0.001),
                max_lr=self.config.get("max_lr", 0.01),
                step_size_up=self.config.get("step_size_up", 2000),
                mode=self.config.get("mode", "triangular")
            )
        
        elif self.scheduler_type == "one_cycle":
            if num_training_steps is None:
                raise ValueError("num_training_steps required for OneCycleLR")
            return scheduler_class(
                optimizer,
                max_lr=self.config.get("max_lr", 0.01),
                total_steps=num_training_steps,
                pct_start=self.config.get("pct_start", 0.3),
                div_factor=self.config.get("div_factor", 25),
                final_div_factor=self.config.get("final_div_factor", 1000)
            )
        
        raise ValueError(f"Unknown scheduler type: {self.scheduler_type}")
    
    @classmethod
    def register_scheduler(
        cls,
        name: str,
        scheduler_class: type
    ) -> None:
        """
        Register custom scheduler.
        
        Args:
            name: Scheduler name
            scheduler_class: Scheduler class
        """
        cls._schedulers[name.lower()] = scheduler_class


def create_optimizer(
    model: nn.Module,
    name: str = "adam",
    learning_rate: float = 0.001,
    weight_decay: float = 0.0001,
    **kwargs
) -> torch.optim.Optimizer:
    """
    Convenience function to create optimizer.
    
    Example:
        >>> optimizer = create_optimizer(model, "adam", lr=0.001, weight_decay=1e-4)
    """
    config = {
        "name": name,
        "learning_rate": learning_rate,
        "weight_decay": weight_decay,
        **kwargs
    }
    factory = OptimizerFactory(config)
    return factory.create(model)


def create_scheduler(
    optimizer: torch.optim.Optimizer,
    name: str = "plateau",
    **kwargs
) -> torch.optim.lr_scheduler._LRScheduler:
    """
    Convenience function to create scheduler.
    
    Example:
        >>> scheduler = create_scheduler(optimizer, "cosine", T_max=100)
    """
    config = {"type": name, **kwargs}
    factory = LRSchedulerFactory(config)
    return factory.create(optimizer)
