"""
Trainer Module
==============

Provides comprehensive training loop with checkpointing, early stopping,
learning rate scheduling, gradient clipping, and detailed logging.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass, field
from pathlib import Path
import time
import json
from datetime import datetime

from pytorch_lab.training.optimizer_factory import OptimizerFactory
from pytorch_lab.training.losses import LossFactory
from pytorch_lab.governance.checkpoints import CheckpointManager


@dataclass
class TrainerConfig:
    """
    Configuration for trainer.
    
    Attributes:
        output_dir: Directory for checkpoints and logs
        max_epochs: Maximum training epochs
        gradient_clip: Gradient clipping value (None to disable)
        early_stopping_patience: Epochs to wait for improvement
        early_stopping_min_delta: Minimum improvement threshold
        log_every: Steps between logging
        validate_every: Steps between validation
        save_best_only: Only save when model improves
        resume_from_checkpoint: Path to checkpoint to resume from
        device: Device to train on ('cuda', 'cpu', or 'auto')
        mixed_precision: Use mixed precision training
        accumulation_steps: Gradient accumulation steps
        seed: Random seed for reproducibility
    """
    output_dir: str = "./output"
    max_epochs: int = 100
    gradient_clip: Optional[float] = 1.0
    early_stopping_patience: int = 10
    early_stopping_min_delta: float = 0.001
    log_every: int = 10
    validate_every: int = 100
    save_best_only: bool = False
    resume_from_checkpoint: Optional[str] = None
    device: str = "auto"
    mixed_precision: bool = False
    accumulation_steps: int = 1
    seed: Optional[int] = None
    
    def __post_init__(self):
        """Validate and set defaults."""
        if self.output_dir:
            Path(self.output_dir).mkdir(parents=True, exist_ok=True)


class Trainer:
    """
    Comprehensive training loop manager.
    
    Handles training, validation, checkpointing, early stopping,
    learning rate scheduling, and detailed logging.
    
    Example:
        >>> trainer = Trainer(model, train_loader, val_loader, config)
        >>> trainer.train()
    """
    
    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader] = None,
        config: Optional[TrainerConfig] = None,
        optimizer_config: Optional[Dict[str, Any]] = None,
        loss_config: Optional[Dict[str, Any]] = None,
        scheduler_config: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize trainer.
        
        Args:
            model: PyTorch model to train
            train_loader: Training data loader
            val_loader: Validation data loader
            config: Trainer configuration
            optimizer_config: Optimizer configuration
            loss_config: Loss function configuration
            scheduler_config: Learning rate scheduler configuration
        """
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.config = config or TrainerConfig()
        
        # Setup device
        self.device = self._setup_device()
        self.model.to(self.device)
        
        # Setup optimizer
        optimizer_factory = OptimizerFactory(optimizer_config or {})
        self.optimizer = optimizer_factory.create(model)
        
        # Setup loss function
        loss_factory = LossFactory(loss_config or {})
        self.criterion = loss_factory.create()
        
        # Setup scheduler
        self.scheduler = self._setup_scheduler(scheduler_config)
        
        # Setup checkpoint manager
        self.checkpoint_manager = CheckpointManager(
            checkpoint_dir=self.config.output_dir,
            save_best_only=self.config.save_best_only
        )
        
        # Training state
        self.current_epoch = 0
        self.global_step = 0
        self.best_metric = float('inf') if self._is_validation_lower_better() else float('-inf')
        self.patience_counter = 0
        self.training_history: Dict[str, List[float]] = {
            "train_loss": [],
            "train_metric": [],
            "val_loss": [],
            "val_metric": [],
            "learning_rate": [],
            "epoch_time": [],
        }
        
        # Mixed precision training
        self.scaler = None
        if self.config.mixed_precision:
            self.scaler = torch.cuda.amp.GradScaler()
        
        # Resume from checkpoint if specified
        if self.config.resume_from_checkpoint:
            self._resume_training(self.config.resume_from_checkpoint)
        
        # Custom callbacks
        self.callbacks: List[Callable] = []
    
    def _setup_device(self) -> torch.device:
        """Setup training device."""
        if self.config.device == "auto":
            return torch.device("cuda" if torch.cuda.is_available() else "cpu")
        return torch.device(self.config.device)
    
    def _is_validation_lower_better(self) -> bool:
        """Check if lower validation metric is better."""
        return True
    
    def _setup_scheduler(
        self,
        scheduler_config: Optional[Dict[str, Any]]
    ) -> Optional[Any]:
        """Setup learning rate scheduler."""
        if scheduler_config is None:
            return None
        
        scheduler_type = scheduler_config.get("type", "plateau")
        
        if scheduler_type == "step":
            return torch.optim.lr_scheduler.StepLR(
                self.optimizer,
                step_size=scheduler_config.get("step_size", 10),
                gamma=scheduler_config.get("gamma", 0.1)
            )
        elif scheduler_type == "exponential":
            return torch.optim.lr_scheduler.ExponentialLR(
                self.optimizer,
                gamma=scheduler_config.get("gamma", 0.95)
            )
        elif scheduler_type == "cosine":
            return torch.optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=scheduler_config.get("T_max", self.config.max_epochs)
            )
        elif scheduler_type == "plateau":
            return torch.optim.lr_scheduler.ReduceLROnPlateau(
                self.optimizer,
                mode='min',
                factor=scheduler_config.get("factor", 0.1),
                patience=scheduler_config.get("patience", 5)
            )
        elif scheduler_type == "warmup":
            return torch.optim.lr_scheduler.LinearLR(
                self.optimizer,
                start_factor=scheduler_config.get("start_factor", 0.1),
                end_factor=1.0,
                total_iters=scheduler_config.get("warmup_epochs", 5)
            )
        
        return None
    
    def add_callback(self, callback: Callable) -> None:
        """Add training callback."""
        self.callbacks.append(callback)
    
    def train(self) -> Dict[str, Any]:
        """
        Execute full training loop.
        
        Returns:
            Dictionary with training results and history
        """
        print(f"Starting training on {self.device}")
        print(f"Device: {self.device}")
        print(f"Training samples: {len(self.train_loader.dataset)}")
        if self.val_loader:
            print(f"Validation samples: {len(self.val_loader.dataset)}")
        print(f"Max epochs: {self.config.max_epochs}")
        print("-" * 60)
        
        for epoch in range(self.current_epoch, self.config.max_epochs):
            epoch_start_time = time.time()
            self.current_epoch = epoch
            
            # Training phase
            train_metrics = self._train_epoch()
            
            # Validation phase
            val_metrics = self._validate_epoch() if self.val_loader else {}
            
            # Update learning rate
            if self.scheduler is not None:
                if isinstance(self.scheduler, torch.optim.lr_scheduler.ReduceLROnPlateau):
                    val_loss = val_metrics.get("loss", float('inf'))
                    self.scheduler.step(val_loss)
                else:
                    self.scheduler.step()
            
            # Record metrics
            epoch_time = time.time() - epoch_start_time
            self._record_metrics(train_metrics, val_metrics, epoch_time)
            
            # Check for improvement
            improved = self._check_improvement(val_metrics)
            
            # Save checkpoint
            self._save_checkpoint(improved, train_metrics, val_metrics)
            
            # Check early stopping
            if self._check_early_stopping(val_metrics):
                print(f"Early stopping triggered after {epoch + 1} epochs")
                break
            
            # Log epoch summary
            self._log_epoch_summary(epoch, train_metrics, val_metrics, epoch_time)
        
        return self._compile_results()
    
    def _train_epoch(self) -> Dict[str, float]:
        """Train for one epoch."""
        self.model.train()
        total_loss = 0.0
        num_batches = 0
        metrics = {}
        
        for batch_idx, (inputs, targets) in enumerate(self.train_loader):
            inputs = inputs.to(self.device)
            targets = targets.to(self.device)
            
            # Forward pass with optional mixed precision
            if self.scaler is not None:
                with torch.cuda.amp.autocast():
                    outputs = self.model(inputs)
                    loss = self.criterion(outputs, targets)
            else:
                outputs = self.model(inputs)
                loss = self.criterion(outputs, targets)
            
            # Backward pass with gradient scaling
            if self.scaler is not None:
                self.scaler.scale(loss).backward()
                
                if (batch_idx + 1) % self.config.accumulation_steps == 0:
                    if self.config.gradient_clip:
                        self.scaler.unscale_(self.optimizer)
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(),
                            self.config.gradient_clip
                        )
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad()
            else:
                loss.backward()
                
                if (batch_idx + 1) % self.config.accumulation_steps == 0:
                    if self.config.gradient_clip:
                        torch.nn.utils.clip_grad_norm_(
                            self.model.parameters(),
                            self.config.gradient_clip
                        )
                    self.optimizer.step()
                    self.optimizer.zero_grad()
            
            total_loss += loss.item()
            num_batches += 1
            self.global_step += 1
            
            # Logging
            if (batch_idx + 1) % self.config.log_every == 0:
                avg_loss = total_loss / num_batches
                lr = self.optimizer.param_groups[0]['lr']
                print(f"  Step [{batch_idx + 1}/{len(self.train_loader)}] "
                      f"Loss: {avg_loss:.4f} LR: {lr:.2e}")
        
        metrics["loss"] = total_loss / num_batches
        return metrics
    
    @torch.no_grad()
    def _validate_epoch(self) -> Dict[str, float]:
        """Validate for one epoch."""
        self.model.eval()
        total_loss = 0.0
        num_batches = 0
        
        for inputs, targets in self.val_loader:
            inputs = inputs.to(self.device)
            targets = targets.to(self.device)
            
            outputs = self.model(inputs)
            loss = self.criterion(outputs, targets)
            
            total_loss += loss.item()
            num_batches += 1
        
        return {"loss": total_loss / num_batches}
    
    def _record_metrics(
        self,
        train_metrics: Dict[str, float],
        val_metrics: Dict[str, float],
        epoch_time: float
    ) -> None:
        """Record metrics to history."""
        self.training_history["train_loss"].append(train_metrics.get("loss", 0))
        self.training_history["train_metric"].append(train_metrics.get("metric", 0))
        self.training_history["val_loss"].append(val_metrics.get("loss", 0))
        self.training_history["val_metric"].append(val_metrics.get("metric", 0))
        self.training_history["learning_rate"].append(
            self.optimizer.param_groups[0]['lr']
        )
        self.training_history["epoch_time"].append(epoch_time)
    
    def _check_improvement(self, val_metrics: Dict[str, float]) -> bool:
        """Check if validation metric improved."""
        current_metric = val_metrics.get("loss", float('inf'))
        
        if self._is_validation_lower_better():
            improved = current_metric < (self.best_metric - self.config.early_stopping_min_delta)
        else:
            improved = current_metric > (self.best_metric + self.config.early_stopping_min_delta)
        
        if improved:
            self.best_metric = current_metric
            self.patience_counter = 0
        else:
            self.patience_counter += 1
        
        return improved
    
    def _check_early_stopping(self, val_metrics: Dict[str, float]) -> bool:
        """Check if early stopping criteria met."""
        return self.patience_counter >= self.config.early_stopping_patience
    
    def _save_checkpoint(
        self,
        improved: bool,
        train_metrics: Dict[str, float],
        val_metrics: Dict[str, float]
    ) -> None:
        """Save model checkpoint."""
        checkpoint = {
            "epoch": self.current_epoch,
            "global_step": self.global_step,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "train_metrics": train_metrics,
            "val_metrics": val_metrics,
            "best_metric": self.best_metric,
            "config": self.config.__dict__,
        }
        
        if self.scheduler is not None:
            checkpoint["scheduler_state_dict"] = self.scheduler.state_dict()
        
        # Save latest checkpoint
        latest_path = Path(self.config.output_dir) / "checkpoint_latest.pt"
        torch.save(checkpoint, latest_path)
        
        # Save best checkpoint
        if improved:
            best_path = Path(self.config.output_dir) / "checkpoint_best.pt"
            torch.save(checkpoint, best_path)
            print(f"  New best model saved (metric: {self.best_metric:.4f})")
    
    def _resume_training(self, checkpoint_path: str) -> None:
        """Resume training from checkpoint."""
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        
        if "scheduler_state_dict" in checkpoint and self.scheduler is not None:
            self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        
        self.current_epoch = checkpoint["epoch"] + 1
        self.global_step = checkpoint["global_step"]
        self.best_metric = checkpoint["best_metric"]
        
        print(f"Resumed training from epoch {self.current_epoch}")
    
    def _log_epoch_summary(
        self,
        epoch: int,
        train_metrics: Dict[str, float],
        val_metrics: Dict[str, float],
        epoch_time: float
    ) -> None:
        """Log epoch summary."""
        lr = self.optimizer.param_groups[0]['lr']
        
        if val_metrics:
            print(f"Epoch [{epoch + 1}/{self.config.max_epochs}] "
                  f"Train Loss: {train_metrics.get('loss', 0):.4f} "
                  f"Val Loss: {val_metrics.get('loss', 0):.4f} "
                  f"LR: {lr:.2e} Time: {epoch_time:.1f}s")
        else:
            print(f"Epoch [{epoch + 1}/{self.config.max_epochs}] "
                  f"Train Loss: {train_metrics.get('loss', 0):.4f} "
                  f"LR: {lr:.2e} Time: {epoch_time:.1f}s")
    
    def _compile_results(self) -> Dict[str, Any]:
        """Compile training results."""
        return {
            "final_epoch": self.current_epoch + 1,
            "best_metric": self.best_metric,
            "training_history": self.training_history,
            "config": self.config.__dict__,
        }
