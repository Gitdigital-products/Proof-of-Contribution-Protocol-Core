"""
Loss Functions Module
======================

Provides comprehensive collection of loss functions for classification,
regression, and specialized tasks with easy configuration.

Author: MiniMax Agent
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Any, Optional, Union, Callable
from dataclasses import dataclass


@dataclass
class LossConfig:
    """
    Configuration for loss function.
    
    Attributes:
        name: Loss function name
        weight: Loss weight for class weighting
        reduction: Reduction method ('mean', 'sum', 'none')
        label_smoothing: Label smoothing factor
        focal_alpha: Focal loss alpha parameter
        focal_gamma: Focal loss gamma parameter
    """
    name: str = "cross_entropy"
    weight: Optional[torch.Tensor] = None
    reduction: str = "mean"
    label_smoothing: float = 0.0
    focal_alpha: float = 0.25
    focal_gamma: float = 2.0


class LossFactory:
    """
    Factory for creating loss functions.
    
    Example:
        >>> factory = LossFactory({"name": "cross_entropy", "label_smoothing": 0.1})
        >>> criterion = factory.create()
    """
    
    _losses = {
        "cross_entropy": nn.CrossEntropyLoss,
        "binary_cross_entropy": nn.BCELoss,
        "bce_with_logits": nn.BCEWithLogitsLoss,
        "mse": nn.MSELoss,
        "mae": nn.L1Loss,
        "smooth_l1": nn.SmoothL1Loss,
        "huber": nn.HuberLoss,
        "kldiv": nn.KLDivLoss,
        "marginRanking": nn.MarginRankingLoss,
        "multiMargin": nn.MultiMarginLoss,
        "multiLabelSoftMargin": nn.MultiLabelSoftMarginLoss,
        "cosineEmbedding": nn.CosineEmbeddingLoss,
        "tripletMargin": nn.TripletMarginLoss,
        "poissonNLL": nn.PoissonNLLLoss,
        "gaussianNLL": nn.GaussianNLLLoss,
    }
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize loss factory.
        
        Args:
            config: Loss configuration dictionary
        """
        self.config = LossConfig(**(config or {}))
    
    def create(self) -> nn.Module:
        """
        Create loss function.
        
        Returns:
            Configured loss function
        """
        loss_name = self.config.name.lower()
        
        if loss_name not in self._losses:
            raise ValueError(
                f"Unknown loss: {loss_name}. "
                f"Available: {list(self._losses.keys())}"
            )
        
        loss_class = self._losses[loss_name]
        
        # Get loss-specific parameters
        loss_kwargs = self._get_loss_kwargs(loss_name)
        
        return loss_class(**loss_kwargs)
    
    def _get_loss_kwargs(self, loss_name: str) -> Dict[str, Any]:
        """Get loss-specific keyword arguments."""
        kwargs = {}
        
        # Common kwargs
        if self.config.weight is not None:
            kwargs["weight"] = self.config.weight
        
        kwargs["reduction"] = self.config.reduction
        
        # Loss-specific kwargs
        if loss_name == "cross_entropy":
            if self.config.label_smoothing > 0:
                kwargs["label_smoothing"] = self.config.label_smoothing
        
        elif loss_name == "bce_with_logits":
            if self.config.pos_weight is not None:
                kwargs["pos_weight"] = self.config.pos_weight
        
        return kwargs
    
    @classmethod
    def register_loss(
        cls,
        name: str,
        loss_class: type
    ) -> None:
        """
        Register custom loss function.
        
        Args:
            name: Loss name
            loss_class: Loss class
        """
        cls._losses[name.lower()] = loss_class


class FocalLoss(nn.Module):
    """
    Focal Loss for addressing class imbalance.
    
    focal_loss = -alpha * (1 - p_t)^gamma * log(p_t)
    
    Reference: Lin et al., "Focal Loss for Dense Object Detection"
    """
    
    def __init__(
        self,
        alpha: float = 0.25,
        gamma: float = 2.0,
        reduction: str = "mean"
    ):
        """
        Initialize Focal Loss.
        
        Args:
            alpha: Weighting factor for class balance
            gamma: Focusing parameter
            reduction: Reduction method
        """
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
    
    def forward(
        self,
        inputs: torch.Tensor,
        targets: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute focal loss.
        
        Args:
            inputs: Predicted logits
            targets: Ground truth labels
            
        Returns:
            Focal loss value
        """
        ce_loss = F.cross_entropy(inputs, targets, reduction='none')
        p_t = torch.exp(-ce_loss)
        focal_weight = (1 - p_t) ** self.gamma
        
        loss = self.alpha * focal_weight * ce_loss
        
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


class LabelSmoothingCrossEntropy(nn.Module):
    """
    Cross-entropy loss with label smoothing.
    
    Reduces overconfidence of the model by smoothing labels.
    """
    
    def __init__(self, smoothing: float = 0.1, reduction: str = "mean"):
        """
        Initialize label smoothing loss.
        
        Args:
            smoothing: Smoothing factor (0.0 to 1.0)
            reduction: Reduction method
        """
        super().__init__()
        self.smoothing = smoothing
        self.reduction = reduction
    
    def forward(
        self,
        inputs: torch.Tensor,
        targets: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute label smoothing loss.
        
        Args:
            inputs: Predicted logits
            targets: Ground truth labels
            
        Returns:
            Loss value
        """
        n_classes = inputs.size(-1)
        log_probs = F.log_softmax(inputs, dim=-1)
        
        # Create smoothed labels
        with torch.no_grad():
            true_dist = torch.zeros_like(log_probs)
            true_dist.fill_(self.smoothing / (n_classes - 1))
            true_dist.scatter_(1, targets.unsqueeze(1), 1.0 - self.smoothing)
        
        loss = torch.sum(-true_dist * log_probs, dim=-1)
        
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


class DiceLoss(nn.Module):
    """
    Dice Loss for segmentation and similar tasks.
    
    Maximizes overlap between predicted and ground truth.
    """
    
    def __init__(self, smooth: float = 1.0, reduction: str = "mean"):
        """
        Initialize Dice Loss.
        
        Args:
            smooth: Smoothing factor to avoid division by zero
            reduction: Reduction method
        """
        super().__init__()
        self.smooth = smooth
        self.reduction = reduction
    
    def forward(
        self,
        inputs: torch.Tensor,
        targets: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute Dice loss.
        
        Args:
            inputs: Predicted probabilities (after sigmoid)
            targets: Ground truth binary masks
            
        Returns:
            Dice loss value
        """
        # Flatten
        inputs = inputs.view(-1)
        targets = targets.view(-1)
        
        intersection = (inputs * targets).sum()
        dice = (2. * intersection + self.smooth) / (
            inputs.sum() + targets.sum() + self.smooth
        )
        
        loss = 1 - dice
        
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


class IoULoss(nn.Module):
    """
    Intersection over Union (IoU) Loss.
    
    Commonly used for object detection and segmentation.
    """
    
    def __init__(self, reduction: str = "mean", smooth: float = 1e-6):
        super().__init__()
        self.reduction = reduction
        self.smooth = smooth
    
    def forward(
        self,
        inputs: torch.Tensor,
        targets: torch.Tensor
    ) -> torch.Tensor:
        """Compute IoU loss."""
        inputs = torch.sigmoid(inputs)
        inputs = inputs.view(-1)
        targets = targets.view(-1)
        
        intersection = (inputs * targets).sum()
        union = inputs.sum() + targets.sum() - intersection
        
        iou = (intersection + self.smooth) / (union + self.smooth)
        loss = 1 - iou
        
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


class ContrastiveLoss(nn.Module):
    """
    Contrastive Loss for learning embeddings.
    
    Pulls similar samples together, pushes dissimilar samples apart.
    """
    
    def __init__(
        self,
        margin: float = 1.0,
        reduction: str = "mean"
    ):
        """
        Initialize contrastive loss.
        
        Args:
            margin: Margin for dissimilar pairs
            reduction: Reduction method
        """
        super().__init__()
        self.margin = margin
        self.reduction = reduction
    
    def forward(
        self,
        embeddings1: torch.Tensor,
        embeddings2: torch.Tensor,
        labels: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute contrastive loss.
        
        Args:
            embeddings1: First set of embeddings
            embeddings2: Second set of embeddings
            labels: Similarity labels (1 for similar, 0 for dissimilar)
            
        Returns:
            Loss value
        """
        distances = F.pairwise_distance(embeddings1, embeddings2)
        
        similar_loss = labels * distances.pow(2)
        dissimilar_loss = (1 - labels) * F.relu(self.margin - distances).pow(2)
        
        loss = similar_loss + dissimilar_loss
        
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


class TripletLoss(nn.Module):
    """
    Triplet Loss for learning embeddings.
    
    Ensures anchor-positive distance < anchor-negative distance.
    """
    
    def __init__(
        self,
        margin: float = 1.0,
        reduction: str = "mean",
        swap: bool = True
    ):
        """
        Initialize triplet loss.
        
        Args:
            margin: Minimum margin between positive and negative pairs
            reduction: Reduction method
            swap: Use anchor-negative distance in addition to anchor-positive
        """
        super().__init__()
        self.margin = margin
        self.reduction = reduction
        self.swap = swap
    
    def forward(
        self,
        anchor: torch.Tensor,
        positive: torch.Tensor,
        negative: torch.Tensor
    ) -> torch.Tensor:
        """
        Compute triplet loss.
        
        Args:
            anchor: Anchor embeddings
            positive: Positive embeddings (same class as anchor)
            negative: Negative embeddings (different class)
            
        Returns:
            Loss value
        """
        dist_pos = F.pairwise_distance(anchor, positive)
        dist_neg = F.pairwise_distance(anchor, negative)
        
        if self.swap:
            dist_swap = F.pairwise_distance(positive, negative)
            dist_neg = torch.min(dist_neg, dist_swap)
        
        losses = F.relu(dist_pos - dist_neg + self.margin)
        
        if self.reduction == "mean":
            return losses.mean()
        elif self.reduction == "sum":
            return losses.sum()
        return losses


class WeightedCrossEntropyLoss(nn.Module):
    """
    Weighted Cross-Entropy Loss with per-class weights.
    
    Useful for imbalanced classification problems.
    """
    
    def __init__(
        self,
        weights: Optional[torch.Tensor] = None,
        label_smoothing: float = 0.0,
        reduction: str = "mean"
    ):
        """
        Initialize weighted cross-entropy loss.
        
        Args:
            weights: Per-class weights
            label_smoothing: Label smoothing factor
            reduction: Reduction method
        """
        super().__init__()
        self.weights = weights
        self.label_smoothing = label_smoothing
        self.reduction = reduction
    
    def forward(
        self,
        inputs: torch.Tensor,
        targets: torch.Tensor
    ) -> torch.Tensor:
        """Compute weighted cross-entropy loss."""
        n_classes = inputs.size(-1)
        
        log_probs = F.log_softmax(inputs, dim=-1)
        
        if self.label_smoothing > 0:
            with torch.no_grad():
                true_dist = torch.zeros_like(log_probs)
                true_dist.fill_(self.label_smoothing / (n_classes - 1))
                true_dist.scatter_(1, targets.unsqueeze(1), 1.0 - self.label_smoothing)
        else:
            true_dist = F.one_hot(targets, n_classes).float()
        
        if self.weights is not None:
            weights = self.weights.to(inputs.device)
            weights = weights.unsqueeze(0).expand_as(true_dist)
            true_dist = true_dist * weights
        
        loss = -(true_dist * log_probs).sum(dim=-1)
        
        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        return loss


def get_loss_function(
    name: str,
    **kwargs
) -> nn.Module:
    """
    Convenience function to get loss function by name.
    
    Example:
        >>> criterion = get_loss_function("focal", alpha=0.25, gamma=2.0)
    """
    losses = {
        "cross_entropy": nn.CrossEntropyLoss,
        "focal": FocalLoss,
        "label_smoothing": LabelSmoothingCrossEntropy,
        "dice": DiceLoss,
        "iou": IoULoss,
        "contrastive": ContrastiveLoss,
        "triplet": TripletLoss,
        "weighted_ce": WeightedCrossEntropyLoss,
    }
    
    if name.lower() not in losses:
        raise ValueError(f"Unknown loss: {name}")
    
    return losses[name.lower()](**kwargs)
