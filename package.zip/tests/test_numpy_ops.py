"""
Tests for NumPy Operations Module
=================================

Unit tests for scientific/numpy_ops.py
"""

import pytest
import numpy as np
from scientific.numpy_ops import (
    normalize,
    denormalize,
    softmax,
    log_sum_exp,
    compute_pairwise_distances,
    clip_gradient
)


class TestNormalize:
    """Tests for normalize function."""
    
    def test_normalize_basic(self):
        """Test basic normalization."""
        data = np.array([1, 2, 3, 4, 5], dtype=np.float32)
        normalized, mean, std = normalize(data)
        
        assert np.abs(mean - 3.0) < 0.1
        assert np.abs(std - 1.4) < 0.1
        assert np.abs(np.mean(normalized)) < 0.1
    
    def test_normalize_axis(self):
        """Test axis normalization."""
        data = np.random.randn(10, 5).astype(np.float32)
        normalized, _, _ = normalize(data, axis=0)
        
        assert normalized.shape == data.shape


class TestSoftmax:
    """Tests for softmax function."""
    
    def test_softmax_basic(self):
        """Test basic softmax."""
        logits = np.array([1.0, 2.0, 3.0])
        result = softmax(logits)
        
        assert np.all(result >= 0)
        assert np.abs(np.sum(result) - 1.0) < 0.01
    
    def test_softmax_stable(self):
        """Test numerical stability."""
        logits = np.array([1000, 1001, 1002])
        result = softmax(logits)
        
        assert np.all(np.isfinite(result))
        assert np.abs(np.sum(result) - 1.0) < 0.01


class TestPairwiseDistances:
    """Tests for pairwise distances."""
    
    def test_euclidean(self):
        """Test Euclidean distance."""
        a = np.array([[0, 0], [1, 1]])
        b = np.array([[0, 0], [1, 0]])
        
        dist = compute_pairwise_distances(a, b, metric='euclidean')
        
        assert dist.shape == (2, 2)
        assert dist[0, 0] == 0.0


class TestClipGradient:
    """Tests for gradient clipping."""
    
    def test_clip_gradient(self):
        """Test gradient clipping."""
        grad = np.array([1.0, 2.0, 10.0])
        clipped = clip_gradient(grad, max_norm=1.0)
        
        total_norm = np.sqrt(np.sum(clipped ** 2))
        assert total_norm <= 1.0 + 1e-5


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
