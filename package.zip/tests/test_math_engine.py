"""
Tests for Math Engine
=====================

Unit tests for math_engine/
"""

import pytest
import numpy as np
from math_engine.equations import LinearEquation, QuadraticEquation, Polynomial
from math_engine.solvers import solve_linear, solve_quadratic, bisection
from math_engine.calculus import derivative, gradient


class TestLinearEquation:
    """Tests for LinearEquation class."""
    
    def test_linear_creation(self):
        """Test linear equation creation."""
        eq = LinearEquation(2, -4)
        
        assert eq.a == 2
        assert eq.b == -4
    
    def test_linear_solve(self):
        """Test linear equation solving."""
        eq = LinearEquation(2, -4)  # 2x - 4 = 0
        
        solution = eq.solve()
        assert np.abs(solution - 2.0) < 0.001


class TestQuadraticEquation:
    """Tests for QuadraticEquation class."""
    
    def test_quadratic_creation(self):
        """Test quadratic equation creation."""
        eq = QuadraticEquation(1, -3, 2)  # x² - 3x + 2 = 0
        
        assert eq.a == 1
        assert eq.b == -3
        assert eq.c == 2
    
    def test_quadratic_solve(self):
        """Test quadratic equation solving."""
        eq = QuadraticEquation(1, -3, 2)  # (x-1)(x-2) = 0
        
        x1, x2 = eq.solve()
        
        assert np.abs(x1 - 1.0) < 0.001 or np.abs(x1 - 2.0) < 0.001
        assert np.abs(x2 - 1.0) < 0.001 or np.abs(x2 - 2.0) < 0.001
    
    def test_discriminant(self):
        """Test discriminant calculation."""
        eq = QuadraticEquation(1, -3, 2)
        
        disc = eq.get_discriminant()
        assert disc == 1


class TestPolynomial:
    """Tests for Polynomial class."""
    
    def test_polynomial_creation(self):
        """Test polynomial creation."""
        poly = Polynomial([1, -3, 2])  # x² - 3x + 2
        
        assert poly.degree == 2
        assert len(poly.coefficients) == 3
    
    def test_polynomial_derivative(self):
        """Test polynomial derivative."""
        poly = Polynomial([1, 0, -1])  # x² - 1
        
        deriv = poly.derivative()
        
        assert deriv.degree == 1


class TestSolvers:
    """Tests for solvers."""
    
    def test_solve_linear(self):
        """Test linear system solver."""
        a = np.array([[2, 1], [1, 3]])
        b = np.array([3, 4])
        
        x = solve_linear(a, b)
        
        assert x.shape == (2,)
        assert np.allclose(a @ x, b)
    
    def test_solve_quadratic(self):
        """Test quadratic solver."""
        x1, x2 = solve_quadratic(1, -3, 2)
        
        assert np.isclose(x1 * x2, 2)


class TestCalculus:
    """Tests for calculus operations."""
    
    def test_derivative(self):
        """Test numerical derivative."""
        def f(x):
            return x**2
        
        df = derivative(f, 2.0)
        
        assert np.abs(df - 4.0) < 0.001
    
    def test_gradient(self):
        """Test gradient computation."""
        def f(x):
            return x[0]**2 + x[1]**2
        
        x = np.array([1.0, 1.0])
        grad = gradient(f, x)
        
        assert np.allclose(grad, [2.0, 2.0], atol=0.01)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
