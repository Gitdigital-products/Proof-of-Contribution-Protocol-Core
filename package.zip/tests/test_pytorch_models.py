"""
Tests for PyTorch Models
=======================

Unit tests for pytorch_lab/models/
"""

import pytest
import torch
from pytorch_lab.models.mlp import MLP, MLPConfig
from pytorch_lab.models.cnn import CNN, CNNConfig
from pytorch_lab.models.transformer import Transformer, TransformerConfig


class TestMLP:
    """Tests for MLP model."""
    
    def test_mlp_creation(self):
        """Test MLP model creation."""
        config = MLPConfig(input_dim=784, output_dim=10, hidden_dims=[256, 128])
        model = MLP(config)
        
        assert model is not None
        assert model.config.input_dim == 784
        assert model.config.output_dim == 10
    
    def test_mlp_forward(self):
        """Test MLP forward pass."""
        config = MLPConfig(input_dim=100, output_dim=10)
        model = MLP(config)
        
        x = torch.randn(4, 100)
        output = model(x)
        
        assert output.shape == (4, 10)
    
    def test_mlp_parameter_count(self):
        """Test parameter counting."""
        config = MLPConfig(input_dim=100, output_dim=10, hidden_dims=[50])
        model = MLP(config)
        
        param_count = model.count_parameters()
        assert param_count > 0


class TestCNN:
    """Tests for CNN model."""
    
    def test_cnn_creation(self):
        """Test CNN model creation."""
        config = CNNConfig(input_channels=3, output_dim=10)
        model = CNN(config)
        
        assert model is not None
        assert model.config.input_channels == 3
    
    def test_cnn_forward(self):
        """Test CNN forward pass."""
        config = CNNConfig(input_channels=3, output_dim=10)
        model = CNN(config)
        
        x = torch.randn(4, 3, 32, 32)
        output = model(x)
        
        assert output.shape == (4, 10)


class TestTransformer:
    """Tests for Transformer model."""
    
    def test_transformer_creation(self):
        """Test Transformer creation."""
        config = TransformerConfig(input_dim=128, output_dim=10)
        model = Transformer(config)
        
        assert model is not None
    
    def test_transformer_forward(self):
        """Test Transformer forward pass."""
        config = TransformerConfig(input_dim=128, output_dim=10, num_heads=4)
        model = Transformer(config)
        
        x = torch.randn(4, 20, 128)  # (batch, seq_len, features)
        output = model(x)
        
        assert "logits" in output
        assert output["logits"].shape == (4, 10)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
